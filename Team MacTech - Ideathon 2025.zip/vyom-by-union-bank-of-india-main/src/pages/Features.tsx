
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage } from "@/components/LanguageToggle";
import { Button } from "@/components/ui/button";
import {
  ShieldCheck,
  Smartphone,
  CreditCard,
  LineChart,
  Globe,
  Lock,
  Zap,
  Building,
  PieChart,
  Check,
  ChevronRight,
  RefreshCw,
  Bell
} from "lucide-react";

const Features = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { currentLanguage } = useLanguage();
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  // Content translations
  const content = {
    en: {
      title: "Features",
      subtitle: "Powerful banking features designed for you",
      description: "Discover how Vyom's innovative features can transform your banking experience and help you achieve your financial goals.",
      categories: [
        {
          title: "Security",
          description: "Bank with confidence knowing your money and data are protected by state-of-the-art security systems.",
          features: [
            { title: "AI Fraud Detection", description: "Proactive monitoring system that detects and prevents suspicious activity." },
            { title: "Biometric Authentication", description: "Secure access through fingerprint, face, or voice recognition." },
            { title: "End-to-End Encryption", description: "All transactions and data are encrypted to industry standards." }
          ],
          icon: <ShieldCheck size={24} />
        },
        {
          title: "Mobile Banking",
          description: "Manage your finances anytime, anywhere with our feature-rich mobile application.",
          features: [
            { title: "User-Friendly Interface", description: "Intuitive design for seamless navigation and transaction processing." },
            { title: "Offline Capabilities", description: "Access key features even without an internet connection." },
            { title: "Multi-Device Sync", description: "Consistent experience across all your devices." }
          ],
          icon: <Smartphone size={24} />
        },
        {
          title: "Payments & Transfers",
          description: "Send and receive money securely, quickly, and with minimal fees.",
          features: [
            { title: "Instant Transfers", description: "Send money in seconds to any account with immediate confirmation." },
            { title: "Scheduled Payments", description: "Set up recurring payments or schedule future transactions." },
            { title: "Global Remittances", description: "Transfer money internationally with competitive exchange rates." }
          ],
          icon: <CreditCard size={24} />
        },
        {
          title: "Financial Insights",
          description: "Get personalized insights to make informed decisions about your money.",
          features: [
            { title: "Spending Analysis", description: "Track and categorize your expenses with detailed breakdowns." },
            { title: "Budget Planning", description: "Create and monitor budgets to meet your financial goals." },
            { title: "Investment Tracking", description: "Monitor the performance of your investments in real-time." }
          ],
          icon: <LineChart size={24} />
        }
      ],
      cta: "Get Started Now",
      explore: "Explore More",
      comparison: {
        title: "Why Choose Vyom",
        description: "See how Vyom compares to traditional banking services",
        features: [
          { name: "24/7 Account Access", vyom: true, traditional: false },
          { name: "Zero Maintenance Fees", vyom: true, traditional: false },
          { name: "Instant Account Opening", vyom: true, traditional: false },
          { name: "Personalized Insights", vyom: true, traditional: false },
          { name: "Global Banking", vyom: true, traditional: true },
          { name: "Physical Branch Support", vyom: false, traditional: true },
          { name: "Smart Notifications", vyom: true, traditional: false },
          { name: "Integrated Investment Tools", vyom: true, traditional: false }
        ]
      }
    },
    hi: {
      title: "विशेषताएँ",
      subtitle: "आपके लिए डिज़ाइन की गई शक्तिशाली बैंकिंग सुविधाएँ",
      description: "जानें कैसे व्योम की नवीन विशेषताएँ आपके बैंकिंग अनुभव को बदल सकती हैं और आपको अपने वित्तीय लक्ष्यों को प्राप्त करने में मदद कर सकती हैं।",
      categories: [
        {
          title: "सुरक्षा",
          description: "आत्मविश्वास के साथ बैंकिंग करें, यह जानते हुए कि आपका पैसा और डेटा अत्याधुनिक सुरक्षा प्रणालियों द्वारा संरक्षित है।",
          features: [
            { title: "एआई धोखाधड़ी का पता लगाना", description: "सक्रिय निगरानी प्रणाली जो संदिग्ध गतिविधि का पता लगाती है और रोकती है।" },
            { title: "बायोमेट्रिक प्रमाणीकरण", description: "फिंगरप्रिंट, चेहरे, या आवाज पहचान के माध्यम से सुरक्षित पहुंच।" },
            { title: "एंड-टू-एंड एन्क्रिप्शन", description: "सभी लेनदेन और डेटा उद्योग मानकों के अनुसार एन्क्रिप्ट किए गए हैं।" }
          ],
          icon: <ShieldCheck size={24} />
        },
        {
          title: "मोबाइल बैंकिंग",
          description: "हमारे फीचर-रिच मोबाइल एप्लिकेशन के साथ किसी भी समय, कहीं भी अपने वित्त का प्रबंधन करें।",
          features: [
            { title: "उपयोगकर्ता-अनुकूल इंटरफेस", description: "निर्बाध नेविगेशन और लेनदेन प्रसंस्करण के लिए सहज डिज़ाइन।" },
            { title: "ऑफलाइन क्षमताएं", description: "इंटरनेट कनेक्शन के बिना भी प्रमुख सुविधाओं तक पहुंच।" },
            { title: "मल्टी-डिवाइस सिंक", description: "आपके सभी उपकरणों पर एक समान अनुभव।" }
          ],
          icon: <Smartphone size={24} />
        },
        {
          title: "भुगतान और स्थानांतरण",
          description: "सुरक्षित, तेज़ी से और न्यूनतम शुल्क के साथ पैसे भेजें और प्राप्त करें।",
          features: [
            { title: "तत्काल स्थानांतरण", description: "तत्काल पुष्टि के साथ किसी भी खाते में सेकंडों में पैसे भेजें।" },
            { title: "निर्धारित भुगतान", description: "आवर्ती भुगतान सेट करें या भविष्य के लेनदेन शेड्यूल करें।" },
            { title: "वैश्विक प्रेषण", description: "प्रतिस्पर्धी विनिमय दरों के साथ अंतरराष्ट्रीय स्तर पर पैसे स्थानांतरित करें।" }
          ],
          icon: <CreditCard size={24} />
        },
        {
          title: "वित्तीय अंतर्दृष्टि",
          description: "अपने पैसे के बारे में सूचित निर्णय लेने के लिए व्यक्तिगत अंतर्दृष्टि प्राप्त करें।",
          features: [
            { title: "खर्च विश्लेषण", description: "विस्तृत विवरण के साथ अपने खर्चों को ट्रैक और वर्गीकृत करें।" },
            { title: "बजट योजना", description: "अपने वित्तीय लक्ष्यों को पूरा करने के लिए बजट बनाएं और निगरानी करें।" },
            { title: "निवेश ट्रैकिंग", description: "रीयल-टाइम में अपने निवेशों के प्रदर्शन की निगरानी करें।" }
          ],
          icon: <LineChart size={24} />
        }
      ],
      cta: "अभी शुरू करें",
      explore: "और जानें",
      comparison: {
        title: "व्योम क्यों चुनें",
        description: "देखें कि व्योम पारंपरिक बैंकिंग सेवाओं की तुलना में कैसा है",
        features: [
          { name: "24/7 खाता पहुंच", vyom: true, traditional: false },
          { name: "शून्य रखरखाव शुल्क", vyom: true, traditional: false },
          { name: "तत्काल खाता खोलना", vyom: true, traditional: false },
          { name: "व्यक्तिगत अंतर्दृष्टि", vyom: true, traditional: false },
          { name: "वैश्विक बैंकिंग", vyom: true, traditional: true },
          { name: "भौतिक शाखा समर्थन", vyom: false, traditional: true },
          { name: "स्मार्ट नोटिफिकेशन", vyom: true, traditional: false },
          { name: "एकीकृत निवेश उपकरण", vyom: true, traditional: false }
        ]
      }
    },
    mr: {
      title: "वैशिष्ट्ये",
      subtitle: "तुमच्यासाठी तयार केलेली शक्तिशाली बँकिंग वैशिष्ट्ये",
      description: "व्योमची नावीन्यपूर्ण वैशिष्ट्ये तुमचा बँकिंग अनुभव कसा बदलू शकतात आणि तुम्हाला तुमची आर्थिक लक्ष्य साध्य करण्यात कशी मदत करू शकतात हे जाणून घ्या.",
      categories: [
        {
          title: "सुरक्षितता",
          description: "तुमचे पैसे आणि डेटा अत्याधुनिक सुरक्षा प्रणालीद्वारे संरक्षित आहेत हे जाणून विश्वासाने बँकिंग करा.",
          features: [
            { title: "AI फसवणूक शोधणे", description: "संशयास्पद क्रियाकलाप शोधण्यासाठी आणि प्रतिबंधित करण्यासाठी सक्रिय देखरेख प्रणाली." },
            { title: "बायोमेट्रिक प्रमाणीकरण", description: "फिंगरप्रिंट, चेहरा किंवा आवाज ओळखीद्वारे सुरक्षित प्रवेश." },
            { title: "एंड-टू-एंड एन्क्रिप्शन", description: "सर्व व्यवहार आणि डेटा उद्योग मानकांनुसार एन्क्रिप्ट केलेले आहेत." }
          ],
          icon: <ShieldCheck size={24} />
        },
        {
          title: "मोबाइल बँकिंग",
          description: "आमच्या वैशिष्ट्यपूर्ण मोबाइल अॅप्लिकेशनसह कधीही, कुठेही आपले आर्थिक व्यवस्थापित करा.",
          features: [
            { title: "वापरकर्ता-अनुकूल इंटरफेस", description: "सहज नेव्हिगेशन आणि व्यवहार प्रक्रियेसाठी अंतर्ज्ञानी डिझाइन." },
            { title: "ऑफलाइन क्षमता", description: "इंटरनेट कनेक्शनशिवाय देखील मुख्य वैशिष्ट्यांमध्ये प्रवेश करा." },
            { title: "मल्टी-डिव्हाइस सिंक", description: "तुमच्या सर्व डिव्हाइसवर सातत्यपूर्ण अनुभव." }
          ],
          icon: <Smartphone size={24} />
        },
        {
          title: "पेमेंट्स आणि ट्रान्सफर्स",
          description: "सुरक्षित, द्रुतगतीने आणि किमान शुल्कासह पैसे पाठवा आणि प्राप्त करा.",
          features: [
            { title: "तात्काळ हस्तांतरण", description: "तत्काळ पुष्टीकरणासह कोणत्याही खात्यात सेकंदात पैसे पाठवा." },
            { title: "शेड्यूल पेमेंट्स", description: "आवर्ती पेमेंट्स सेटअप करा किंवा भविष्यातील व्यवहार शेड्यूल करा." },
            { title: "जागतिक प्रेषण", description: "स्पर्धात्मक विनिमय दरांसह आंतरराष्ट्रीय पैसे हस्तांतरित करा." }
          ],
          icon: <CreditCard size={24} />
        },
        {
          title: "आर्थिक अंतर्दृष्टी",
          description: "तुमच्या पैशांबद्दल माहितीपूर्ण निर्णय घेण्यासाठी वैयक्तिकृत अंतर्दृष्टी मिळवा.",
          features: [
            { title: "खर्च विश्लेषण", description: "तपशीलवार ब्रेकडाउनसह तुमचे खर्च ट्रॅक आणि वर्गीकृत करा." },
            { title: "बजेट नियोजन", description: "तुमची आर्थिक उद्दिष्टे पूर्ण करण्यासाठी बजेट तयार करा आणि देखरेख करा." },
            { title: "गुंतवणूक ट्रॅकिंग", description: "रिअल-टाइममध्ये तुमच्या गुंतवणुकींची कामगिरी मॉनिटर करा." }
          ],
          icon: <LineChart size={24} />
        }
      ],
      cta: "आता सुरू करा",
      explore: "अधिक जाणून घ्या",
      comparison: {
        title: "व्योम का निवडावे",
        description: "व्योम पारंपारिक बँकिंग सेवांशी कसे तुलना करते हे पहा",
        features: [
          { name: "24/7 खाते प्रवेश", vyom: true, traditional: false },
          { name: "शून्य देखभाल शुल्क", vyom: true, traditional: false },
          { name: "तात्काळ खाते उघडणे", vyom: true, traditional: false },
          { name: "वैयक्तिकृत अंतर्दृष्टी", vyom: true, traditional: false },
          { name: "जागतिक बँकिंग", vyom: true, traditional: true },
          { name: "भौतिक शाखा समर्थन", vyom: false, traditional: true },
          { name: "स्मार्ट सूचना", vyom: true, traditional: false },
          { name: "एकात्मिक गुंतवणूक साधने", vyom: true, traditional: false }
        ]
      }
    }
  };

  // Get content based on current language
  const t = content[currentLanguage.code as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-40 pb-20 px-4 bg-gradient-to-b from-white to-vyom-light">
        <div className="container mx-auto">
          <div className={`max-w-3xl mx-auto text-center ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}>
            <h1 className="text-4xl md:text-5xl font-bold text-vyom-blue mb-6">{t.title}</h1>
            <p className="text-xl text-vyom-red font-medium mb-8">{t.subtitle}</p>
            <p className="text-lg text-vyom-gray">{t.description}</p>
          </div>
        </div>
      </section>
      
      {/* Feature Categories */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {t.categories.map((category, index) => (
              <div 
                key={index}
                className={`bg-vyom-light p-8 rounded-xl shadow-md transform transition-all duration-300 hover:shadow-xl ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}
                style={{ animationDelay: `${0.2 + 0.1 * index}s` }}
              >
                <div className="w-12 h-12 mb-6 rounded-full bg-vyom-red flex items-center justify-center">
                  {category.icon}
                </div>
                <h2 className="text-2xl font-bold text-vyom-blue mb-3">{category.title}</h2>
                <p className="text-vyom-gray mb-6">{category.description}</p>
                
                <div className="space-y-4">
                  {category.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <div className="mt-1 w-5 h-5 rounded-full bg-vyom-blue/20 flex items-center justify-center">
                        <Check size={12} className="text-vyom-blue" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-vyom-blue">{feature.title}</h4>
                        <p className="text-sm text-vyom-gray">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-8">
                  <Link to="/signup">
                    <Button variant="outline" className="rounded-lg border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white">
                      {t.explore}
                      <ChevronRight size={16} className="ml-1" />
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Feature Showcase */}
      <section className="py-20 px-4 bg-vyom-light overflow-hidden">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="relative">
                <div className="rounded-2xl overflow-hidden shadow-xl">
                  <img 
                    src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                    alt="Mobile banking app" 
                    className="w-full h-auto"
                  />
                </div>
                
                {/* Animated feature cards */}
                <div className="absolute -top-6 -left-6 bg-white rounded-xl p-4 shadow-lg max-w-[200px] animate-float">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-vyom-red/20 flex items-center justify-center">
                      <RefreshCw size={20} className="text-vyom-red" />
                    </div>
                    <h4 className="font-semibold text-vyom-blue">Real-time Updates</h4>
                  </div>
                  <p className="text-xs text-vyom-gray">Get instant notifications about your account activity.</p>
                </div>
                
                <div className="absolute -bottom-6 -right-6 bg-white rounded-xl p-4 shadow-lg max-w-[200px] animate-float" style={{ animationDelay: '0.7s' }}>
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-vyom-blue/20 flex items-center justify-center">
                      <Bell size={20} className="text-vyom-blue" />
                    </div>
                    <h4 className="font-semibold text-vyom-blue">Smart Alerts</h4>
                  </div>
                  <p className="text-xs text-vyom-gray">Customized notifications for your financial goals.</p>
                </div>
              </div>
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <h2 className="text-3xl font-bold text-vyom-blue mb-6">{t.comparison.title}</h2>
              <p className="text-vyom-gray mb-8">{t.comparison.description}</p>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="grid grid-cols-3 p-4 bg-vyom-blue text-white">
                  <div className="col-span-1">
                    <span className="font-medium">Features</span>
                  </div>
                  <div className="col-span-1 text-center">
                    <span className="font-medium">Vyom</span>
                  </div>
                  <div className="col-span-1 text-center">
                    <span className="font-medium">Traditional</span>
                  </div>
                </div>
                
                {t.comparison.features.map((feature, index) => (
                  <div key={index} className={`grid grid-cols-3 p-4 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}`}>
                    <div className="col-span-1">
                      <span className="text-vyom-gray">{feature.name}</span>
                    </div>
                    <div className="col-span-1 text-center">
                      {feature.vyom ? (
                        <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100">
                          <Check size={14} className="text-green-600" />
                        </div>
                      ) : (
                        <div className="inline-flex items-center justify-center w-6 h-6">
                          <span className="text-gray-400">—</span>
                        </div>
                      )}
                    </div>
                    <div className="col-span-1 text-center">
                      {feature.traditional ? (
                        <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-100">
                          <Check size={14} className="text-green-600" />
                        </div>
                      ) : (
                        <div className="inline-flex items-center justify-center w-6 h-6">
                          <span className="text-gray-400">—</span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-10">
                <Link to="/signup">
                  <Button className="bg-vyom-red hover:bg-vyom-red/90 text-white">
                    {t.cta}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-vyom-blue to-vyom-navy text-white">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Experience Next-Gen Banking?</h2>
            <p className="text-white/80 mb-8">Join thousands of customers who have already upgraded to the future of banking with Vyom.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/signup">
                <Button className="bg-vyom-red hover:bg-vyom-red/90 text-white px-8 py-6 rounded-lg text-lg font-medium transition-all duration-300 shadow-lg hover:shadow-xl w-full sm:w-auto">
                  {t.cta}
                </Button>
              </Link>
              <Link to="/contact">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 rounded-lg text-lg font-medium transition-all duration-300 w-full sm:w-auto">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Features;
