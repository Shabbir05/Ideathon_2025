
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get Supabase credentials from environment
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL') || 'https://awptauacoalamxadknhg.supabase.co';
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    if (!SUPABASE_SERVICE_ROLE_KEY) {
      console.error("SUPABASE_SERVICE_ROLE_KEY is not set");
      return new Response(
        JSON.stringify({ error: "Server configuration error: SUPABASE_SERVICE_ROLE_KEY is not set" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create a Supabase client with the service role key (bypasses RLS)
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Parse request body
    let body;
    try {
      body = await req.json();
    } catch (e) {
      console.error("Error parsing request body:", e);
      return new Response(
        JSON.stringify({ error: "Invalid request body" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { profileId } = body;
    if (!profileId) {
      console.error("Missing profileId in request");
      return new Response(
        JSON.stringify({ error: "Missing profileId" }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log("Processing risk assessment for profile:", profileId);

    // First try to fetch the profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', profileId)
      .single();

    if (profileError) {
      console.error("Error fetching profile:", profileError);
      
      // Create a basic profile if it doesn't exist
      const defaultProfile = {
        id: profileId,
        first_name: "Anonymous",
        last_name: "User",
        age: 30,
        occupation: "Unknown",
        annual_income: 50000,
        kyc_verified: false,
        marital_status: "Single",
        is_admin: false,
        updated_at: new Date().toISOString()
      };
      
      const { data: insertedProfile, error: insertError } = await supabase
        .from('profiles')
        .upsert(defaultProfile)
        .select();
        
      if (insertError) {
        console.error("Error creating default profile:", insertError);
        return new Response(
          JSON.stringify({ error: "Failed to create profile" }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      console.log("Created default profile:", insertedProfile);
    }
    
    // Generate a simplified risk assessment
    // For reliability, we'll use a deterministic algorithm rather than OpenAI
    const userProfile = profile || {
      id: profileId,
      age: 30,
      occupation: "Unknown",
      annual_income: 50000,
      kyc_verified: false,
      marital_status: "Single"
    };
    
    // Calculate risk score based on profile factors
    let riskScore = 50; // Default medium risk
    let riskFactors = [];
    
    // Age factor (younger and older users are higher risk)
    if (userProfile.age) {
      if (userProfile.age < 25) {
        riskScore += 15;
        riskFactors.push("Young age increases risk.");
      } else if (userProfile.age > 60) {
        riskScore += 10;
        riskFactors.push("Senior age slightly increases risk.");
      } else {
        riskScore -= 5;
        riskFactors.push("Middle age reduces risk.");
      }
    }
    
    // Income factor
    if (userProfile.annual_income) {
      if (userProfile.annual_income > 100000) {
        riskScore -= 15;
        riskFactors.push("High income reduces risk significantly.");
      } else if (userProfile.annual_income > 50000) {
        riskScore -= 5;
        riskFactors.push("Average income slightly reduces risk.");
      } else {
        riskScore += 10;
        riskFactors.push("Lower income increases risk.");
      }
    }
    
    // KYC verification is a major factor
    if (userProfile.kyc_verified) {
      riskScore -= 20;
      riskFactors.push("KYC verification significantly reduces risk.");
    } else {
      riskScore += 20;
      riskFactors.push("Lack of KYC verification significantly increases risk.");
    }
    
    // Marital status
    if (userProfile.marital_status === "Married") {
      riskScore -= 5;
      riskFactors.push("Married status slightly reduces risk.");
    }
    
    // Ensure score is within 0-100 range
    riskScore = Math.max(0, Math.min(100, riskScore));
    
    // Determine risk category
    let riskCategory;
    if (riskScore < 30) {
      riskCategory = "Low";
    } else if (riskScore < 70) {
      riskCategory = "Medium";
    } else {
      riskCategory = "High";
    }
    
    // Create assessment details
    const assessmentDetails = {
      age_factor: userProfile.age ? `Age ${userProfile.age} is a ${userProfile.age < 25 || userProfile.age > 60 ? 'risk' : 'positive'} factor.` : "Age is unknown.",
      occupation_factor: `Occupation "${userProfile.occupation || 'Unknown'}" has been considered in risk assessment.`,
      income_factor: userProfile.annual_income ? `Annual income of ${userProfile.annual_income} is a ${userProfile.annual_income > 50000 ? 'positive' : 'risk'} factor.` : "Income is unknown.",
      kyc_factor: `KYC verification is ${userProfile.kyc_verified ? 'complete which significantly reduces' : 'not complete which increases'} risk.`,
      marital_status_factor: `Marital status "${userProfile.marital_status || 'Unknown'}" has been factored into assessment.`,
      summary: `This is a ${riskCategory.toLowerCase()} risk profile (score: ${riskScore}) based on ${riskFactors.join(' ')}`,
    };
    
    // Save the assessment
    const { data: assessmentData, error: assessmentError } = await supabase
      .from('risk_assessments')
      .upsert({
        profile_id: profileId,
        risk_score: riskScore,
        risk_category: riskCategory,
        assessment_details: assessmentDetails,
        updated_at: new Date().toISOString()
      }, { onConflict: 'profile_id' })
      .select();

    if (assessmentError) {
      console.error("Error saving assessment:", assessmentError);
      return new Response(
        JSON.stringify({ error: "Failed to save assessment", details: assessmentError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log("Successfully created risk assessment:", assessmentData);
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        assessment: {
          risk_score: riskScore,
          risk_category: riskCategory,
          assessment_details: assessmentDetails
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error("Unexpected error in assess-risk function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Unknown server error" }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
