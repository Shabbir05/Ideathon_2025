
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request
    const { userId } = await req.json();
    
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with service role key for admin access
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Fetch user profile data
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (profileError) {
      console.error('Error fetching user profile:', profileError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch user profile' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch user transactions
    const { data: transactions, error: transactionsError } = await supabase
      .from('user_transactions')
      .select('*')
      .eq('user_id', userId);
      
    if (transactionsError) {
      console.error('Error fetching transactions:', transactionsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch transactions' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prepare data for OpenAI
    const userFinancialData = {
      profile: {
        age: profile.age,
        occupation: profile.occupation,
        annualIncome: profile.annual_income,
        maritalStatus: profile.marital_status,
        kycVerified: profile.kyc_verified
      },
      transactions: transactions.map(tx => ({
        category: tx.transaction_category,
        amount: tx.transaction_amount,
        date: tx.transaction_date,
        frequency: tx.transaction_frequency
      }))
    };

    // Calculate summary metrics for better recommendations
    const totalSpending = transactions.reduce((sum, tx) => sum + Number(tx.transaction_amount), 0);
    const spendingByCategory = transactions.reduce((acc, tx) => {
      acc[tx.transaction_category] = (acc[tx.transaction_category] || 0) + Number(tx.transaction_amount);
      return acc;
    }, {});
    
    const topCategories = Object.entries(spendingByCategory)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([category, amount]) => ({ category, amount }));

    // Generate OpenAI prompt
    const prompt = `
You are a financial advisor at a bank. Generate 3 personalized product recommendations for a customer based on their profile and transaction history.

Customer Profile:
- Age: ${profile.age || 'Unknown'}
- Occupation: ${profile.occupation || 'Unknown'}
- Annual Income: ${profile.annual_income ? `₹${profile.annual_income.toLocaleString()}` : 'Unknown'}
- Marital Status: ${profile.marital_status || 'Unknown'}
- KYC Verified: ${profile.kyc_verified ? 'Yes' : 'No'}

Transaction Summary:
- Total Spending: ₹${totalSpending.toLocaleString()}
- Top Spending Categories: ${topCategories.map(c => `${c.category} (₹${c.amount.toLocaleString()})`).join(', ')}
- Number of Transactions: ${transactions.length}

Based on this information, recommend 3 financial products that would benefit this customer. For each recommendation, provide:
1. Product Name (Credit Card, Loan, Investment Plan, or Insurance)
2. Specific Type (e.g., "Travel Rewards Credit Card", "Home Loan", "Fixed Deposit", "Health Insurance")
3. A brief explanation of why this product is suitable for the customer (2-3 sentences)

Format the response as a JSON array of objects with the fields: "productType", "specificType", and "reason".
`;

    // Call OpenAI API
    console.log('Calling OpenAI API...');
    const openAIResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a financial advisor specializing in personalized banking product recommendations.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
      }),
    });

    if (!openAIResponse.ok) {
      const errorData = await openAIResponse.json();
      console.error('OpenAI API error:', errorData);
      return new Response(
        JSON.stringify({ error: 'Failed to generate recommendations' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const openAIData = await openAIResponse.json();
    const recommendationsText = openAIData.choices[0].message.content;
    
    // Parse the JSON from the response
    let recommendations;
    try {
      recommendations = JSON.parse(recommendationsText);
    } catch (error) {
      console.error('Error parsing OpenAI response:', error);
      console.log('Raw response:', recommendationsText);
      
      // Try to extract JSON using regex as a fallback
      const jsonMatch = recommendationsText.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        try {
          recommendations = JSON.parse(jsonMatch[0]);
        } catch (e) {
          console.error('Failed to extract JSON with regex');
          return new Response(
            JSON.stringify({ error: 'Failed to parse recommendations' }),
            { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }
      } else {
        return new Response(
          JSON.stringify({ error: 'Invalid response format from AI' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Store recommendations in Supabase
    // First, delete any existing recommendations for this user
    await supabase
      .from('user_recommendations')
      .delete()
      .eq('user_id', userId);
    
    // Insert new recommendations
    for (const rec of recommendations) {
      await supabase
        .from('user_recommendations')
        .insert({
          user_id: userId,
          recommended_product: `${rec.productType}: ${rec.specificType}`,
          recommendation_reason: rec.reason,
        });
    }

    // Return the recommendations
    return new Response(
      JSON.stringify({ recommendations }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in generate-recommendations function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
