
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { useRiskAssessment } from "./risk-assessment/useRiskAssessment";
import ProfilesList from "./risk-assessment/ProfilesList";
import LoadingState from "./risk-assessment/LoadingState";
import EmptyState from "./risk-assessment/EmptyState";
import AssessmentDetailsDialog from "./risk-assessment/AssessmentDetailsDialog";

const RiskAssessment = () => {
  const {
    profiles,
    loading,
    assessingId,
    detailsOpen,
    selectedAssessment,
    setDetailsOpen,
    fetchProfiles,
    assessRisk,
    showAssessmentDetails
  } = useRiskAssessment();

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Risk Assessment</CardTitle>
          <CardDescription>
            User risk profiles analyzed by AI
          </CardDescription>
        </div>
        <Button onClick={fetchProfiles} variant="outline" size="icon">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <LoadingState />
        ) : profiles.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="overflow-x-auto">
            <ProfilesList 
              profiles={profiles}
              onAssessRisk={assessRisk}
              onViewDetails={showAssessmentDetails}
              assessingId={assessingId}
            />
          </div>
        )}

        <AssessmentDetailsDialog 
          open={detailsOpen} 
          onOpenChange={setDetailsOpen} 
          assessment={selectedAssessment} 
        />
      </CardContent>
    </Card>
  );
};

export default RiskAssessment;
