
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Globe, ArrowRightLeft, Building2, DollarSign, Euro, PoundSterling, Circle, Bitcoin, ArrowLeft, BadgePercent, Calendar, CalendarClock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const InternationalTransfers = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("send");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showExchangeDetails, setShowExchangeDetails] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState("USD");
  const [transferAmount, setTransferAmount] = useState("");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [transferDetails, setTransferDetails] = useState<any>(null);
  const [trackingId, setTrackingId] = useState("");
  const [feeWaived, setFeeWaived] = useState(false);

  // Exchange Rates
  const currencies = [
    { code: "USD", name: "US Dollar", symbol: "$", icon: <DollarSign size={16} className="text-green-600" />, rate: 82.75, trend: "up", change: 0.15 },
    { code: "EUR", name: "Euro", symbol: "€", icon: <Euro size={16} className="text-blue-600" />, rate: 90.25, trend: "down", change: 0.22 },
    { code: "GBP", name: "British Pound", symbol: "£", icon: <PoundSterling size={16} className="text-purple-600" />, rate: 105.50, trend: "up", change: 0.30 },
    { code: "JPY", name: "Japanese Yen", symbol: "¥", icon: <Circle size={16} className="text-red-600" />, rate: 0.55, trend: "down", change: 0.01 },
    { code: "BTC", name: "Bitcoin", symbol: "₿", icon: <Bitcoin size={16} className="text-orange-600" />, rate: 5432165.45, trend: "up", change: 4521.75 }
  ];

  // Recent international transactions
  const internationalTransactions = [
    { 
      id: 1, 
      type: "sent", 
      amount: 1250, 
      currency: "USD", 
      recipientName: "John Smith", 
      recipientBank: "Chase Bank, USA", 
      date: "15 May 2023",
      status: "Completed",
      fees: 250,
      exchangeRate: 82.45,
      trackingNumber: "ITX78945612"
    },
    { 
      id: 2, 
      type: "received", 
      amount: 2000, 
      currency: "EUR", 
      senderName: "Maria Garcia", 
      senderBank: "Santander, Spain", 
      date: "02 Jun 2023",
      status: "Completed",
      fees: 0,
      exchangeRate: 90.12,
      trackingNumber: "ITX65478932"
    },
    { 
      id: 3, 
      type: "sent", 
      amount: 500, 
      currency: "GBP", 
      recipientName: "Robert Johnson", 
      recipientBank: "Barclays, UK", 
      date: "10 Jun 2023",
      status: "Processing",
      fees: 150,
      exchangeRate: 105.30,
      trackingNumber: "ITX32145698"
    }
  ];

  // Popular Destinations
  const popularDestinations = [
    { country: "United States", currency: "USD", flag: "🇺🇸", fee: "₹250" },
    { country: "United Kingdom", currency: "GBP", flag: "🇬🇧", fee: "₹300" },
    { country: "European Union", currency: "EUR", flag: "🇪🇺", fee: "₹250" },
    { country: "Canada", currency: "CAD", flag: "🇨🇦", fee: "₹250" },
    { country: "Australia", currency: "AUD", flag: "🇦🇺", fee: "₹300" },
    { country: "Singapore", currency: "SGD", flag: "🇸🇬", fee: "₹200" },
  ];

  // Recent Recipients
  const recentRecipients = [
    { id: 1, name: "John Smith", country: "USA", bank: "Chase Bank", accountNumber: "****4523", lastUsed: "2 weeks ago" },
    { id: 2, name: "Maria Garcia", country: "Spain", bank: "Santander", accountNumber: "****9876", lastUsed: "1 month ago" },
    { id: 3, name: "Robert Johnson", country: "UK", bank: "Barclays", accountNumber: "****3210", lastUsed: "3 months ago" },
  ];

  const handleSendMoney = (event: React.FormEvent) => {
    event.preventDefault();
    setIsProcessing(true);
    
    const formData = new FormData(event.target as HTMLFormElement);
    const formValues = Object.fromEntries(formData.entries());
    
    // Generate a random tracking number
    const newTrackingId = "ITX" + Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    setTrackingId(newTrackingId);
    
    const selectedCurrencyObj = currencies.find(c => c.code === formValues.currency);
    const exchangeRate = selectedCurrencyObj ? selectedCurrencyObj.rate : 82.75;
    
    const transferData = {
      recipientName: formValues.recipientName,
      bankName: formValues.bankName,
      accountNumber: formValues.accountNumber,
      swiftCode: formValues.swiftCode,
      amount: formValues.amount,
      currency: formValues.currency,
      exchangeRate: exchangeRate,
      fees: feeWaived ? 0 : 250,
      totalAmount: Number(formValues.amount) * exchangeRate + (feeWaived ? 0 : 250),
      trackingNumber: newTrackingId,
      estimatedDelivery: "1-2 business days"
    };
    
    setTransferDetails(transferData);
    
    // Simulate API call
    setTimeout(() => {
      setIsProcessing(false);
      setShowConfirmation(true);
    }, 2000);
  };

  const confirmTransfer = () => {
    toast({
      title: "Transfer Initiated",
      description: `Your international money transfer of ${transferDetails.currency} ${transferDetails.amount} has been initiated successfully. Tracking ID: ${trackingId}`,
    });
    setShowConfirmation(false);
    
    // Reset form
    const form = document.getElementById("sendMoneyForm") as HTMLFormElement;
    if (form) form.reset();
    
    // Add to recent transactions
    const newTransaction = {
      id: internationalTransactions.length + 1,
      type: "sent",
      amount: Number(transferDetails.amount),
      currency: transferDetails.currency,
      recipientName: transferDetails.recipientName,
      recipientBank: `${transferDetails.bankName}`,
      date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      status: "Processing",
      fees: transferDetails.fees,
      exchangeRate: transferDetails.exchangeRate,
      trackingNumber: transferDetails.trackingNumber
    };
    
    // In a real app, we'd update the state with the new transaction
    // internationalTransactions.unshift(newTransaction);
  };

  const handleTrackTransfer = () => {
    if (!trackingId.trim()) {
      toast({
        title: "Error",
        description: "Please enter a valid tracking ID",
        variant: "destructive"
      });
      return;
    }
    
    // Find transaction with matching tracking ID
    const transaction = internationalTransactions.find(tx => tx.trackingNumber === trackingId);
    
    if (transaction) {
      toast({
        title: "Transfer Found",
        description: `${transaction.currency} ${transaction.amount} to ${transaction.recipientName}. Status: ${transaction.status}`,
      });
    } else {
      toast({
        title: "Tracking Transfer",
        description: "Simulating tracking for ID: " + trackingId,
      });
      
      setTimeout(() => {
        toast({
          title: "Transfer Status",
          description: "Your transfer is being processed. Estimated completion: 1-2 business days.",
        });
      }, 1500);
    }
  };

  const handleCurrencyChange = (currency: string) => {
    setSelectedCurrency(currency);
    
    toast({
      title: "Currency Selected",
      description: `Selected ${currencies.find(c => c.code === currency)?.name} for your transfer.`,
    });
  };

  const handleSelectRecipient = (recipient: typeof recentRecipients[0]) => {
    const form = document.getElementById("sendMoneyForm") as HTMLFormElement;
    if (form) {
      const elements = form.elements as HTMLFormControlsCollection & {
        recipientName: HTMLInputElement;
        bankName: HTMLInputElement;
        accountNumber: HTMLInputElement;
      };
      
      elements.recipientName.value = recipient.name;
      elements.bankName.value = recipient.bank;
      elements.accountNumber.value = recipient.accountNumber;
      
      toast({
        title: "Recipient Selected",
        description: `Selected ${recipient.name} as your transfer recipient.`,
      });
    }
  };

  const toggleFeeWaiver = () => {
    setFeeWaived(!feeWaived);
    toast({
      title: feeWaived ? "Fee Waiver Removed" : "Fee Waiver Applied",
      description: feeWaived ? "Standard transaction fee will be applied." : "Transaction fee has been waived for this transfer!",
    });
  };

  const handleDestinationSelect = (destination: typeof popularDestinations[0]) => {
    setActiveTab("send");
    
    // If we had a form reference, we would set the country value here
    toast({
      title: "Destination Selected",
      description: `Selected ${destination.country} as your transfer destination.`,
    });
    
    // Find the currency associated with this destination
    const currency = currencies.find(c => c.code === destination.currency);
    if (currency) {
      setSelectedCurrency(currency.code);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <Button 
            variant="outline" 
            size="sm" 
            className="mb-2"
            onClick={() => navigate("/dashboard")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-vyom-blue">International Transfers</h1>
          <p className="text-vyom-gray">Send and receive money globally with competitive exchange rates</p>
        </div>
        <div className="hidden md:block">
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-vyom-gray">Exchange Rate Updates</p>
              <p className="text-sm font-medium">Last updated: Today, 10:45 AM</p>
            </div>
            <Button 
              variant="outline"
              onClick={() => {
                toast({
                  title: "Rates Refreshed",
                  description: "Exchange rates have been updated to the latest values.",
                });
              }}
            >
              Refresh Rates
            </Button>
          </div>
        </div>
      </div>
      
      <Tabs defaultValue="send" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-3 max-w-[500px]">
          <TabsTrigger value="send">Send Money</TabsTrigger>
          <TabsTrigger value="track">Track Transfer</TabsTrigger>
          <TabsTrigger value="convert">Currency Converter</TabsTrigger>
        </TabsList>
        
        <TabsContent value="send" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="shadow-md overflow-hidden">
                <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-purple" />
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-vyom-purple" />
                    <CardTitle>International Money Transfer</CardTitle>
                  </div>
                  <CardDescription>Send money to recipients worldwide with competitive exchange rates</CardDescription>
                </CardHeader>
                <CardContent>
                  <form id="sendMoneyForm" onSubmit={handleSendMoney} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fromAccount">From Account</Label>
                        <Select name="fromAccount" defaultValue="savings">
                          <SelectTrigger id="fromAccount">
                            <SelectValue placeholder="Select Account" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="savings">Savings Account (₹157,892.45)</SelectItem>
                            <SelectItem value="current">Current Account (₹245,630.20)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="country">Recipient Country</Label>
                        <Select name="country" defaultValue="usa">
                          <SelectTrigger id="country">
                            <SelectValue placeholder="Select Country" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="usa">United States</SelectItem>
                            <SelectItem value="uk">United Kingdom</SelectItem>
                            <SelectItem value="eu">European Union</SelectItem>
                            <SelectItem value="uae">United Arab Emirates</SelectItem>
                            <SelectItem value="sg">Singapore</SelectItem>
                            <SelectItem value="aus">Australia</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="bankName">Bank Name</Label>
                        <Input id="bankName" name="bankName" placeholder="Recipient's Bank Name" />
                      </div>
                      
                      <div>
                        <Label htmlFor="swiftCode">SWIFT/BIC Code</Label>
                        <Input id="swiftCode" name="swiftCode" placeholder="SWIFT or BIC Code" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="accountNumber">Account Number / IBAN</Label>
                        <Input id="accountNumber" name="accountNumber" placeholder="Recipient's Account Number" />
                      </div>
                      
                      <div>
                        <Label htmlFor="recipientName">Recipient Name</Label>
                        <Input id="recipientName" name="recipientName" placeholder="Full Name of Recipient" />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="currency">Currency</Label>
                        <Select name="currency" value={selectedCurrency} onValueChange={handleCurrencyChange}>
                          <SelectTrigger id="currency">
                            <SelectValue placeholder="Select Currency" />
                          </SelectTrigger>
                          <SelectContent>
                            {currencies.map(currency => (
                              <SelectItem key={currency.code} value={currency.code}>
                                <div className="flex items-center">
                                  {currency.icon}
                                  <span className="ml-2">{currency.code} - {currency.name}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label htmlFor="amount">Amount</Label>
                        <Input 
                          id="amount" 
                          name="amount" 
                          type="number" 
                          placeholder="Enter amount" 
                          value={transferAmount}
                          onChange={(e) => setTransferAmount(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="purpose">Purpose of Transfer</Label>
                      <Select name="purpose" defaultValue="family">
                        <SelectTrigger id="purpose">
                          <SelectValue placeholder="Select Purpose" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="family">Family Support</SelectItem>
                          <SelectItem value="education">Education Expenses</SelectItem>
                          <SelectItem value="medical">Medical Expenses</SelectItem>
                          <SelectItem value="travel">Travel Expenses</SelectItem>
                          <SelectItem value="business">Business Payment</SelectItem>
                          <SelectItem value="investment">Investment</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-100 text-sm space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width="16"
                            height="16"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            className="text-vyom-blue"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <line x1="12" y1="16" x2="12" y2="12" />
                            <line x1="12" y1="8" x2="12.01" y2="8" />
                          </svg>
                          <span className="font-medium text-vyom-blue">Transfer Information</span>
                        </div>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm" 
                          className="h-7 text-xs"
                          onClick={() => setShowExchangeDetails(!showExchangeDetails)}
                        >
                          {showExchangeDetails ? "Hide Details" : "Show Details"}
                        </Button>
                      </div>
                      
                      <p>Exchange Rate: 1 {selectedCurrency} = ₹{currencies.find(c => c.code === selectedCurrency)?.rate.toFixed(2) || "82.75"}</p>
                      <p>Estimated Fees: {feeWaived ? "₹0.00 (Waived)" : "₹250.00"}</p>
                      <p>Estimated Delivery: 1-2 business days</p>
                      
                      {showExchangeDetails && (
                        <>
                          <Separator className="my-2" />
                          <div className="space-y-1 pt-1">
                            <div className="flex justify-between text-xs">
                              <span>Amount in {selectedCurrency}:</span>
                              <span>{selectedCurrency} {transferAmount || "0.00"}</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Converted Amount:</span>
                              <span>₹{transferAmount ? (parseFloat(transferAmount) * (currencies.find(c => c.code === selectedCurrency)?.rate || 82.75)).toFixed(2) : "0.00"}</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span>Fees:</span>
                              <span>{feeWaived ? "₹0.00 (Waived)" : "₹250.00"}</span>
                            </div>
                            <Separator className="my-1" />
                            <div className="flex justify-between font-medium">
                              <span>Total Amount:</span>
                              <span>₹{transferAmount ? ((parseFloat(transferAmount) * (currencies.find(c => c.code === selectedCurrency)?.rate || 82.75)) + (feeWaived ? 0 : 250)).toFixed(2) : "0.00"}</span>
                            </div>
                          </div>
                        </>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <input 
                        type="checkbox" 
                        id="applyOffer" 
                        checked={feeWaived} 
                        onChange={toggleFeeWaiver} 
                        className="h-4 w-4 rounded border-gray-300 text-vyom-blue focus:ring-vyom-blue"
                      />
                      <Label htmlFor="applyOffer" className="text-sm cursor-pointer">
                        Apply Zero Fee Offer (2 of 3 remaining)
                      </Label>
                    </div>
                    
                    <div className="flex justify-end space-x-3">
                      <Button 
                        variant="outline" 
                        type="button"
                        onClick={() => {
                          const form = document.getElementById("sendMoneyForm") as HTMLFormElement;
                          if (form) form.reset();
                          setTransferAmount("");
                          setFeeWaived(false);
                          toast({
                            title: "Form Reset",
                            description: "The transfer form has been reset.",
                          });
                        }}
                      >
                        Reset Form
                      </Button>
                      <Button type="submit" variant="international" disabled={isProcessing}>
                        {isProcessing ? "Processing..." : "Send Money"}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
              
              <Card className="shadow-md overflow-hidden mt-6">
                <div className="h-1 bg-gradient-to-r from-vyom-purple to-vyom-teal" />
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <ArrowRightLeft className="h-5 w-5 text-vyom-teal" />
                    <CardTitle>Recent International Transactions</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {internationalTransactions.map(transaction => (
                      <div key={transaction.id} className="p-4 rounded-lg border hover:border-vyom-purple/30 hover:bg-vyom-light/50 transition-all duration-200">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant="outline" 
                                className={`${
                                  transaction.type === 'sent' 
                                    ? 'bg-blue-50 text-blue-600 border-blue-200' 
                                    : 'bg-green-50 text-green-600 border-green-200'
                                }`}
                              >
                                {transaction.type === 'sent' ? 'Sent' : 'Received'}
                              </Badge>
                              <Badge 
                                variant="outline" 
                                className={`${
                                  transaction.status === 'Completed' 
                                    ? 'bg-green-50 text-green-600 border-green-200' 
                                    : 'bg-amber-50 text-amber-600 border-amber-200'
                                }`}
                              >
                                {transaction.status}
                              </Badge>
                            </div>
                            <h3 className="font-medium mt-2">{
                              transaction.type === 'sent' 
                                ? `To: ${transaction.recipientName}` 
                                : `From: ${transaction.senderName}`
                            }</h3>
                            <p className="text-sm text-vyom-gray">{
                              transaction.type === 'sent' 
                                ? transaction.recipientBank 
                                : transaction.senderBank
                            }</p>
                            <p className="text-xs text-vyom-gray">Tracking ID: {transaction.trackingNumber}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold">{transaction.currency} {transaction.amount.toLocaleString()}</p>
                            <p className="text-sm text-vyom-gray">≈ ₹{(transaction.amount * transaction.exchangeRate).toLocaleString()}</p>
                            <p className="text-xs text-vyom-gray">{transaction.date}</p>
                          </div>
                        </div>
                        <div className="mt-3 text-sm">
                          <div className="flex justify-between text-vyom-gray">
                            <span>Exchange Rate:</span>
                            <span>1 {transaction.currency} = ₹{transaction.exchangeRate.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-vyom-gray">
                            <span>Fees:</span>
                            <span>₹{transaction.fees.toLocaleString()}</span>
                          </div>
                        </div>
                        <div className="mt-3 flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-xs"
                            onClick={() => {
                              toast({
                                title: "View Receipt",
                                description: `Viewing receipt for ${transaction.currency} ${transaction.amount} transaction`,
                              });
                            }}
                          >
                            View Receipt
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-xs"
                            onClick={() => {
                              setTrackingId(transaction.trackingNumber);
                              setActiveTab("track");
                              toast({
                                title: "Track Transfer",
                                description: `Tracking transfer with ID: ${transaction.trackingNumber}`,
                              });
                            }}
                          >
                            Track Transfer
                          </Button>
                          {transaction.type === 'sent' && (
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={() => {
                                setActiveTab("send");
                                // Prefill the form with the recipient details
                                const form = document.getElementById("sendMoneyForm") as HTMLFormElement;
                                if (form) {
                                  const elements = form.elements as HTMLFormControlsCollection & {
                                    recipientName: HTMLInputElement;
                                    amount: HTMLInputElement;
                                    currency: HTMLSelectElement;
                                  };
                                  
                                  elements.recipientName.value = transaction.recipientName;
                                  setSelectedCurrency(transaction.currency);
                                }
                                
                                toast({
                                  title: "Repeat Transfer",
                                  description: `Setting up repeat transfer to ${transaction.recipientName}`,
                                });
                              }}
                            >
                              Repeat Transfer
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        toast({
                          title: "View All Transactions",
                          description: "Loading your complete international transaction history...",
                        });
                      }}
                    >
                      View All International Transactions
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              <Card className="shadow-md bg-gradient-to-br from-vyom-light to-white">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Building2 className="h-5 w-5 text-vyom-purple" />
                    <CardTitle>Currency Exchange Rates</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {currencies.map(currency => (
                      <div 
                        key={currency.code} 
                        className="p-3 rounded-lg border hover:shadow-sm transition-all duration-200 cursor-pointer"
                        onClick={() => handleCurrencyChange(currency.code)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="p-2 rounded-full bg-gray-100">
                              {currency.icon}
                            </div>
                            <div>
                              <p className="text-sm font-medium">{currency.code}</p>
                              <p className="text-xs text-vyom-gray">{currency.name}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">₹{currency.rate.toFixed(2)}</p>
                            <p className={`text-xs ${currency.trend === 'up' ? 'text-vyom-green' : 'text-vyom-red'}`}>
                              {currency.trend === 'up' ? '▲' : '▼'} ₹{currency.change.toFixed(2)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setActiveTab("convert")}
                    >
                      Open Currency Converter
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-md">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-vyom-teal" />
                    <CardTitle>Popular Destinations</CardTitle>
                  </div>
                  <CardDescription>Countries with the best transfer rates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {popularDestinations.map((destination, index) => (
                      <div 
                        key={index} 
                        className="p-3 rounded-lg hover:bg-vyom-light/50 transition-all duration-200 cursor-pointer border"
                        onClick={() => handleDestinationSelect(destination)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{destination.flag}</span>
                            <div>
                              <p className="text-sm font-medium">{destination.country}</p>
                              <p className="text-xs text-vyom-gray">{destination.currency}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">Fee: {destination.fee}</p>
                            <p className="text-xs text-vyom-green">Fast transfer</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-md">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <CalendarClock className="h-5 w-5 text-vyom-blue" />
                    <CardTitle>Recent Recipients</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {recentRecipients.map(recipient => (
                      <div 
                        key={recipient.id} 
                        className="p-3 rounded-lg hover:bg-vyom-light/50 transition-all duration-200 cursor-pointer border"
                        onClick={() => handleSelectRecipient(recipient)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium">{recipient.name}</p>
                            <p className="text-xs text-vyom-gray">{recipient.bank}, {recipient.country}</p>
                            <p className="text-xs text-vyom-gray">Acc: {recipient.accountNumber}</p>
                          </div>
                          <div className="text-right">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSelectRecipient(recipient);
                              }}
                            >
                              Transfer
                            </Button>
                            <p className="text-xs text-vyom-gray mt-1">{recipient.lastUsed}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        toast({
                          title: "Add New Recipient",
                          description: "Opening form to add a new recipient...",
                        });
                      }}
                    >
                      Add New Recipient
                    </Button>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="shadow-md bg-gradient-to-br from-blue-50 to-purple-50 border-none overflow-hidden">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="bg-white p-3 rounded-full shadow-sm">
                      <BadgePercent className="text-vyom-purple h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-medium">Special Offer</h3>
                      <p className="text-sm text-vyom-gray">International Transfers</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h3 className="font-medium text-vyom-purple">Zero Fee Transfers</h3>
                    <p className="text-sm">Send money internationally with zero transfer fees for your first 3 transactions this month.</p>
                    
                    <div className="bg-white p-3 rounded-lg text-sm space-y-1">
                      <div className="flex justify-between">
                        <span>Offer Valid Till:</span>
                        <span className="font-medium">30 Jun 2023</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Used:</span>
                        <span>1 of 3</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Remaining:</span>
                        <span className="font-medium text-vyom-green">2</span>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full bg-gradient-to-r from-vyom-purple to-vyom-blue text-white hover:shadow-lg"
                      onClick={toggleFeeWaiver}
                    >
                      {feeWaived ? "Remove Fee Waiver" : "Use Offer Now"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="track" className="space-y-6">
          <Card className="shadow-md overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-purple" />
            <CardHeader>
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-vyom-purple" />
                <CardTitle>Track Your International Transfer</CardTitle>
              </div>
              <CardDescription>Follow the status of your international money transfer</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="trackingId">Transfer Tracking ID</Label>
                      <div className="flex gap-2">
                        <Input 
                          id="trackingId" 
                          placeholder="Enter tracking ID (e.g., ITX12345678)" 
                          value={trackingId}
                          onChange={(e) => setTrackingId(e.target.value)}
                        />
                        <Button onClick={handleTrackTransfer}>Track</Button>
                      </div>
                      <p className="text-sm text-vyom-gray">Enter the tracking ID you received when initiating the transfer</p>
                    </div>
                    
                    {trackingId && (
                      <div className="p-4 rounded-lg border shadow-sm bg-white">
                        <h3 className="font-medium text-vyom-blue">Transfer Details</h3>
                        <div className="mt-2 space-y-1">
                          <div className="flex justify-between">
                            <span className="text-sm">Status:</span>
                            <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">Processing</Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Initiated:</span>
                            <span className="text-sm">Today, 15:30</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Expected Completion:</span>
                            <span className="text-sm">In 1-2 business days</span>
                          </div>
                        </div>
                        
                        <div className="mt-4">
                          <h4 className="text-sm font-medium mb-2">Transfer Progress</h4>
                          <div className="space-y-3">
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="flex items-center gap-1">
                                  <Badge className="h-2 w-2 p-0 rounded-full bg-green-500" />
                                  Transfer Initiated
                                </span>
                                <span className="text-xs">Today, 15:30</span>
                              </div>
                              <Progress value={100} className="h-1.5" />
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="flex items-center gap-1">
                                  <Badge className="h-2 w-2 p-0 rounded-full bg-green-500" />
                                  Funds Verified
                                </span>
                                <span className="text-xs">Today, 15:35</span>
                              </div>
                              <Progress value={100} className="h-1.5" />
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="flex items-center gap-1">
                                  <Badge className="h-2 w-2 p-0 rounded-full bg-amber-500" />
                                  Processing Transfer
                                </span>
                                <span className="text-xs">In Progress</span>
                              </div>
                              <Progress value={50} className="h-1.5" />
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="flex items-center gap-1">
                                  <Badge className="h-2 w-2 p-0 rounded-full bg-gray-300" />
                                  Recipient Bank Processing
                                </span>
                                <span className="text-xs">Pending</span>
                              </div>
                              <Progress value={0} className="h-1.5" />
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span className="flex items-center gap-1">
                                  <Badge className="h-2 w-2 p-0 rounded-full bg-gray-300" />
                                  Funds Delivered
                                </span>
                                <span className="text-xs">Pending</span>
                              </div>
                              <Progress value={0} className="h-1.5" />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-3 border-t pt-4 mt-4">
                      <div className="p-2 rounded-full bg-blue-50">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-vyom-blue">
                          <circle cx="12" cy="12" r="10" />
                          <line x1="12" y1="16" x2="12" y2="12" />
                          <line x1="12" y1="8" x2="12.01" y2="8" />
                        </svg>
                      </div>
                      <p className="text-sm text-vyom-gray">
                        Having trouble with your transfer? Contact our <span className="text-vyom-blue font-medium">24/7 International Transfer Support</span> team.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h3 className="font-medium mb-3">Recent Transfers</h3>
                  <div className="space-y-3">
                    {internationalTransactions.map(transaction => (
                      <div 
                        key={transaction.id} 
                        className="flex items-start gap-3 p-2 hover:bg-accent rounded-md cursor-pointer border"
                        onClick={() => {
                          setTrackingId(transaction.trackingNumber);
                          handleTrackTransfer();
                        }}
                      >
                        <div className="mt-1 p-1.5 rounded-full bg-gray-100">
                          <ArrowRightLeft size={14} className={transaction.type === 'sent' ? 'text-blue-600' : 'text-green-600'} />
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {transaction.type === 'sent' ? `To: ${transaction.recipientName}` : `From: ${transaction.senderName}`}
                          </p>
                          <p className="text-xs text-vyom-gray">{transaction.currency} {transaction.amount}</p>
                          <p className="text-xs text-vyom-gray">{transaction.trackingNumber}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="convert" className="space-y-6">
          <Card className="shadow-md overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-vyom-teal to-vyom-purple" />
            <CardHeader>
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="h-5 w-5 text-vyom-teal" />
                <CardTitle>Currency Converter</CardTitle>
              </div>
              <CardDescription>Get real-time exchange rates between currencies</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fromCurrency">From Currency</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Select defaultValue="INR">
                            <SelectTrigger id="fromCurrency" className="flex-1">
                              <SelectValue placeholder="Select Currency" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="INR">INR - Indian Rupee</SelectItem>
                              {currencies.map(currency => (
                                <SelectItem key={currency.code} value={currency.code}>
                                  {currency.code} - {currency.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Input placeholder="Amount" defaultValue="1000" />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="toCurrency">To Currency</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Select defaultValue="USD">
                            <SelectTrigger id="toCurrency" className="flex-1">
                              <SelectValue placeholder="Select Currency" />
                            </SelectTrigger>
                            <SelectContent>
                              {currencies.map(currency => (
                                <SelectItem key={currency.code} value={currency.code}>
                                  {currency.code} - {currency.name}
                                </SelectItem>
                              ))}
                              <SelectItem value="INR">INR - Indian Rupee</SelectItem>
                            </SelectContent>
                          </Select>
                          <Input placeholder="Converted Amount" value="12.08" readOnly />
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2 mx-auto"
                      onClick={() => {
                        toast({
                          title: "Currencies Swapped",
                          description: "The currencies have been swapped.",
                        });
                      }}
                    >
                      <ArrowRightLeft size={16} />
                      <span>Swap Currencies</span>
                    </Button>
                    
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                      <div className="flex justify-between mb-2">
                        <span className="font-medium">Conversion Details</span>
                        <Badge variant="outline" className="bg-blue-100">Live Rate</Badge>
                      </div>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>Exchange Rate:</span>
                          <span>1 INR = 0.01208 USD</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Inverse Rate:</span>
                          <span>1 USD = 82.75 INR</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Last Updated:</span>
                          <span>Today, 10:45 AM</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-3">
                      <Button 
                        variant="outline"
                        onClick={() => {
                          toast({
                            title: "Chart View",
                            description: "Opening exchange rate chart view...",
                          });
                        }}
                      >
                        View Exchange Rate Chart
                      </Button>
                      <Button 
                        variant="international"
                        onClick={() => {
                          setActiveTab("send");
                          toast({
                            title: "Transfer This Amount",
                            description: "Setting up a new transfer with this amount...",
                          });
                        }}
                      >
                        Transfer This Amount
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <h3 className="font-medium mb-3">Popular Conversions</h3>
                    <div className="space-y-2">
                      {[
                        { from: "INR", to: "USD", rate: "0.01208", inverse: "82.75" },
                        { from: "INR", to: "EUR", rate: "0.01107", inverse: "90.25" },
                        { from: "INR", to: "GBP", rate: "0.00948", inverse: "105.50" }
                      ].map((conversion, index) => (
                        <div 
                          key={index}
                          className="p-2 hover:bg-accent rounded-md cursor-pointer"
                          onClick={() => {
                            toast({
                              title: "Conversion Selected",
                              description: `Selected ${conversion.from} to ${conversion.to} conversion.`,
                            });
                          }}
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-sm">1 {conversion.from} = {conversion.rate} {conversion.to}</span>
                            <ArrowRightLeft size={14} className="text-vyom-gray" />
                          </div>
                          <div className="text-xs text-vyom-gray">
                            1 {conversion.to} = {conversion.inverse} {conversion.from}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <Card className="shadow-sm bg-gradient-to-br from-vyom-light to-white">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Calendar className="h-5 w-5 text-vyom-purple" />
                        <h3 className="font-medium">Historical Rates</h3>
                      </div>
                      <p className="text-sm text-vyom-gray mb-3">
                        Track how exchange rates have changed over time.
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          toast({
                            title: "Historical Rates",
                            description: "Opening historical exchange rate chart...",
                          });
                        }}
                      >
                        View Rate History
                      </Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="shadow-sm bg-gradient-to-br from-blue-50 to-white">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <BadgePercent className="h-5 w-5 text-vyom-blue" />
                        <h3 className="font-medium">Exchange Rate Alerts</h3>
                      </div>
                      <p className="text-sm text-vyom-gray mb-3">
                        Get notified when exchange rates hit your target.
                      </p>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => {
                          toast({
                            title: "Rate Alert",
                            description: "Setting up an exchange rate alert...",
                          });
                        }}
                      >
                        Set Rate Alert
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Confirmation Dialog */}
      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Confirm International Transfer</DialogTitle>
            <DialogDescription>
              Please review the details of your transfer before confirming.
            </DialogDescription>
          </DialogHeader>
          
          {transferDetails && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <h3 className="font-medium">Transfer Details</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="text-vyom-gray">Recipient:</div>
                  <div>{transferDetails.recipientName}</div>
                  
                  <div className="text-vyom-gray">Bank:</div>
                  <div>{transferDetails.bankName}</div>
                  
                  <div className="text-vyom-gray">Account:</div>
                  <div>{transferDetails.accountNumber}</div>
                  
                  <div className="text-vyom-gray">SWIFT/BIC:</div>
                  <div>{transferDetails.swiftCode}</div>
                  
                  <div className="text-vyom-gray">Amount:</div>
                  <div>{transferDetails.currency} {transferDetails.amount}</div>
                  
                  <div className="text-vyom-gray">Exchange Rate:</div>
                  <div>1 {transferDetails.currency} = ₹{transferDetails.exchangeRate.toFixed(2)}</div>
                  
                  <div className="text-vyom-gray">Fees:</div>
                  <div>{transferDetails.fees === 0 ? "₹0.00 (Waived)" : `₹${transferDetails.fees.toFixed(2)}`}</div>
                  
                  <div className="text-vyom-gray">Total Amount (INR):</div>
                  <div className="font-medium">₹{transferDetails.totalAmount.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="bg-amber-50 p-3 rounded-md text-sm border border-amber-100">
                <p className="flex items-center gap-1">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-amber-600">
                    <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" />
                    <path d="M12 9v4" />
                    <path d="M12 17h.01" />
                  </svg>
                  <span className="font-medium text-amber-700">Important</span>
                </p>
                <p className="text-amber-700 mt-1">
                  Transfers typically take 1-2 business days to complete. Make sure all details are correct before confirming.
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="confirmDetails" 
                  className="h-4 w-4 rounded border-gray-300 text-vyom-blue focus:ring-vyom-blue" 
                />
                <Label htmlFor="confirmDetails" className="text-sm">
                  I confirm that all details are correct
                </Label>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmation(false)}>Cancel</Button>
            <Button 
              variant="international"
              onClick={confirmTransfer}
            >
              Confirm Transfer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default InternationalTransfers;
