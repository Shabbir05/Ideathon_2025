
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { FileCheck, AlertTriangle, CheckCircle, User, Eye } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const AdminVerification = () => {
  const handleViewUser = (userId: string) => {
    toast({
      title: "Viewing User",
      description: `Opening user profile for ${userId}`
    });
  };

  const handleVerificationAction = (userId: string, action: 'approve' | 'reject') => {
    toast({
      title: action === 'approve' ? "Verification Approved" : "Verification Rejected",
      description: `User ${userId} verification has been ${action === 'approve' ? 'approved' : 'rejected'}.`,
      variant: action === 'approve' ? "default" : "destructive"
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">User Verification Panel</h2>
          <p className="text-muted-foreground">Monitor and verify user identity documents</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge className="bg-green-100 text-green-800 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            23 Verified Today
          </Badge>
          <Badge className="bg-red-100 text-red-800 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            8 Rejected Today
          </Badge>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <FileCheck className="w-5 h-5 mr-2 text-green-500" />
              Pending Verification
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">17</div>
            <div className="text-sm text-vyom-gray mt-1">Documents awaiting verification</div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>Aadhaar Card</span>
                <span>8</span>
              </div>
              <Progress value={47} className="h-1" />
              <div className="flex justify-between items-center text-sm">
                <span>PAN Card</span>
                <span>5</span>
              </div>
              <Progress value={29} className="h-1" />
              <div className="flex justify-between items-center text-sm">
                <span>Address Proof</span>
                <span>4</span>
              </div>
              <Progress value={24} className="h-1" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
              High Risk Verifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">5</div>
            <div className="text-sm text-vyom-gray mt-1">Flagged due to anomalies</div>
            <div className="mt-4 space-y-3">
              <div className="flex justify-between items-center text-sm border-b pb-2">
                <span>Document tampering</span>
                <Badge className="bg-red-100 text-red-800">2</Badge>
              </div>
              <div className="flex justify-between items-center text-sm border-b pb-2">
                <span>Multiple address changes</span>
                <Badge className="bg-orange-100 text-orange-800">2</Badge>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span>Name mismatch</span>
                <Badge className="bg-yellow-100 text-yellow-800">1</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <CheckCircle className="w-5 h-5 mr-2 text-blue-500" />
              Verification Performance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">96.7%</div>
            <div className="text-sm text-vyom-gray mt-1">Accuracy rate</div>
            <div className="mt-4 space-y-3">
              <div className="flex justify-between items-center text-sm border-b pb-2">
                <span>Average time</span>
                <span className="font-medium">1.5 hours</span>
              </div>
              <div className="flex justify-between items-center text-sm border-b pb-2">
                <span>Rejections</span>
                <span className="font-medium">8.3%</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span>Processing now</span>
                <Badge className="bg-blue-100 text-blue-800">3 docs</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Pending KYC Verifications</CardTitle>
          <CardDescription>
            User identity documents requiring verification
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Document Type</TableHead>
                <TableHead>Submission Date</TableHead>
                <TableHead>Risk Score</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">ID56789</TableCell>
                <TableCell>Rajesh Kumar</TableCell>
                <TableCell>Aadhaar Card</TableCell>
                <TableCell>Today, 08:32 AM</TableCell>
                <TableCell>
                  <Badge className="bg-red-100 text-red-800">High (82/100)</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUser("ID56789")}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleVerificationAction("ID56789", "reject")}>
                      Reject
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleVerificationAction("ID56789", "approve")}>
                      Approve
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
              
              <TableRow>
                <TableCell className="font-medium">ID67890</TableCell>
                <TableCell>Neha Singh</TableCell>
                <TableCell>PAN Card</TableCell>
                <TableCell>Today, 09:15 AM</TableCell>
                <TableCell>
                  <Badge className="bg-green-100 text-green-800">Low (24/100)</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUser("ID67890")}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleVerificationAction("ID67890", "reject")}>
                      Reject
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleVerificationAction("ID67890", "approve")}>
                      Approve
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
              
              <TableRow>
                <TableCell className="font-medium">ID78901</TableCell>
                <TableCell>Sanjay Patel</TableCell>
                <TableCell>Address Proof</TableCell>
                <TableCell>Yesterday, 4:45 PM</TableCell>
                <TableCell>
                  <Badge className="bg-yellow-100 text-yellow-800">Medium (58/100)</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUser("ID78901")}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleVerificationAction("ID78901", "reject")}>
                      Reject
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleVerificationAction("ID78901", "approve")}>
                      Approve
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
              
              <TableRow>
                <TableCell className="font-medium">ID89012</TableCell>
                <TableCell>Priya Mehta</TableCell>
                <TableCell>Aadhaar Card</TableCell>
                <TableCell>Yesterday, 3:10 PM</TableCell>
                <TableCell>
                  <Badge className="bg-orange-100 text-orange-800">Medium (67/100)</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUser("ID89012")}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleVerificationAction("ID89012", "reject")}>
                      Reject
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleVerificationAction("ID89012", "approve")}>
                      Approve
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
              
              <TableRow>
                <TableCell className="font-medium">ID90123</TableCell>
                <TableCell>Vijay Sharma</TableCell>
                <TableCell>PAN Card</TableCell>
                <TableCell>Yesterday, 1:22 PM</TableCell>
                <TableCell>
                  <Badge className="bg-green-100 text-green-800">Low (32/100)</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUser("ID90123")}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="destructive" size="sm" onClick={() => handleVerificationAction("ID90123", "reject")}>
                      Reject
                    </Button>
                    <Button variant="default" size="sm" onClick={() => handleVerificationAction("ID90123", "approve")}>
                      Approve
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminVerification;
