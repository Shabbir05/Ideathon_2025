
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Footer from "@/components/Footer";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-vyom-light to-white">
      {/* Top Navigation */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-red flex items-center justify-center text-white font-bold text-xl">V</div>
            <span className="text-xl font-bold">Vyom</span>
          </Link>
          
          <Link to="/" className="flex items-center text-vyom-blue hover:text-vyom-red transition-colors duration-200">
            <ArrowLeft size={16} className="mr-2" />
            Back to Home
          </Link>
        </div>
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 py-12 flex-grow">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-vyom-blue">Privacy Policy</h1>
          
          <div className="prose prose-blue max-w-none">
            <p className="text-vyom-gray mb-6">Last Updated: {new Date().toLocaleDateString()}</p>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Introduction</h2>
              <p className="mb-4">
                Vyom by Union Bank of India ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our digital banking platform.
              </p>
              <p>
                Please read this Privacy Policy carefully. By accessing or using our platform, you acknowledge that you have read, understood, and agree to be bound by all the terms of this Privacy Policy.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Information We Collect</h2>
              <p className="mb-4">We may collect the following categories of information:</p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Personal Identification Information (name, email address, phone number, etc.)</li>
                <li>Financial Information (account numbers, transaction history, credit information)</li>
                <li>Authentication Information (user credentials, security questions)</li>
                <li>Device and Usage Information (IP address, browser type, device identifiers)</li>
                <li>Location Information (with your consent)</li>
              </ul>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">How We Use Your Information</h2>
              <p className="mb-4">We may use the information we collect for various purposes, including:</p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Providing and maintaining our banking services</li>
                <li>Processing transactions and managing accounts</li>
                <li>Authenticating your identity and preventing fraud</li>
                <li>Communicating with you about your accounts and services</li>
                <li>Improving our platform and developing new features</li>
                <li>Complying with legal obligations and regulatory requirements</li>
              </ul>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Security of Your Information</h2>
              <p className="mb-4">
                We implement appropriate technical and organizational measures to protect your personal information from unauthorized access, disclosure, alteration, and destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Your Rights and Choices</h2>
              <p className="mb-4">
                Depending on your location, you may have certain rights regarding your personal information, such as:
              </p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Accessing, correcting, or deleting your personal information</li>
                <li>Restricting or objecting to our processing of your information</li>
                <li>Data portability</li>
                <li>Withdrawing consent (where processing is based on consent)</li>
              </ul>
              <p>
                To exercise these rights, please contact us using the information provided in the "Contact Us" section.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Changes to This Privacy Policy</h2>
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Contact Us</h2>
              <p>
                If you have questions or concerns about this Privacy Policy, please contact our Data Protection Officer at privacy@vyombank.in or write to us at Union Bank Headquarters, Mumbai, Maharashtra, India.
              </p>
            </section>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;
