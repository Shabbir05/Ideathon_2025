
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, CheckCircle, ArrowRight } from "lucide-react";
import { Link, useSearchParams } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

const ApplyOffer = () => {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const offerTitle = searchParams.get("title") || "Special Offer";
  
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Simulate form submission
    setTimeout(() => {
      setLoading(false);
      
      if (step < 3) {
        setStep(step + 1);
      } else {
        setCompleted(true);
        toast({
          title: "Application Submitted",
          description: "Your offer application has been submitted successfully!",
        });
      }
    }, 1500);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-vyom-blue mb-2">Apply for Offer</h1>
        <p className="text-muted-foreground mb-8">
          Complete the application process to avail {offerTitle}
        </p>
        
        {!completed ? (
          <>
            <div className="mb-8">
              <div className="flex items-center">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-white' : 'bg-accent text-muted-foreground'}`}>
                  {step > 1 ? <CheckCircle className="h-5 w-5" /> : "1"}
                </div>
                <div className={`h-1 flex-1 ${step > 1 ? 'bg-primary' : 'bg-accent'}`}></div>
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-white' : 'bg-accent text-muted-foreground'}`}>
                  {step > 2 ? <CheckCircle className="h-5 w-5" /> : "2"}
                </div>
                <div className={`h-1 flex-1 ${step > 2 ? 'bg-primary' : 'bg-accent'}`}></div>
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-primary text-white' : 'bg-accent text-muted-foreground'}`}>
                  3
                </div>
              </div>
              <div className="flex justify-between mt-2">
                <span className="text-sm font-medium">Personal Details</span>
                <span className="text-sm font-medium">Account Details</span>
                <span className="text-sm font-medium">Confirmation</span>
              </div>
            </div>
            
            <Card>
              {step === 1 && (
                <>
                  <CardHeader>
                    <CardTitle>Personal Details</CardTitle>
                    <CardDescription>
                      Provide your personal information to proceed with the offer application
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form id="step1Form" onSubmit={handleFormSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="firstName" className="text-sm font-medium">First Name</label>
                          <Input id="firstName" required />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="lastName" className="text-sm font-medium">Last Name</label>
                          <Input id="lastName" required />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="email" className="text-sm font-medium">Email Address</label>
                          <Input id="email" type="email" required />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="phone" className="text-sm font-medium">Mobile Number</label>
                          <Input id="phone" type="tel" required />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="address" className="text-sm font-medium">Address</label>
                        <Input id="address" required />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="city" className="text-sm font-medium">City</label>
                          <Input id="city" required />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="state" className="text-sm font-medium">State</label>
                          <Input id="state" required />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="pincode" className="text-sm font-medium">Pincode</label>
                          <Input id="pincode" required />
                        </div>
                      </div>
                    </form>
                  </CardContent>
                </>
              )}
              
              {step === 2 && (
                <>
                  <CardHeader>
                    <CardTitle>Account Details</CardTitle>
                    <CardDescription>
                      Provide your account information to apply for the offer
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form id="step2Form" onSubmit={handleFormSubmit} className="space-y-4">
                      <div className="space-y-2">
                        <label htmlFor="accountType" className="text-sm font-medium">Account Type</label>
                        <Select required defaultValue="savings">
                          <SelectTrigger>
                            <SelectValue placeholder="Select account type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="savings">Savings Account</SelectItem>
                            <SelectItem value="current">Current Account</SelectItem>
                            <SelectItem value="salary">Salary Account</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <label htmlFor="accountNumber" className="text-sm font-medium">Account Number</label>
                        <Input id="accountNumber" required />
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="employmentType" className="text-sm font-medium">Employment Type</label>
                          <Select required defaultValue="salaried">
                            <SelectTrigger>
                              <SelectValue placeholder="Select employment type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="salaried">Salaried</SelectItem>
                              <SelectItem value="self-employed">Self-Employed</SelectItem>
                              <SelectItem value="business">Business Owner</SelectItem>
                              <SelectItem value="retired">Retired</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="annualIncome" className="text-sm font-medium">Annual Income (₹)</label>
                          <Input id="annualIncome" type="number" required />
                        </div>
                      </div>
                      
                      <div className="p-4 bg-amber-50 rounded-lg flex items-start gap-3">
                        <AlertCircle className="h-5 w-5 text-amber-600 mt-1 flex-shrink-0" />
                        <div>
                          <p className="text-sm font-medium text-amber-800">Important Note</p>
                          <p className="text-sm text-amber-700">
                            The offer is subject to meeting the eligibility criteria and final approval by Vyom Bank.
                          </p>
                        </div>
                      </div>
                    </form>
                  </CardContent>
                </>
              )}
              
              {step === 3 && (
                <>
                  <CardHeader>
                    <CardTitle>Confirm Application</CardTitle>
                    <CardDescription>
                      Review and confirm your application details
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form id="step3Form" onSubmit={handleFormSubmit}>
                      <div className="space-y-6">
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground mb-2">Offer Details</h3>
                          <div className="p-4 border rounded-lg">
                            <p className="font-medium mb-1">{offerTitle}</p>
                            <p className="text-sm text-muted-foreground">
                              This exclusive offer is available for a limited time only. 
                              Terms and conditions apply.
                            </p>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground mb-2">Personal Information</h3>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Name</p>
                              <p>Rahul Sharma</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Email</p>
                              <p>rahul.sharma@example.com</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Mobile</p>
                              <p>+91 98765 43210</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Address</p>
                              <p>123 Main St, New Delhi 110001</p>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-sm font-medium text-muted-foreground mb-2">Account Details</h3>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Account Type</p>
                              <p>Savings Account</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Account Number</p>
                              <p>XXXX XXXX 5467</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Employment</p>
                              <p>Salaried</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-muted-foreground">Annual Income</p>
                              <p>₹12,00,000</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-top space-x-2">
                          <Checkbox id="terms" required />
                          <label
                            htmlFor="terms"
                            className="text-sm leading-tight"
                          >
                            I agree to the terms and conditions of the offer and confirm that all information provided is accurate. I authorize Vyom Bank to verify the information as needed.
                          </label>
                        </div>
                      </div>
                    </form>
                  </CardContent>
                </>
              )}
              
              <CardFooter className="flex justify-between">
                {step > 1 ? (
                  <Button 
                    variant="outline" 
                    onClick={() => setStep(step - 1)}
                    disabled={loading}
                  >
                    Previous
                  </Button>
                ) : (
                  <Button 
                    variant="outline" 
                    asChild
                    disabled={loading}
                  >
                    <Link to="/dashboard">Cancel</Link>
                  </Button>
                )}
                
                <Button 
                  type="submit"
                  form={`step${step}Form`}
                  disabled={loading}
                >
                  {loading ? "Processing..." : step < 3 ? "Next" : "Submit Application"}
                </Button>
              </CardFooter>
            </Card>
          </>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Application Submitted!</h2>
              <p className="text-muted-foreground mb-6">
                Your application for {offerTitle} has been successfully submitted.
                We'll review your application and get back to you shortly.
              </p>
              <div className="p-4 bg-accent rounded-lg mb-6">
                <p className="font-medium text-sm">Application Reference: <span className="text-vyom-blue">VYM25031246</span></p>
                <p className="text-xs text-muted-foreground mt-1">
                  Please save this reference number for future communications
                </p>
              </div>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <Button variant="outline" asChild>
                  <Link to="/dashboard">Return to Dashboard</Link>
                </Button>
                <Button className="flex items-center gap-2">
                  <span>Track Application</span>
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ApplyOffer;
