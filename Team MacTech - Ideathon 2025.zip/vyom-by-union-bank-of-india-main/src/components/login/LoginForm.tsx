
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Lock, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

interface LoginFormProps {
  loginType: "user" | "admin";
  setLoginType: (type: "user" | "admin") => void;
}

const LoginForm = ({ loginType, setLoginType }: LoginFormProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const toggleShowPassword = () => setShowPassword(!showPassword);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      
      // Simulate successful login
      if (email && password) {
        toast({
          title: "Login successful!",
          description: loginType === "user" ? "Welcome back to Vyom." : "Welcome to the Admin Portal.",
          duration: 3000,
        });
        
        // Redirect based on login type
        navigate(loginType === "user" ? "/dashboard" : "/admin");
      } else {
        toast({
          title: "Login failed",
          description: "Please check your credentials and try again.",
          variant: "destructive",
          duration: 3000,
        });
      }
    }, 1500);
  };

  return (
    <div className="space-y-4">
      {/* Account Type Selector */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-lg bg-vyom-light">
        <Button
          type="button"
          variant={loginType === "user" ? "toggle-active" : "toggle"}
          onClick={() => setLoginType("user")}
        >
          User Account
        </Button>
        <Button
          type="button"
          variant={loginType === "admin" ? "toggle-active" : "toggle"}
          onClick={() => setLoginType("admin")}
        >
          Admin Access
        </Button>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
            <Input 
              id="email" 
              type="email" 
              placeholder="name@example.com" 
              className="pl-10 form-input" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Password</Label>
            <Link to="/forgot-password" className="text-xs text-vyom-red hover:underline">
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
            <Input 
              id="password" 
              type={showPassword ? "text" : "password"} 
              className="pl-10 pr-10 form-input" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button 
              type="button" 
              onClick={toggleShowPassword}
              className="absolute right-3 top-3 text-vyom-gray hover:text-vyom-blue transition-colors"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-vyom-red hover:bg-vyom-red/90 text-white transform transition-all duration-300 hover:translate-y-[-2px] hover:shadow-md"
          disabled={isLoading}
        >
          {isLoading ? "Signing in..." : "Sign in"}
        </Button>
      </form>
    </div>
  );
};

export default LoginForm;
