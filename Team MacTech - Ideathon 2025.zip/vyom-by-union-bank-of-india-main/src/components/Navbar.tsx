
import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Globe, ChevronDown } from "lucide-react";
import LanguageToggle from "./LanguageToggle";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  
  // Track scroll position to change navbar style
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const isLinkActive = (path: string) => {
    return location.pathname === path;
  };
  
  return (
    <nav 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? "py-3 bg-white/90 backdrop-blur-md shadow-md" 
          : "py-5 bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-red flex items-center justify-center text-white font-bold text-xl">V</div>
            <span className="text-xl font-bold">Vyom</span>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`nav-link ${isLinkActive('/') ? 'after:scale-x-100 after:origin-bottom-left text-foreground' : ''}`}
            >
              Home
            </Link>
            
            {/* Services Dropdown */}
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <NavigationMenuTrigger className="bg-transparent hover:bg-transparent focus:bg-transparent data-[state=open]:bg-transparent">
                    Services
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid grid-cols-2 gap-3 p-4 w-[400px]">
                      <Link 
                        to="/services/personal-banking" 
                        className="flex items-center space-x-2 rounded-md p-2 hover:bg-accent"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-8 h-8 rounded-full bg-vyom-teal/20 flex items-center justify-center">
                          <span className="text-vyom-teal text-xs">PB</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Personal Banking</div>
                          <div className="text-xs text-muted-foreground">Accounts & services for individuals</div>
                        </div>
                      </Link>
                      
                      <Link 
                        to="/services/business-banking" 
                        className="flex items-center space-x-2 rounded-md p-2 hover:bg-accent"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-8 h-8 rounded-full bg-vyom-blue/20 flex items-center justify-center">
                          <span className="text-vyom-blue text-xs">BB</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Business Banking</div>
                          <div className="text-xs text-muted-foreground">Solutions for businesses</div>
                        </div>
                      </Link>
                      
                      <Link 
                        to="/services/loans" 
                        className="flex items-center space-x-2 rounded-md p-2 hover:bg-accent"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-8 h-8 rounded-full bg-vyom-red/20 flex items-center justify-center">
                          <span className="text-vyom-red text-xs">LN</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Loans</div>
                          <div className="text-xs text-muted-foreground">Personal & business loans</div>
                        </div>
                      </Link>
                      
                      <Link 
                        to="/services/investments" 
                        className="flex items-center space-x-2 rounded-md p-2 hover:bg-accent"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-8 h-8 rounded-full bg-vyom-purple/20 flex items-center justify-center">
                          <span className="text-vyom-purple text-xs">IN</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Investments</div>
                          <div className="text-xs text-muted-foreground">Grow your wealth</div>
                        </div>
                      </Link>
                      
                      <Link 
                        to="/services/insurance" 
                        className="flex items-center space-x-2 rounded-md p-2 hover:bg-accent"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <div className="w-8 h-8 rounded-full bg-vyom-teal/20 flex items-center justify-center">
                          <span className="text-vyom-teal text-xs">IS</span>
                        </div>
                        <div>
                          <div className="text-sm font-medium">Insurance</div>
                          <div className="text-xs text-muted-foreground">Protect what matters</div>
                        </div>
                      </Link>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
            
            <Link 
              to="/features" 
              className={`nav-link ${isLinkActive('/features') ? 'after:scale-x-100 after:origin-bottom-left text-foreground' : ''}`}
            >
              Features
            </Link>
            <Link 
              to="/about" 
              className={`nav-link ${isLinkActive('/about') ? 'after:scale-x-100 after:origin-bottom-left text-foreground' : ''}`}
            >
              About
            </Link>
            <Link 
              to="/contact" 
              className={`nav-link ${isLinkActive('/contact') ? 'after:scale-x-100 after:origin-bottom-left text-foreground' : ''}`}
            >
              Contact
            </Link>
            
            {/* Language Toggle */}
            <div className="pl-2 border-l border-gray-300">
              <LanguageToggle />
            </div>
            
            {/* Authentication Buttons */}
            <div className="flex items-center space-x-3">
              <Link to="/login" className="btn-secondary py-2 px-4">
                Login
              </Link>
              <Link to="/signup" className="btn-primary py-2 px-4">
                Sign Up
              </Link>
            </div>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMenu}
              className="text-vyom-blue p-2 rounded-md hover:bg-vyom-light transition-colors duration-200"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-lg shadow-lg animate-fade-in">
          <div className="container mx-auto px-4 py-5">
            <div className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className={`text-vyom-blue hover:text-vyom-red py-2 transition-colors duration-200 ${isLinkActive('/') ? 'text-vyom-red font-medium' : ''}`} 
                onClick={toggleMenu}
              >
                Home
              </Link>
              
              {/* Mobile Services Dropdown */}
              <div className="py-2">
                <div className="flex items-center justify-between text-vyom-blue hover:text-vyom-red transition-colors duration-200 cursor-pointer">
                  <span>Services</span>
                  <ChevronDown size={16} />
                </div>
                <div className="pl-4 mt-2 space-y-2">
                  <Link 
                    to="/services/personal-banking" 
                    className="block text-vyom-blue hover:text-vyom-red py-1 text-sm transition-colors duration-200" 
                    onClick={toggleMenu}
                  >
                    Personal Banking
                  </Link>
                  <Link 
                    to="/services/business-banking" 
                    className="block text-vyom-blue hover:text-vyom-red py-1 text-sm transition-colors duration-200" 
                    onClick={toggleMenu}
                  >
                    Business Banking
                  </Link>
                  <Link 
                    to="/services/loans" 
                    className="block text-vyom-blue hover:text-vyom-red py-1 text-sm transition-colors duration-200" 
                    onClick={toggleMenu}
                  >
                    Loans
                  </Link>
                  <Link 
                    to="/services/investments" 
                    className="block text-vyom-blue hover:text-vyom-red py-1 text-sm transition-colors duration-200" 
                    onClick={toggleMenu}
                  >
                    Investments
                  </Link>
                  <Link 
                    to="/services/insurance" 
                    className="block text-vyom-blue hover:text-vyom-red py-1 text-sm transition-colors duration-200" 
                    onClick={toggleMenu}
                  >
                    Insurance
                  </Link>
                </div>
              </div>
              
              <Link 
                to="/features" 
                className={`text-vyom-blue hover:text-vyom-red py-2 transition-colors duration-200 ${isLinkActive('/features') ? 'text-vyom-red font-medium' : ''}`} 
                onClick={toggleMenu}
              >
                Features
              </Link>
              <Link 
                to="/about" 
                className={`text-vyom-blue hover:text-vyom-red py-2 transition-colors duration-200 ${isLinkActive('/about') ? 'text-vyom-red font-medium' : ''}`} 
                onClick={toggleMenu}
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className={`text-vyom-blue hover:text-vyom-red py-2 transition-colors duration-200 ${isLinkActive('/contact') ? 'text-vyom-red font-medium' : ''}`} 
                onClick={toggleMenu}
              >
                Contact
              </Link>
              
              <div className="flex items-center py-2">
                <Globe size={18} className="text-vyom-gray mr-2" />
                <LanguageToggle />
              </div>
              
              <div className="flex flex-col space-y-3 pt-2">
                <Link to="/login" className="btn-secondary text-center" onClick={toggleMenu}>
                  Login
                </Link>
                <Link to="/signup" className="btn-primary text-center" onClick={toggleMenu}>
                  Sign Up
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
