
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle, User, CreditCard, PiggyBank, Lock, Activity, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

const PersonalBanking = () => {
  const [showAccountForm, setShowAccountForm] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    accountType: "savings"
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleOpenAccount = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Account Application Received",
      description: `Thank you, ${formData.fullName}! Your ${formData.accountType} account application has been submitted successfully.`,
    });
    setShowAccountForm(false);
    setFormData({
      fullName: "",
      email: "",
      phone: "",
      accountType: "savings"
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero Section */}
        <section className="py-12 md:py-20 bg-gradient-to-r from-vyom-light via-white to-vyom-teal/10">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-vyom-navy">Personal Banking</h1>
              <p className="text-lg md:text-xl text-vyom-gray mb-8">
                Banking solutions designed for your personal financial needs with innovative digital features and expert support.
              </p>
              <Button 
                size="lg" 
                className="bg-vyom-blue hover:bg-vyom-blue/90 text-white"
                onClick={() => setShowAccountForm(true)}
              >
                Open an Account <ArrowRight className="ml-2" />
              </Button>
            </div>
          </div>
        </section>
        
        {/* Account Types */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Our Account Types</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-blue rounded-full flex items-center justify-center mb-6">
                  <PiggyBank className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">Savings Account</h3>
                <p className="text-vyom-gray mb-4">Grow your savings with competitive interest rates and zero maintenance fees.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>4.5% interest rate p.a.</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Zero maintenance charges</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Free digital banking</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    setShowAccountForm(true);
                    setFormData(prev => ({ ...prev, accountType: "savings" }));
                  }}
                >
                  Open Savings Account
                </Button>
              </div>
              
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-teal rounded-full flex items-center justify-center mb-6">
                  <CreditCard className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">Current Account</h3>
                <p className="text-vyom-gray mb-4">Ideal for everyday transactions with unlimited withdrawals and deposits.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Unlimited transactions</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Free checkbook</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Overdraft facility</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    setShowAccountForm(true);
                    setFormData(prev => ({ ...prev, accountType: "current" }));
                  }}
                >
                  Open Current Account
                </Button>
              </div>
              
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-purple rounded-full flex items-center justify-center mb-6">
                  <User className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">Premium Account</h3>
                <p className="text-vyom-gray mb-4">Exclusive benefits and personalized service for premium customers.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Priority banking services</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Dedicated relationship manager</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Preferential rates on loans</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    setShowAccountForm(true);
                    setFormData(prev => ({ ...prev, accountType: "premium" }));
                  }}
                >
                  Open Premium Account
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Digital Banking */}
        <section className="py-16 bg-gradient-to-br from-vyom-navy/5 to-vyom-teal/5">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center max-w-6xl mx-auto">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                <img 
                  src="/placeholder.svg" 
                  alt="Vyom Digital Banking" 
                  className="rounded-xl shadow-lg w-full"
                />
              </div>
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold mb-6 text-vyom-blue">State-of-the-Art Digital Banking</h2>
                <p className="text-vyom-gray mb-6">Experience seamless banking with our feature-rich mobile and online banking platforms.</p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-blue rounded-full flex items-center justify-center shrink-0 mr-4">
                      <Activity className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Real-time Transactions</h4>
                      <p className="text-vyom-gray">Monitor your finances with instant transaction alerts and updates.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-teal rounded-full flex items-center justify-center shrink-0 mr-4">
                      <Lock className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Secure Banking</h4>
                      <p className="text-vyom-gray">Bank with confidence with our advanced security features.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-purple rounded-full flex items-center justify-center shrink-0 mr-4">
                      <PiggyBank className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Financial Tools</h4>
                      <p className="text-vyom-gray">Access budgeting tools and financial insights to manage your money better.</p>
                    </div>
                  </div>
                </div>
                
                <Button 
                  className="bg-vyom-blue hover:bg-vyom-blue/90 text-white"
                  onClick={() => {
                    toast({
                      title: "Digital Banking Demo",
                      description: "We'll send you a link to access our digital banking demo. Thank you for your interest!",
                    });
                  }}
                >
                  Try Digital Banking Demo
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Additional Services */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Additional Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Link to="/services/loans" className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100 group">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue group-hover:text-vyom-red transition-colors">Personal Loans</h3>
                <p className="text-vyom-gray mb-3">Quick loans with minimal documentation for your personal needs.</p>
                <div className="flex items-center text-vyom-blue text-sm font-medium group-hover:text-vyom-red transition-colors">
                  Learn More <ChevronRight size={16} className="ml-1" />
                </div>
              </Link>
              
              <Link to="/services/investments" className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100 group">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue group-hover:text-vyom-red transition-colors">Investment Options</h3>
                <p className="text-vyom-gray mb-3">Grow your wealth with our range of investment products.</p>
                <div className="flex items-center text-vyom-blue text-sm font-medium group-hover:text-vyom-red transition-colors">
                  Learn More <ChevronRight size={16} className="ml-1" />
                </div>
              </Link>
              
              <Link to="/services/insurance" className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100 group">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue group-hover:text-vyom-red transition-colors">Insurance Plans</h3>
                <p className="text-vyom-gray mb-3">Secure your future with our comprehensive insurance solutions.</p>
                <div className="flex items-center text-vyom-blue text-sm font-medium group-hover:text-vyom-red transition-colors">
                  Learn More <ChevronRight size={16} className="ml-1" />
                </div>
              </Link>
              
              <Link to="/contact" className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100 group">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue group-hover:text-vyom-red transition-colors">Financial Advisory</h3>
                <p className="text-vyom-gray mb-3">Get expert advice on managing your finances and investments.</p>
                <div className="flex items-center text-vyom-blue text-sm font-medium group-hover:text-vyom-red transition-colors">
                  Learn More <ChevronRight size={16} className="ml-1" />
                </div>
              </Link>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-vyom-blue text-white">
          <div className="container mx-auto px-4 text-center max-w-4xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Banking Journey?</h2>
            <p className="text-lg md:text-xl mb-8 opacity-90">Join Vyom Bank today and experience banking reimagined for the digital age.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-white text-vyom-blue hover:bg-vyom-light"
                onClick={() => setShowAccountForm(true)}
              >
                Open an Account
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/10"
                onClick={() => {
                  toast({
                    title: "Contact Request",
                    description: "A banking representative will contact you shortly. Thank you for your interest!",
                  });
                }}
              >
                Speak to an Advisor
              </Button>
            </div>
          </div>
        </section>
        
        {/* Account Opening Form Modal */}
        {showAccountForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl p-6 md:p-8 max-w-md w-full animate-fade-in">
              <h3 className="text-2xl font-bold mb-4 text-vyom-blue">Open an Account</h3>
              <p className="text-vyom-gray mb-6">Please provide your details to start the account opening process.</p>
              
              <form onSubmit={handleOpenAccount} className="space-y-4">
                <div>
                  <label htmlFor="fullName" className="block text-sm font-medium mb-1">Full Name</label>
                  <Input 
                    id="fullName" 
                    name="fullName" 
                    value={formData.fullName} 
                    onChange={handleInputChange} 
                    required 
                    placeholder="John Doe"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1">Email Address</label>
                  <Input 
                    id="email" 
                    name="email" 
                    type="email" 
                    value={formData.email} 
                    onChange={handleInputChange} 
                    required 
                    placeholder="john@example.com"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-1">Phone Number</label>
                  <Input 
                    id="phone" 
                    name="phone" 
                    value={formData.phone} 
                    onChange={handleInputChange} 
                    required 
                    placeholder="+91 9876543210"
                  />
                </div>
                
                <div>
                  <label htmlFor="accountType" className="block text-sm font-medium mb-1">Account Type</label>
                  <select 
                    id="accountType" 
                    name="accountType" 
                    value={formData.accountType} 
                    onChange={handleInputChange}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm"
                    required
                  >
                    <option value="savings">Savings Account</option>
                    <option value="current">Current Account</option>
                    <option value="premium">Premium Account</option>
                  </select>
                </div>
                
                <div className="flex justify-end space-x-3 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowAccountForm(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Submit Application</Button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default PersonalBanking;
