
import { Json } from "@/integrations/supabase/types";

export type Profile = {
  id: string;
  first_name: string | null;
  last_name: string | null;
  age: number | null;
  occupation: string | null;
  annual_income: number | null;
  kyc_verified: boolean;
  marital_status: string | null;
  created_at: string;
};

export type AssessmentDetails = {
  age_factor: string;
  occupation_factor: string;
  income_factor: string;
  kyc_factor: string;
  marital_status_factor: string;
  summary: string;
};

export type RiskAssessment = {
  id: string;
  profile_id: string;
  risk_score: number;
  risk_category: string;
  assessment_details: AssessmentDetails | null;
  created_at: string;
  updated_at: string;
};

export type ProfileWithRisk = Profile & {
  risk_assessment?: RiskAssessment | null;
};
