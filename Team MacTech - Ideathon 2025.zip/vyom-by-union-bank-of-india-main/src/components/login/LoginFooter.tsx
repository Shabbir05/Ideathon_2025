
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const LoginFooter = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex flex-col md:flex-row justify-between items-center text-sm text-vyom-gray">
        <div className="mb-4 md:mb-0">
          © {new Date().getFullYear()} Vyom by Union Bank of India. All rights reserved.
        </div>
        <div className="flex space-x-6">
          <Link to="/privacy-policy" target="_blank" className="hover:text-vyom-red transition-colors duration-200">Privacy Policy</Link>
          <Link to="/terms-of-service" target="_blank" className="hover:text-vyom-red transition-colors duration-200">Terms of Service</Link>
          <Link to="/contact" className="hover:text-vyom-red transition-colors duration-200">
            <Button variant="contact" size="sm">Contact Support</Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginFooter;
