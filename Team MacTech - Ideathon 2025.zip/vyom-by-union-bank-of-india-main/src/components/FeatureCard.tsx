
import { ReactNode } from "react";

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  color?: string;
}

const FeatureCard = ({ icon, title, description, color = "from-vyom-blue to-vyom-teal" }: FeatureCardProps) => {
  return (
    <div className="feature-card glass-card overflow-hidden group">
      <div className={`p-3 w-16 h-16 rounded-xl mb-4 flex items-center justify-center bg-gradient-to-br ${color} text-white transform group-hover:scale-110 transition-transform duration-300`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-vyom-blue">{title}</h3>
      <p className="text-vyom-gray text-sm leading-relaxed">{description}</p>
    </div>
  );
};

export default FeatureCard;
