
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon, Download, FileText, Filter } from "lucide-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Link } from "react-router-dom";

const Statement = () => {
  const [date, setDate] = useState<Date | undefined>(new Date());
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">Account Statement</h1>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Statement Download</CardTitle>
          <CardDescription>Download your account statement for any period</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Account</label>
              <Select defaultValue="savings">
                <SelectTrigger>
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="savings">Savings Account (...5467)</SelectItem>
                  <SelectItem value="current">Current Account (...8901)</SelectItem>
                  <SelectItem value="fd">Fixed Deposit (...2345)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">Statement Period</label>
              <Select defaultValue="custom">
                <SelectTrigger>
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1month">Last 1 Month</SelectItem>
                  <SelectItem value="3month">Last 3 Months</SelectItem>
                  <SelectItem value="6month">Last 6 Months</SelectItem>
                  <SelectItem value="1year">Last 1 Year</SelectItem>
                  <SelectItem value="custom">Custom Period</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">From Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-2 block">To Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          
          <div className="mt-6 flex flex-wrap gap-4">
            <Button className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Download as PDF
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Download as Excel
            </Button>
            <Button variant="outline" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Download as CSV
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>View all your recent transactions</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead className="text-right">Debit (₹)</TableHead>
                <TableHead className="text-right">Credit (₹)</TableHead>
                <TableHead className="text-right">Balance (₹)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                {
                  date: "24 Mar 2025",
                  description: "Salary Credit",
                  reference: "NEFT-SALARY-MAR",
                  debit: "",
                  credit: "75,000.00",
                  balance: "1,25,430.50"
                },
                {
                  date: "23 Mar 2025",
                  description: "ATM Withdrawal",
                  reference: "ATM/DEL/789654",
                  debit: "10,000.00",
                  credit: "",
                  balance: "50,430.50"
                },
                {
                  date: "22 Mar 2025",
                  description: "Online Shopping - Amazon",
                  reference: "UPI/123456789",
                  debit: "2,450.00",
                  credit: "",
                  balance: "60,430.50"
                },
                {
                  date: "21 Mar 2025",
                  description: "Electricity Bill Payment",
                  reference: "BBPS/ELEC/456789",
                  debit: "3,250.00",
                  credit: "",
                  balance: "62,880.50"
                },
                {
                  date: "20 Mar 2025",
                  description: "Fund Transfer to Rahul",
                  reference: "UPI/987654321",
                  debit: "5,000.00",
                  credit: "",
                  balance: "66,130.50"
                },
                {
                  date: "19 Mar 2025",
                  description: "Mutual Fund Investment",
                  reference: "MF/SIP/123456",
                  debit: "10,000.00",
                  credit: "",
                  balance: "71,130.50"
                },
                {
                  date: "18 Mar 2025",
                  description: "Interest Credit",
                  reference: "INT/SA/Q4",
                  debit: "",
                  credit: "750.50",
                  balance: "81,130.50"
                },
              ].map((transaction, index) => (
                <TableRow key={index}>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.description}</TableCell>
                  <TableCell>{transaction.reference}</TableCell>
                  <TableCell className="text-right text-red-500">{transaction.debit}</TableCell>
                  <TableCell className="text-right text-green-600">{transaction.credit}</TableCell>
                  <TableCell className="text-right font-medium">{transaction.balance}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          <div className="flex justify-center mt-6">
            <Button variant="outline">Load More</Button>
          </div>
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default Statement;
