
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface AddPaymentMethodDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdd: (method: { type: string; linkedTo: string }) => void;
}

export function AddPaymentMethodDialog({ open, onOpenChange, onAdd }: AddPaymentMethodDialogProps) {
  const [type, setType] = useState<string>("UPI");
  const [linkedTo, setLinkedTo] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!type || !linkedTo) {
      toast({
        title: "Error",
        description: "Please fill all the required fields",
        variant: "destructive",
      });
      return;
    }

    if (type === "Debit Card" && linkedTo.length < 4) {
      toast({
        title: "Error",
        description: "Please enter at least the last 4 digits of your card",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    // Simulate processing
    setTimeout(() => {
      onAdd({ type, linkedTo });
      setType("UPI");
      setLinkedTo("");
      setIsSubmitting(false);
      onOpenChange(false);
    }, 800);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Payment Method</DialogTitle>
          <DialogDescription>
            Add a new payment method for quicker transfers
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">
                Type
              </Label>
              <div className="col-span-3">
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UPI">UPI</SelectItem>
                    <SelectItem value="Debit Card">Debit Card</SelectItem>
                    <SelectItem value="Credit Card">Credit Card</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="linkedTo" className="text-right">
                {type === "UPI" ? "UPI ID" : "Card Number"}
              </Label>
              <Input
                id="linkedTo"
                value={linkedTo}
                onChange={(e) => setLinkedTo(e.target.value)}
                className="col-span-3"
                placeholder={type === "UPI" ? "Enter UPI ID" : "Enter last 4 digits of card"}
                maxLength={type === "UPI" ? 50 : 4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Adding..." : "Add Payment Method"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
