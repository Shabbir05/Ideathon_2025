
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, ArrowRight, Download, Filter, Search, SlidersHorizontal } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useNavigate } from "react-router-dom";

const MPassbook = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("all");
  const [currentMonth, setCurrentMonth] = useState("June 2023");
  const [months] = useState([
    "June 2023", "May 2023", "April 2023", "March 2023", 
    "February 2023", "January 2023", "December 2022"
  ]);
  
  const transactions = [
    {
      id: 1,
      date: "30-Jun-2023",
      description: "Salary Deposit",
      type: "credit",
      amount: "75,000.00",
      balance: "232,892.45"
    },
    {
      id: 2,
      date: "28-Jun-2023",
      description: "Credit Card Payment",
      type: "debit",
      amount: "12,450.25",
      balance: "157,892.45"
    },
    {
      id: 3,
      date: "25-Jun-2023",
      description: "Online Shopping - Amazon",
      type: "debit",
      amount: "3,540.50",
      balance: "170,342.70"
    },
    {
      id: 4,
      date: "22-Jun-2023",
      description: "Mobile Bill Payment",
      type: "debit",
      amount: "799.00",
      balance: "173,883.20"
    },
    {
      id: 5,
      date: "20-Jun-2023",
      description: "Electricity Bill Payment",
      type: "debit",
      amount: "1,450.00",
      balance: "174,682.20"
    },
    {
      id: 6,
      date: "15-Jun-2023",
      description: "Freelance Payment",
      type: "credit",
      amount: "15,000.00",
      balance: "176,132.20"
    },
    {
      id: 7,
      date: "12-Jun-2023",
      description: "Restaurant Payment",
      type: "debit",
      amount: "1,750.25",
      balance: "161,132.20"
    },
    {
      id: 8,
      date: "10-Jun-2023",
      description: "Grocery Store",
      type: "debit",
      amount: "2,150.25",
      balance: "162,882.45"
    },
    {
      id: 9,
      date: "05-Jun-2023",
      description: "Movie Tickets",
      type: "debit",
      amount: "600.00",
      balance: "165,032.70"
    },
    {
      id: 10,
      date: "01-Jun-2023",
      description: "Monthly Interest Credit",
      type: "credit",
      amount: "320.45",
      balance: "165,632.70"
    }
  ];

  const filteredTransactions = transactions.filter(transaction => {
    if (activeTab === "all") return true;
    return transaction.type === activeTab;
  });

  const handlePreviousMonth = () => {
    const currentIndex = months.indexOf(currentMonth);
    if (currentIndex < months.length - 1) {
      setCurrentMonth(months[currentIndex + 1]);
      toast({
        title: "Month Changed",
        description: `Viewing transactions for ${months[currentIndex + 1]}`,
      });
    }
  };

  const handleNextMonth = () => {
    const currentIndex = months.indexOf(currentMonth);
    if (currentIndex > 0) {
      setCurrentMonth(months[currentIndex - 1]);
      toast({
        title: "Month Changed",
        description: `Viewing transactions for ${months[currentIndex - 1]}`,
      });
    }
  };

  const handleDownloadStatement = () => {
    toast({
      title: "Statement Downloaded",
      description: `Your bank statement for ${currentMonth} has been downloaded successfully.`,
      variant: "default",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => navigate("/dashboard")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      
      <Card className="shadow-lg border-none">
        <CardHeader className="bg-gradient-to-r from-vyom-blue to-vyom-teal text-white">
          <CardTitle className="text-2xl">mPassbook</CardTitle>
          <CardDescription className="text-white/80">
            View and download your account statements
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
            <div className="flex items-center gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handlePreviousMonth}
                disabled={months.indexOf(currentMonth) === months.length - 1}
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <span className="font-medium">{currentMonth}</span>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleNextMonth}
                disabled={months.indexOf(currentMonth) === 0}
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Filter className="h-4 w-4" />
                <span>Filter</span>
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-1">
                <Search className="h-4 w-4" />
                <span>Search</span>
              </Button>
              <Button 
                variant="default" 
                size="sm" 
                className="flex items-center gap-1"
                onClick={handleDownloadStatement}
              >
                <Download className="h-4 w-4" />
                <span>Download</span>
              </Button>
            </div>
          </div>
          
          <Alert className="mb-6 bg-blue-50 border border-blue-200">
            <AlertTitle className="text-vyom-blue flex items-center gap-2">
              <SlidersHorizontal className="h-4 w-4" /> Transaction Summary
            </AlertTitle>
            <AlertDescription className="text-vyom-gray">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-2">
                <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <p className="text-sm text-vyom-gray">Opening Balance</p>
                  <p className="text-lg font-medium">₹165,312.25</p>
                </div>
                <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <p className="text-sm text-vyom-gray">Total Credits</p>
                  <p className="text-lg font-medium text-vyom-green">₹90,320.45</p>
                </div>
                <div className="p-3 bg-white rounded-lg border border-gray-100 shadow-sm">
                  <p className="text-sm text-vyom-gray">Total Debits</p>
                  <p className="text-lg font-medium text-vyom-red">₹22,740.25</p>
                </div>
              </div>
            </AlertDescription>
          </Alert>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-6">
              <TabsTrigger value="all">All Transactions</TabsTrigger>
              <TabsTrigger value="credit">Credits</TabsTrigger>
              <TabsTrigger value="debit">Debits</TabsTrigger>
            </TabsList>
            
            <TabsContent value={activeTab} className="mt-0">
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader className="bg-vyom-light">
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Amount (₹)</TableHead>
                      <TableHead className="text-right">Balance (₹)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTransactions.map((transaction) => (
                      <TableRow key={transaction.id} className="hover:bg-gray-50">
                        <TableCell className="font-medium">{transaction.date}</TableCell>
                        <TableCell>{transaction.description}</TableCell>
                        <TableCell>
                          <Badge variant={transaction.type === "credit" ? "outline" : "destructive"} className={`${
                            transaction.type === "credit" ? "bg-green-50 text-vyom-green border-vyom-green/30" : "bg-red-50 text-vyom-red border-vyom-red/30"
                          }`}>
                            {transaction.type === "credit" ? "Credit" : "Debit"}
                          </Badge>
                        </TableCell>
                        <TableCell className={`text-right ${
                          transaction.type === "credit" ? "text-vyom-green" : "text-vyom-red"
                        }`}>
                          {transaction.type === "credit" ? "+" : "-"}{transaction.amount}
                        </TableCell>
                        <TableCell className="text-right font-medium">{transaction.balance}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between border-t p-6 bg-gray-50">
          <p className="text-sm text-vyom-gray">Showing {filteredTransactions.length} transactions for {currentMonth}</p>
          <div className="flex gap-1">
            <Button variant="outline" size="sm" disabled>Previous</Button>
            <Button variant="outline" size="sm" disabled>Next</Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default MPassbook;
