
import React from "react";
import { Link } from "react-router-dom";
import LanguageToggle from "@/components/LanguageToggle";

const LoginHeader = () => {
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center">
        <Link 
          to="/" 
          className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-red flex items-center justify-center text-white font-bold text-xl">V</div>
          <span className="text-xl font-bold">Vyom</span>
        </Link>
        
        <div className="flex items-center space-x-4">
          <LanguageToggle />
          <Link to="/" className="text-vyom-blue hover:text-vyom-red transition-colors duration-200 text-sm">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LoginHeader;
