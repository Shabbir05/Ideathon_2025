
import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import LoginForm from "./LoginForm";
import SocialLogin from "./SocialLogin";

const LoginCard = () => {
  const [loginType, setLoginType] = useState<"user" | "admin">("user");

  return (
    <Card className="border-none shadow-xl">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center text-vyom-blue">Welcome back</CardTitle>
        <CardDescription className="text-center">
          Enter your credentials to access your {loginType === "user" ? "account" : "admin portal"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <LoginForm loginType={loginType} setLoginType={setLoginType} />
        <SocialLogin />
      </CardContent>
      <CardFooter className="flex justify-center">
        <p className="text-sm text-vyom-gray">
          Don't have an account?{" "}
          <Link to="/signup" className="text-vyom-red hover:underline font-medium">
            Sign up
          </Link>
        </p>
      </CardFooter>
    </Card>
  );
};

export default LoginCard;
