

// Data for fraud weekly chart
export const fraudWeeklyData = [
  { name: "Mon", attempts: 24, prevented: 22 },
  { name: "Tue", attempts: 18, prevented: 16 },
  { name: "Wed", attempts: 32, prevented: 29 },
  { name: "Thu", attempts: 27, prevented: 25 },
  { name: "Fri", attempts: 35, prevented: 31 },
  { name: "Sat", attempts: 15, prevented: 14 },
  { name: "Sun", attempts: 12, prevented: 11 },
];

// Data for fraud monthly chart
export const fraudMonthlyData = [
  { name: "Jan", attempts: 120, prevented: 105 },
  { name: "Feb", attempts: 98, prevented: 88 },
  { name: "Mar", attempts: 145, prevented: 131 },
  { name: "Apr", attempts: 132, prevented: 120 },
  { name: "May", attempts: 156, prevented: 143 },
  { name: "Jun", attempts: 127, prevented: 117 },
  { name: "Jul", attempts: 169, prevented: 154 },
  { name: "Aug", attempts: 142, prevented: 129 },
  { name: "Sep", attempts: 115, prevented: 107 },
  { name: "Oct", attempts: 138, prevented: 126 },
  { name: "Nov", attempts: 152, prevented: 142 },
  { name: "Dec", attempts: 165, prevented: 151 },
];

// Data for risk heatmap
export const riskHeatmapData = [
  { region: "Mumbai", risk: 78, incidents: 156, color: "#f44336" },
  { region: "Delhi", risk: 62, incidents: 127, color: "#ff9800" },
  { region: "Bangalore", risk: 45, incidents: 93, color: "#ffeb3b" },
  { region: "Hyderabad", risk: 37, incidents: 76, color: "#8bc34a" },
  { region: "Chennai", risk: 51, incidents: 102, color: "#ff9800" },
  { region: "Kolkata", risk: 55, incidents: 112, color: "#ff9800" },
  { region: "Pune", risk: 30, incidents: 64, color: "#8bc34a" },
];

// Data for request type distribution
export const requestTypeData = [
  { name: "Password Reset", value: 35, fill: "#8884d8" },
  { name: "Transaction Limit", value: 25, fill: "#82ca9d" },
  { name: "New Beneficiary", value: 18, fill: "#ffc658" },
  { name: "Account Unlock", value: 15, fill: "#ff8042" },
  { name: "KYC Update", value: 7, fill: "#a4de6c" },
];

// Data for fraud activity monitoring
export const fraudActivityData = [
  { 
    id: "TX78923", 
    accountId: "A9283728", 
    type: "Large Transfer", 
    amount: "₹9,500.00", 
    timestamp: "Today, 10:23 AM", 
    risk: "High", 
    location: "Mumbai, IN",
    flagged: true,
    category: "Transfer"
  },
  { 
    id: "TX78922", 
    accountId: "A4526781", 
    type: "Multiple Small Transfers", 
    amount: "₹3,480.00", 
    timestamp: "Today, 9:45 AM", 
    risk: "Medium", 
    location: "Delhi, IN",
    flagged: true,
    category: "Transfer"
  },
  { 
    id: "TX78919", 
    accountId: "A7812056", 
    type: "International Transfer", 
    amount: "₹15,750.00", 
    timestamp: "Today, 8:30 AM", 
    risk: "High", 
    location: "London, UK",
    flagged: true,
    category: "International"
  },
];

// Data for transaction categories
export const transactionCategoriesData = [
  { name: "Transfers", value: 35, fill: "#8884d8" },
  { name: "Bill Payments", value: 25, fill: "#82ca9d" },
  { name: "Withdrawals", value: 18, fill: "#ffc658" },
  { name: "Card Payments", value: 15, fill: "#ff8042" },
  { name: "International", value: 7, fill: "#a4de6c" },
];

// Data for anomaly detection
export const anomalyDetectionData = [
  { date: "May 10", normal: 95, anomaly: 5 },
  { date: "May 11", normal: 92, anomaly: 8 },
  { date: "May 12", normal: 97, anomaly: 3 },
  { date: "May 13", normal: 91, anomaly: 9 },
  { date: "May 14", normal: 94, anomaly: 6 },
  { date: "May 15", normal: 98, anomaly: 2 },
  { date: "May 16", normal: 93, anomaly: 7 },
];

// Risk assessment overview data
export const riskAssessmentSummaryData = [
  { category: "Low Risk", count: 45, color: "#4caf50" },
  { category: "Medium Risk", count: 32, color: "#ff9800" },
  { category: "High Risk", count: 18, color: "#f44336" },
];

// Risk factors distribution
export const riskFactorsData = [
  { factor: "Age", weight: 15, description: "Age correlates with financial stability" },
  { factor: "Income", weight: 25, description: "Higher income reduces financial risk" },
  { factor: "KYC Status", weight: 30, description: "Verified identity significantly reduces risk" },
  { factor: "Occupation", weight: 20, description: "Job stability affects financial reliability" },
  { factor: "Marital Status", weight: 10, description: "Affects financial responsibilities" },
];

// Monthly risk assessment trends
export const riskTrendsData = [
  { month: "Jan", avgScore: 42, highRiskUsers: 15 },
  { month: "Feb", avgScore: 44, highRiskUsers: 16 },
  { month: "Mar", avgScore: 48, highRiskUsers: 20 },
  { month: "Apr", avgScore: 45, highRiskUsers: 18 },
  { month: "May", avgScore: 41, highRiskUsers: 14 },
  { month: "Jun", avgScore: 39, highRiskUsers: 12 },
];

