
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage } from "@/components/LanguageToggle";
import { Button } from "@/components/ui/button";
import { 
  Building, 
  Heart, 
  Users, 
  Award, 
  Target, 
  Clock, 
  ChevronRight 
} from "lucide-react";

const About = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { currentLanguage } = useLanguage();
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  // Content translations
  const content = {
    en: {
      title: "About Vyom",
      subtitle: "Building the future of digital banking",
      description: "Founded in 2018, Vyom is a pioneering digital banking platform that combines cutting-edge technology with customer-centric services to revolutionize the banking experience.",
      mission: "Our Mission",
      missionText: "To make banking accessible, secure, and simple for everyone through innovative technology and exceptional service.",
      vision: "Our Vision",
      visionText: "To become the world's most trusted and innovative financial platform, empowering people to achieve financial freedom.",
      values: "Our Values",
      team: "Leadership Team",
      cta: "Join Our Team",
      ctaText: "Be part of our mission to transform banking. Explore career opportunities at Vyom.",
      history: "Our Journey",
      valueItems: [
        { title: "Innovation", description: "We constantly push boundaries to create better solutions." },
        { title: "Trust", description: "Security and reliability are at the core of everything we do." },
        { title: "Inclusion", description: "We build for everyone, regardless of background or location." },
        { title: "Excellence", description: "We hold ourselves to the highest standards in all we do." }
      ],
      teamMembers: [
        { name: "Ajay Patel", role: "Founder & CEO", image: "https://randomuser.me/api/portraits/men/32.jpg" },
        { name: "Priya Sharma", role: "Chief Technology Officer", image: "https://randomuser.me/api/portraits/women/44.jpg" },
        { name: "Vikram Singh", role: "Chief Financial Officer", image: "https://randomuser.me/api/portraits/men/86.jpg" },
        { name: "Meera Kapoor", role: "Chief Product Officer", image: "https://randomuser.me/api/portraits/women/65.jpg" }
      ],
      timeline: [
        { year: "2018", title: "Founded", description: "Vyom was founded with a vision to transform banking." },
        { year: "2019", title: "First Product Launch", description: "Launched our mobile banking application." },
        { year: "2020", title: "Expansion", description: "Expanded services to include investments and loans." },
        { year: "2021", title: "AI Integration", description: "Implemented AI-powered security and insights." },
        { year: "2022", title: "Global Reach", description: "Extended operations to international markets." },
        { year: "2023", title: "10M+ Users", description: "Crossed the milestone of 10 million users." }
      ]
    },
    hi: {
      title: "व्योम के बारे में",
      subtitle: "डिजिटल बैंकिंग का भविष्य बनाना",
      description: "2018 में स्थापित, व्योम एक अग्रणी डिजिटल बैंकिंग प्लेटफॉर्म है जो बैंकिंग अनुभव को क्रांतिकारी बनाने के लिए अत्याधुनिक तकनीक को ग्राहक-केंद्रित सेवाओं के साथ जोड़ता है।",
      mission: "हमारा मिशन",
      missionText: "नवीन तकनीक और असाधारण सेवा के माध्यम से हर किसी के लिए बैंकिंग को सुलभ, सुरक्षित और सरल बनाना।",
      vision: "हमारी दृष्टि",
      visionText: "दुनिया का सबसे भरोसेमंद और नवीन वित्तीय प्लेटफॉर्म बनना, जो लोगों को वित्तीय स्वतंत्रता प्राप्त करने के लिए सशक्त बनाता है।",
      values: "हमारे मूल्य",
      team: "नेतृत्व टीम",
      cta: "हमारी टीम से जुड़ें",
      ctaText: "बैंकिंग को बदलने के हमारे मिशन का हिस्सा बनें। व्योम में करियर के अवसरों का पता लगाएं।",
      history: "हमारी यात्रा",
      valueItems: [
        { title: "नवाचार", description: "हम बेहतर समाधान बनाने के लिए लगातार सीमाओं को आगे बढ़ाते हैं।" },
        { title: "विश्वास", description: "सुरक्षा और विश्वसनीयता हमारे हर काम का आधार है।" },
        { title: "समावेश", description: "हम सभी के लिए बनाते हैं, चाहे पृष्ठभूमि या स्थान कुछ भी हो।" },
        { title: "उत्कृष्टता", description: "हम अपने सभी कार्यों में खुद को उच्चतम मानकों पर रखते हैं।" }
      ],
      teamMembers: [
        { name: "अजय पटेल", role: "संस्थापक और सीईओ", image: "https://randomuser.me/api/portraits/men/32.jpg" },
        { name: "प्रिया शर्मा", role: "मुख्य तकनीकी अधिकारी", image: "https://randomuser.me/api/portraits/women/44.jpg" },
        { name: "विक्रम सिंह", role: "मुख्य वित्तीय अधिकारी", image: "https://randomuser.me/api/portraits/men/86.jpg" },
        { name: "मीरा कपूर", role: "मुख्य उत्पाद अधिकारी", image: "https://randomuser.me/api/portraits/women/65.jpg" }
      ],
      timeline: [
        { year: "2018", title: "स्थापना", description: "व्योम की स्थापना बैंकिंग को बदलने के दृष्टिकोण के साथ की गई थी।" },
        { year: "2019", title: "पहला उत्पाद लॉन्च", description: "हमारे मोबाइल बैंकिंग एप्लिकेशन को लॉन्च किया।" },
        { year: "2020", title: "विस्तार", description: "निवेश और ऋण को शामिल करने के लिए सेवाओं का विस्तार किया।" },
        { year: "2021", title: "एआई एकीकरण", description: "एआई-संचालित सुरक्षा और अंतर्दृष्टि लागू की।" },
        { year: "2022", title: "वैश्विक पहुंच", description: "अंतरराष्ट्रीय बाजारों में संचालन का विस्तार किया।" },
        { year: "2023", title: "10M+ उपयोगकर्ता", description: "10 मिलियन उपयोगकर्ताओं का मील का पत्थर पार किया।" }
      ]
    },
    mr: {
      title: "व्योम बद्दल",
      subtitle: "डिजिटल बँकिंगचे भविष्य घडवत आहे",
      description: "2018 मध्ये स्थापित, व्योम हे एक अग्रगण्य डिजिटल बँकिंग प्लॅटफॉर्म आहे जे अत्याधुनिक तंत्रज्ञान आणि ग्राहक-केंद्रित सेवा एकत्र करून बँकिंग अनुभवात क्रांती आणते.",
      mission: "आमचे ध्येय",
      missionText: "नाविन्यपूर्ण तंत्रज्ञान आणि उत्कृष्ट सेवांद्वारे प्रत्येकासाठी बँकिंग सुलभ, सुरक्षित आणि सोपे करणे.",
      vision: "आमची दृष्टी",
      visionText: "जगातील सर्वात विश्वासार्ह आणि नाविन्यपूर्ण आर्थिक प्लॅटफॉर्म बनणे, जे लोकांना आर्थिक स्वातंत्र्य मिळविण्यासाठी सक्षम करते.",
      values: "आमची मूल्ये",
      team: "नेतृत्व संघ",
      cta: "आमच्या संघात सामील व्हा",
      ctaText: "बँकिंग बदलण्याच्या आमच्या मिशनचा भाग बना. व्योम मध्ये करिअरच्या संधी शोधा.",
      history: "आमचा प्रवास",
      valueItems: [
        { title: "नवकल्पना", description: "आम्ही चांगली समाधाने तयार करण्यासाठी सातत्याने सीमा ओलांडतो." },
        { title: "विश्वास", description: "सुरक्षा आणि विश्वासार्हता हे आम्ही करत असलेल्या प्रत्येक गोष्टीचे मूळ आहे." },
        { title: "समावेश", description: "आम्ही पार्श्वभूमी किंवा स्थान कोणतेही असले तरी प्रत्येकासाठी बांधतो." },
        { title: "उत्कृष्टता", description: "आम्ही आमच्या सर्व कामात स्वतःला सर्वोच्च मानकांवर राखतो." }
      ],
      teamMembers: [
        { name: "अजय पटेल", role: "संस्थापक आणि सीईओ", image: "https://randomuser.me/api/portraits/men/32.jpg" },
        { name: "प्रिया शर्मा", role: "मुख्य तंत्रज्ञान अधिकारी", image: "https://randomuser.me/api/portraits/women/44.jpg" },
        { name: "विक्रम सिंह", role: "मुख्य वित्तीय अधिकारी", image: "https://randomuser.me/api/portraits/men/86.jpg" },
        { name: "मीरा कपूर", role: "मुख्य उत्पादन अधिकारी", image: "https://randomuser.me/api/portraits/women/65.jpg" }
      ],
      timeline: [
        { year: "2018", title: "स्थापना", description: "व्योम ची स्थापना बँकिंग बदलण्याच्या दृष्टीने झाली." },
        { year: "2019", title: "पहिले उत्पादन लाँच", description: "आमचे मोबाइल बँकिंग अॅप्लिकेशन लाँच केले." },
        { year: "2020", title: "विस्तार", description: "गुंतवणूक आणि कर्ज समाविष्ट करण्यासाठी सेवांचा विस्तार केला." },
        { year: "2021", title: "AI एकत्रीकरण", description: "AI-संचालित सुरक्षा आणि अंतर्दृष्टी अंमलात आणली." },
        { year: "2022", title: "जागतिक पोहोच", description: "आंतरराष्ट्रीय बाजारपेठांमध्ये कार्य विस्तारित केले." },
        { year: "2023", title: "10M+ वापरकर्ते", description: "10 दशलक्ष वापरकर्त्यांचा टप्पा ओलांडला." }
      ]
    }
  };

  // Get content based on current language
  const t = content[currentLanguage.code as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-40 pb-20 px-4 bg-gradient-to-b from-white to-vyom-light">
        <div className="container mx-auto">
          <div className={`max-w-3xl mx-auto text-center ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}>
            <h1 className="text-4xl md:text-5xl font-bold text-vyom-blue mb-6">{t.title}</h1>
            <p className="text-xl text-vyom-red font-medium mb-8">{t.subtitle}</p>
            <p className="text-lg text-vyom-gray">{t.description}</p>
          </div>
        </div>
      </section>
      
      {/* Mission & Vision */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className={`bg-vyom-light p-8 rounded-xl shadow-md transform transition-all duration-300 hover:shadow-lg ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="w-16 h-16 mb-6 rounded-full bg-vyom-red flex items-center justify-center">
                <Target className="text-white h-8 w-8" />
              </div>
              <h2 className="text-2xl font-bold text-vyom-blue mb-4">{t.mission}</h2>
              <p className="text-vyom-gray">{t.missionText}</p>
            </div>
            
            <div className={`bg-vyom-light p-8 rounded-xl shadow-md transform transition-all duration-300 hover:shadow-lg ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
              <div className="w-16 h-16 mb-6 rounded-full bg-vyom-blue flex items-center justify-center">
                <Heart className="text-white h-8 w-8" />
              </div>
              <h2 className="text-2xl font-bold text-vyom-blue mb-4">{t.vision}</h2>
              <p className="text-vyom-gray">{t.visionText}</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Values */}
      <section className="py-20 px-4 bg-vyom-light">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-vyom-blue mb-4">{t.values}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.valueItems.map((value, index) => (
              <div 
                key={index}
                className={`bg-white p-6 rounded-xl shadow-md transform transition-all duration-300 hover:-translate-y-2 hover:shadow-lg ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}
                style={{ animationDelay: `${0.2 + 0.1 * index}s` }}
              >
                <h3 className="text-xl font-semibold text-vyom-red mb-3">{value.title}</h3>
                <p className="text-vyom-gray">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Team */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-vyom-blue mb-4">{t.team}</h2>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.teamMembers.map((member, index) => (
              <div 
                key={index}
                className={`text-center ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}
                style={{ animationDelay: `${0.2 + 0.1 * index}s` }}
              >
                <div className="relative mb-4 mx-auto w-32 h-32 rounded-full overflow-hidden transition-all duration-300 transform hover:scale-105">
                  <img src={member.image} alt={member.name} className="w-full h-full object-cover" />
                </div>
                <h3 className="text-xl font-semibold text-vyom-blue">{member.name}</h3>
                <p className="text-vyom-gray">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* History Timeline */}
      <section className="py-20 px-4 bg-vyom-light">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-vyom-blue mb-4">{t.history}</h2>
          </div>
          
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-vyom-blue/30 hidden md:block"></div>
            
            <div className="space-y-12">
              {t.timeline.map((item, index) => (
                <div 
                  key={index}
                  className={`flex flex-col md:flex-row items-center gap-8 ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}
                  style={{ animationDelay: `${0.2 + 0.1 * index}s` }}
                >
                  <div className={`md:w-1/2 ${index % 2 === 0 ? 'md:text-right' : 'md:order-3'}`}>
                    <div className={`p-6 bg-white rounded-xl shadow-md ${index % 2 === 0 ? 'ml-auto mr-0' : 'mr-auto ml-0'} transform transition-all duration-300 hover:shadow-xl max-w-lg`}>
                      <div className="text-vyom-red font-bold text-xl mb-2">{item.year}</div>
                      <h3 className="text-vyom-blue font-semibold text-lg mb-2">{item.title}</h3>
                      <p className="text-vyom-gray">{item.description}</p>
                    </div>
                  </div>
                  
                  <div className="md:w-0 z-10 order-2">
                    <div className="w-12 h-12 rounded-full bg-vyom-red flex items-center justify-center">
                      <Clock className="text-white h-6 w-6" />
                    </div>
                  </div>
                  
                  <div className="md:w-1/2 hidden md:block order-1"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-20 px-4 bg-gradient-to-r from-vyom-blue to-vyom-navy text-white">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">{t.cta}</h2>
            <p className="text-white/80 mb-8">{t.ctaText}</p>
            <Link to="/contact">
              <Button className="bg-vyom-red hover:bg-vyom-red/90 text-white">
                {t.cta}
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default About;
