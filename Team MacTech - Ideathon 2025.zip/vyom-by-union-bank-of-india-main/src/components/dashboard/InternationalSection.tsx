
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { Account } from "./AccountsSection";
import { NavigateFunction } from "react-router-dom";

// Schema for international transfer form
const internationalTransferSchema = z.object({
  fromAccount: z.string(),
  country: z.string().min(1, "Country is required"),
  bankName: z.string().min(1, "Bank name is required"),
  swiftCode: z.string().min(8, "Valid SWIFT code is required"),
  accountNumber: z.string().min(1, "Account number is required"),
  recipientName: z.string().min(1, "Recipient name is required"),
  currency: z.string(),
  amount: z.string().min(1, "Amount is required"),
  purpose: z.string().min(1, "Purpose is required"),
});

type InternationalTransferFormValues = z.infer<typeof internationalTransferSchema>;

export interface InternationalSectionProps {
  accounts: Account[];
  navigate: NavigateFunction;
}

export const InternationalSection = ({ accounts, navigate }: InternationalSectionProps) => {
  const [isInternationalTransferring, setIsInternationalTransferring] = useState(false);

  const internationalForm = useForm<InternationalTransferFormValues>({
    resolver: zodResolver(internationalTransferSchema),
    defaultValues: {
      fromAccount: accounts && accounts.length > 0 ? `${accounts[0].type} (₹${accounts[0].balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})` : "",
      country: "",
      bankName: "",
      swiftCode: "",
      accountNumber: "",
      recipientName: "",
      currency: "USD",
      amount: "",
      purpose: "",
    },
  });

  const onSubmitInternationalTransfer = (values: InternationalTransferFormValues) => {
    setIsInternationalTransferring(true);
    
    setTimeout(() => {
      toast({
        title: "International Transfer Initiated",
        description: `₹${values.amount} (${values.currency}) will be transferred to ${values.recipientName} once approved.`,
      });
      
      internationalForm.reset({
        fromAccount: accounts && accounts.length > 0 ? `${accounts[0].type} (₹${accounts[0].balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})` : "",
        country: "",
        bankName: "",
        swiftCode: "",
        accountNumber: "",
        recipientName: "",
        currency: "USD",
        amount: "",
        purpose: "",
      });
      
      setIsInternationalTransferring(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-vyom-blue">International Transfers</h2>
        <Button 
          onClick={() => navigate('/dashboard/InternationalTransactions')}
          variant="outline"
        >
          View International Transactions
        </Button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Send Money Internationally</CardTitle>
            <CardDescription>Transfer money to bank accounts in other countries</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...internationalForm}>
              <form onSubmit={internationalForm.handleSubmit(onSubmitInternationalTransfer)} className="space-y-4">
                <FormField
                  control={internationalForm.control}
                  name="fromAccount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From Account</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select an account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {accounts.map(account => (
                            <SelectItem 
                              key={account.id} 
                              value={`${account.type} (₹${account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})`}
                            >
                              {account.type} (₹{account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={internationalForm.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input placeholder="Recipient's country" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={internationalForm.control}
                    name="currency"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Currency</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select currency" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="USD">USD - US Dollar</SelectItem>
                            <SelectItem value="EUR">EUR - Euro</SelectItem>
                            <SelectItem value="GBP">GBP - British Pound</SelectItem>
                            <SelectItem value="JPY">JPY - Japanese Yen</SelectItem>
                            <SelectItem value="AUD">AUD - Australian Dollar</SelectItem>
                            <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                            <SelectItem value="SGD">SGD - Singapore Dollar</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={internationalForm.control}
                  name="bankName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bank Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Recipient's bank name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={internationalForm.control}
                    name="swiftCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>SWIFT/BIC Code</FormLabel>
                        <FormControl>
                          <Input placeholder="Bank SWIFT code" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={internationalForm.control}
                    name="accountNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account Number/IBAN</FormLabel>
                        <FormControl>
                          <Input placeholder="Recipient's account number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={internationalForm.control}
                  name="recipientName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Recipient Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Full name of recipient" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={internationalForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Amount</FormLabel>
                        <FormControl>
                          <Input placeholder="Amount to transfer" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={internationalForm.control}
                    name="purpose"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Purpose of Transfer</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select purpose" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Family Support">Family Support</SelectItem>
                            <SelectItem value="Education">Education</SelectItem>
                            <SelectItem value="Medical">Medical</SelectItem>
                            <SelectItem value="Business">Business</SelectItem>
                            <SelectItem value="Investment">Investment</SelectItem>
                            <SelectItem value="Travel">Travel</SelectItem>
                            <SelectItem value="Other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="pt-2">
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isInternationalTransferring}
                  >
                    {isInternationalTransferring ? "Processing..." : "Send Money"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>International Transfer Services</CardTitle>
              <CardDescription>Our global money transfer solutions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold text-vyom-blue mb-2">Why Transfer With Vyom Bank?</h3>
                <ul className="space-y-2 list-disc pl-5">
                  <li>Competitive exchange rates</li>
                  <li>Low transfer fees</li>
                  <li>Fast processing times</li>
                  <li>Secure, traceable transfers</li>
                  <li>Support for over 100 currencies</li>
                </ul>
              </div>
              
              <div className="p-4 border rounded-lg">
                <h3 className="font-semibold text-vyom-blue mb-2">Fee Information</h3>
                <p className="text-sm text-vyom-gray mb-2">Our international transfer fees vary based on:</p>
                <ul className="space-y-1 list-disc pl-5 text-sm">
                  <li>Transfer amount</li>
                  <li>Destination country</li>
                  <li>Selected currency</li>
                  <li>Transfer method</li>
                </ul>
                <p className="text-sm text-vyom-teal mt-2">View detailed fee structure</p>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => navigate("/dashboard/InternationalTransfers")}
              >
                Learn More About International Transfers
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
