
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const supabaseUrl = Deno.env.get('SUPABASE_URL') ?? '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Categories and sample transactions
const transactionCategories = [
  'Groceries', 'Dining', 'Shopping', 'Transportation', 'Utilities', 
  'Entertainment', 'Healthcare', 'Travel', 'Education', 'Housing'
];

const frequencies = ['Daily', 'Weekly', 'Monthly'];

// Generate random amount between min and max
const randomAmount = (min: number, max: number) => {
  return Math.floor(Math.random() * (max - min + 1) + min);
};

// Generate random date in the last 3 months
const randomDate = () => {
  const now = new Date();
  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(now.getMonth() - 3);
  
  const randomTimestamp = threeMonthsAgo.getTime() + 
    Math.random() * (now.getTime() - threeMonthsAgo.getTime());
  
  return new Date(randomTimestamp).toISOString();
};

// Generate sample transactions for a user
const generateTransactions = (userId: string, count: number) => {
  const transactions = [];
  
  for (let i = 0; i < count; i++) {
    const category = transactionCategories[Math.floor(Math.random() * transactionCategories.length)];
    
    // Adjust amounts based on category
    let minAmount, maxAmount;
    
    switch (category) {
      case 'Groceries':
        minAmount = 500; maxAmount = 5000;
        break;
      case 'Dining':
        minAmount = 200; maxAmount = 3000;
        break;
      case 'Shopping':
        minAmount = 1000; maxAmount = 10000;
        break;
      case 'Transportation':
        minAmount = 100; maxAmount = 2000;
        break;
      case 'Utilities':
        minAmount = 500; maxAmount = 5000;
        break;
      case 'Entertainment':
        minAmount = 200; maxAmount = 5000;
        break;
      case 'Healthcare':
        minAmount = 500; maxAmount = 15000;
        break;
      case 'Travel':
        minAmount = 2000; maxAmount = 50000;
        break;
      case 'Education':
        minAmount = 1000; maxAmount = 20000;
        break;
      case 'Housing':
        minAmount = 5000; maxAmount = 50000;
        break;
      default:
        minAmount = 100; maxAmount = 5000;
    }
    
    const transaction = {
      user_id: userId,
      transaction_category: category,
      transaction_amount: randomAmount(minAmount, maxAmount),
      transaction_date: randomDate(),
      transaction_frequency: frequencies[Math.floor(Math.random() * frequencies.length)]
    };
    
    transactions.push(transaction);
  }
  
  return transactions;
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request
    const { userId, count = 20 } = await req.json();
    
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with service role key
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Generate sample transactions
    const transactions = generateTransactions(userId, count);
    
    // Insert transactions into the database
    const { data, error } = await supabase
      .from('user_transactions')
      .insert(transactions);
      
    if (error) {
      console.error('Error inserting transactions:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to insert transactions' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Return success response
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `${count} sample transactions generated for user ${userId}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in generate-sample-transactions function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
