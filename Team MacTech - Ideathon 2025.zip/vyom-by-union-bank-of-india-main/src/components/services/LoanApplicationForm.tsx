
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/hooks/use-toast";

interface LoanApplicationFormProps {
  loanType: string;
  onClose: () => void;
}

const LoanApplicationForm: React.FC<LoanApplicationFormProps> = ({ loanType, onClose }) => {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    amount: "",
    purpose: "",
    term: "3-years"
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Loan Application Submitted",
      description: `Thank you, ${formData.fullName}! Your ${loanType} loan application has been submitted successfully. A loan officer will contact you shortly.`,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl p-6 md:p-8 max-w-md w-full animate-fade-in">
        <h3 className="text-2xl font-bold mb-4 text-vyom-blue">Apply for {loanType} Loan</h3>
        <p className="text-vyom-gray mb-6">Complete the form below to start your loan application process.</p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="fullName" className="block text-sm font-medium mb-1">Full Name</label>
            <Input 
              id="fullName" 
              name="fullName" 
              value={formData.fullName} 
              onChange={handleInputChange} 
              required 
              placeholder="John Doe"
            />
          </div>
          
          <div>
            <label htmlFor="email" className="block text-sm font-medium mb-1">Email Address</label>
            <Input 
              id="email" 
              name="email" 
              type="email" 
              value={formData.email} 
              onChange={handleInputChange} 
              required 
              placeholder="john@example.com"
            />
          </div>
          
          <div>
            <label htmlFor="phone" className="block text-sm font-medium mb-1">Phone Number</label>
            <Input 
              id="phone" 
              name="phone" 
              value={formData.phone} 
              onChange={handleInputChange} 
              required 
              placeholder="+91 9876543210"
            />
          </div>
          
          <div>
            <label htmlFor="amount" className="block text-sm font-medium mb-1">Loan Amount (₹)</label>
            <Input 
              id="amount" 
              name="amount" 
              type="number" 
              value={formData.amount} 
              onChange={handleInputChange} 
              required 
              placeholder="500000"
            />
          </div>
          
          <div>
            <label htmlFor="purpose" className="block text-sm font-medium mb-1">Loan Purpose</label>
            <textarea 
              id="purpose" 
              name="purpose" 
              value={formData.purpose} 
              onChange={handleInputChange} 
              className="flex min-h-24 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm"
              placeholder="Please describe the purpose of the loan..."
              required
            />
          </div>
          
          <div>
            <label htmlFor="term" className="block text-sm font-medium mb-1">Loan Term</label>
            <select 
              id="term" 
              name="term" 
              value={formData.term} 
              onChange={handleInputChange}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm"
              required
            >
              <option value="1-year">1 Year</option>
              <option value="3-years">3 Years</option>
              <option value="5-years">5 Years</option>
              <option value="10-years">10 Years</option>
              <option value="15-years">15 Years</option>
              <option value="20-years">20 Years</option>
            </select>
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button type="submit">Submit Application</Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default LoanApplicationForm;
