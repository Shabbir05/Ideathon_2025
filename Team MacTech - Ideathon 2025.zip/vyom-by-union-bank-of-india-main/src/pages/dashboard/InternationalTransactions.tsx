
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Globe, 
  ArrowRightLeft, 
  DollarSign, 
  Euro, 
  PoundSterling, 
  Building2, 
  FileText, 
  Calendar, 
  CreditCard, 
  UserCheck, 
  BadgeCheck, 
  ChevronRight,
  Landmark,
  CircleDollarSign,
  LineChart,
  ShieldCheck,
  Clock,
  AlertCircle,
  Send
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const InternationalTransactions = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [currentTab, setCurrentTab] = useState("exchange");
  const [exchangeAmount, setExchangeAmount] = useState("");
  const [exchangeCurrency, setExchangeCurrency] = useState("USD");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferCurrency, setTransferCurrency] = useState("USD");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showRateAlert, setShowRateAlert] = useState(false);
  const [saveAsBeneficiary, setSaveAsBeneficiary] = useState(false);
  
  // Exchange rates (for demo purposes)
  const exchangeRates = {
    USD: 83.12,
    EUR: 89.45,
    GBP: 105.67,
    AUD: 54.32,
    CAD: 60.78,
    SGD: 61.23,
    AED: 22.64,
  };
  
  // Transaction history
  const transactions = [
    {
      id: "TRX-INT-001",
      type: "Outward",
      date: "12 Jun 2023",
      amount: "USD 2,500",
      amountInr: "₹2,07,800",
      status: "Completed",
      recipient: "John Smith, USA",
      description: "Business Payment"
    },
    {
      id: "TRX-INT-002",
      type: "Inward",
      date: "28 May 2023",
      amount: "EUR 1,800",
      amountInr: "₹1,61,010",
      status: "Completed",
      recipient: "Global Trading Co., Germany",
      description: "Export Proceeds"
    },
    {
      id: "TRX-INT-003",
      type: "Outward",
      date: "15 May 2023",
      amount: "GBP 1,200",
      amountInr: "₹1,26,804",
      status: "Completed",
      recipient: "University of London, UK",
      description: "Education Fees"
    }
  ];
  
  // Popular beneficiaries
  const popularBeneficiaries = [
    {
      id: 1,
      name: "John Smith",
      accountNo: "12345678901234",
      bank: "Bank of America",
      country: "USA",
      currency: "USD",
      lastTransfer: "12 Jun 2023"
    },
    {
      id: 2,
      name: "Global Trading Co.",
      accountNo: "DE89370400440532013000",
      bank: "Deutsche Bank",
      country: "Germany",
      currency: "EUR",
      lastTransfer: "28 May 2023"
    },
    {
      id: 3,
      name: "University of London",
      accountNo: "GB29NWBK60161331926819",
      bank: "Barclays Bank",
      country: "UK",
      currency: "GBP",
      lastTransfer: "15 May 2023"
    }
  ];

  // Forex rates
  const forexRates = [
    { currency: "USD", name: "US Dollar", buy: 83.12, sell: 83.42 },
    { currency: "EUR", name: "Euro", buy: 89.45, sell: 89.85 },
    { currency: "GBP", name: "British Pound", buy: 105.67, sell: 106.12 },
    { currency: "AUD", name: "Australian Dollar", buy: 54.32, sell: 54.72 },
    { currency: "CAD", name: "Canadian Dollar", buy: 60.78, sell: 61.18 },
    { currency: "SGD", name: "Singapore Dollar", buy: 61.23, sell: 61.63 },
    { currency: "AED", name: "UAE Dirham", buy: 22.64, sell: 22.84 }
  ];
  
  const internationalTransferSchema = z.object({
    beneficiaryName: z.string().min(3, "Beneficiary name is required"),
    accountNumber: z.string().min(8, "Account number is required"),
    swiftCode: z.string().min(8, "Valid SWIFT code is required"),
    bankName: z.string().min(3, "Bank name is required"),
    bankAddress: z.string().min(3, "Bank address is required"),
    country: z.string().min(1, "Country is required"),
    currency: z.string().min(1, "Currency is required"),
    amount: z.string().min(1, "Amount is required"),
    amountInWords: z.string().optional(),
    purpose: z.string().min(3, "Purpose is required"),
    remitterReference: z.string().optional(),
    chargesBearer: z.string(),
  });

  type InternationalTransferFormValues = z.infer<typeof internationalTransferSchema>;

  const remittanceForm = useForm<InternationalTransferFormValues>({
    resolver: zodResolver(internationalTransferSchema),
    defaultValues: {
      beneficiaryName: "",
      accountNumber: "",
      swiftCode: "",
      bankName: "",
      bankAddress: "",
      country: "",
      currency: "USD",
      amount: "",
      amountInWords: "",
      purpose: "",
      remitterReference: "",
      chargesBearer: "OUR", // OUR, BEN, SHA
    },
  });

  // Handle currency exchange
  const handleExchange = () => {
    if (!exchangeAmount || isNaN(parseFloat(exchangeAmount))) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    setTimeout(() => {
      const inrAmount = parseFloat(exchangeAmount) * exchangeRates[exchangeCurrency as keyof typeof exchangeRates];
      
      toast({
        title: "Exchange Rate",
        description: `${exchangeAmount} ${exchangeCurrency} = ₹${inrAmount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`,
      });
      
      setShowRateAlert(true);
      setIsProcessing(false);
    }, 1500);
  };
  
  // Handle international transfer
  const handleTransfer = () => {
    if (!transferAmount || isNaN(parseFloat(transferAmount))) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    setTimeout(() => {
      toast({
        title: "Transfer Initiated",
        description: `Your request to transfer ${transferAmount} ${transferCurrency} has been initiated. You will be notified once processed.`,
      });
      
      setIsProcessing(false);
      navigate("/dashboard/international-transfers");
    }, 2000);
  };
  
  // Handle remittance submission
  const onRemittanceSubmit = (data: InternationalTransferFormValues) => {
    setIsProcessing(true);
    
    setTimeout(() => {
      toast({
        title: "Remittance Initiated",
        description: `Your remittance request for ${data.currency} ${data.amount} to ${data.beneficiaryName} has been successfully submitted.`,
      });
      
      setIsProcessing(false);
      remittanceForm.reset();
      navigate("/dashboard/international-transfers");
    }, 2000);
  };

  // Currency icon mapper
  const getCurrencyIcon = (currency: string) => {
    switch (currency) {
      case "USD":
        return <DollarSign className="text-green-600" size={16} />;
      case "EUR":
        return <Euro className="text-blue-600" size={16} />;
      case "GBP":
        return <PoundSterling className="text-purple-600" size={16} />;
      default:
        return <CircleDollarSign className="text-vyom-blue" size={16} />;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-vyom-blue">International Banking</h1>
          <p className="text-muted-foreground">Manage your international transactions, transfers, and currency exchange</p>
        </div>
        <Button 
          variant="international" 
          onClick={() => navigate("/dashboard/international-transfers")}
          className="flex items-center gap-2"
        >
          <Globe size={18} />
          New International Transfer
        </Button>
      </div>
      
      <Tabs defaultValue="exchange" value={currentTab} onValueChange={setCurrentTab} className="space-y-6">
        <TabsList className="grid grid-cols-4 max-w-[600px] bg-vyom-light">
          <TabsTrigger value="exchange" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Currency Exchange
          </TabsTrigger>
          <TabsTrigger value="remittance" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Remittance
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            History
          </TabsTrigger>
          <TabsTrigger value="rates" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Forex Rates
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="exchange" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-2 shadow-md hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <CardTitle>Currency Exchange</CardTitle>
                <CardDescription>Convert your INR to any foreign currency or vice versa</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="fromCurrency">From Currency</Label>
                    <Select defaultValue="INR">
                      <SelectTrigger>
                        <SelectValue placeholder="INR" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="INR">Indian Rupee (INR)</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Label htmlFor="fromAmount">Amount</Label>
                    <Input 
                      id="fromAmount" 
                      placeholder="Enter amount" 
                      value={exchangeAmount} 
                      onChange={(e) => setExchangeAmount(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-3">
                    <Label htmlFor="toCurrency">To Currency</Label>
                    <Select value={exchangeCurrency} onValueChange={setExchangeCurrency}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">US Dollar (USD)</SelectItem>
                        <SelectItem value="EUR">Euro (EUR)</SelectItem>
                        <SelectItem value="GBP">British Pound (GBP)</SelectItem>
                        <SelectItem value="AUD">Australian Dollar (AUD)</SelectItem>
                        <SelectItem value="CAD">Canadian Dollar (CAD)</SelectItem>
                        <SelectItem value="SGD">Singapore Dollar (SGD)</SelectItem>
                        <SelectItem value="AED">UAE Dirham (AED)</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Label htmlFor="convertedAmount">Converted Amount</Label>
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <Input 
                          id="convertedAmount" 
                          readOnly
                          value={
                            exchangeAmount && !isNaN(parseFloat(exchangeAmount))
                              ? (parseFloat(exchangeAmount) / exchangeRates[exchangeCurrency as keyof typeof exchangeRates]).toFixed(2)
                              : ""
                          }
                          className="pr-10"
                        />
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                          {getCurrencyIcon(exchangeCurrency)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {showRateAlert && (
                  <div className="bg-vyom-light border border-vyom-blue/20 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="text-vyom-blue mt-0.5" size={18} />
                      <div>
                        <p className="font-medium text-vyom-blue">Current Exchange Rate</p>
                        <p className="text-sm">
                          1 {exchangeCurrency} = ₹{exchangeRates[exchangeCurrency as keyof typeof exchangeRates].toFixed(2)}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Rate is indicative and subject to change at the time of transaction
                        </p>
                      </div>
                    </div>
                  </div>
                )}
                
                <div className="flex gap-4">
                  <Button 
                    variant="international" 
                    onClick={handleExchange}
                    disabled={isProcessing}
                    className="flex-1"
                  >
                    {isProcessing ? "Processing..." : "Get Exchange Rate"}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => navigate("/dashboard/international-transfers")}
                    className="flex-1"
                  >
                    Proceed to Transfer
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="text-xs text-muted-foreground border-t pt-4">
                Note: Exchange rates are indicative and may vary at the time of transaction.
              </CardFooter>
            </Card>
            
            <Card className="shadow-md hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <CardTitle>Today's Rates</CardTitle>
                <CardDescription>Popular currency exchange rates</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-4">
                    {forexRates.slice(0, 5).map((rate, index) => (
                      <div key={index} className="flex items-center justify-between pb-2 border-b">
                        <div className="flex items-center gap-2">
                          {getCurrencyIcon(rate.currency)}
                          <div>
                            <p className="font-medium">{rate.currency}</p>
                            <p className="text-xs text-muted-foreground">{rate.name}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">₹{rate.buy.toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground">Buy</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
                
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setCurrentTab("rates")}
                  >
                    View All Rates
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-3 shadow-md hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <CardTitle>Available Services</CardTitle>
                <CardDescription>Explore our international banking services</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                  <Button 
                    variant="outline"
                    className="h-auto py-6 flex flex-col items-center justify-center gap-3 hover:bg-vyom-light/50 hover:border-vyom-blue/30"
                    onClick={() => navigate("/dashboard/international-transfers")}
                  >
                    <Send className="h-8 w-8 text-vyom-blue" />
                    <div className="text-center">
                      <p className="font-medium">International Transfers</p>
                      <p className="text-xs text-muted-foreground">Send money overseas</p>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline"
                    className="h-auto py-6 flex flex-col items-center justify-center gap-3 hover:bg-vyom-light/50 hover:border-vyom-blue/30"
                    onClick={() => toast({
                      title: "Forex Card",
                      description: "Redirecting to Forex Card application...",
                    })}
                  >
                    <CreditCard className="h-8 w-8 text-vyom-purple" />
                    <div className="text-center">
                      <p className="font-medium">Forex Card</p>
                      <p className="text-xs text-muted-foreground">Multi-currency travel card</p>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline"
                    className="h-auto py-6 flex flex-col items-center justify-center gap-3 hover:bg-vyom-light/50 hover:border-vyom-blue/30"
                    onClick={() => toast({
                      title: "Foreign Currency",
                      description: "Redirecting to Foreign Currency services...",
                    })}
                  >
                    <CircleDollarSign className="h-8 w-8 text-vyom-teal" />
                    <div className="text-center">
                      <p className="font-medium">Foreign Currency</p>
                      <p className="text-xs text-muted-foreground">Cash for your travels</p>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="outline"
                    className="h-auto py-6 flex flex-col items-center justify-center gap-3 hover:bg-vyom-light/50 hover:border-vyom-blue/30"
                    onClick={() => toast({
                      title: "Trade Finance",
                      description: "Redirecting to Trade Finance services...",
                    })}
                  >
                    <Building2 className="h-8 w-8 text-vyom-red" />
                    <div className="text-center">
                      <p className="font-medium">Trade Finance</p>
                      <p className="text-xs text-muted-foreground">Import-Export solutions</p>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="remittance" className="space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>International Remittance</CardTitle>
              <CardDescription>Send money to beneficiaries across the globe</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={remittanceForm.handleSubmit(onRemittanceSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Beneficiary Details</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="beneficiaryName">Beneficiary Name</Label>
                      <Input 
                        id="beneficiaryName" 
                        {...remittanceForm.register("beneficiaryName")} 
                        placeholder="Full name as per bank record"
                      />
                      {remittanceForm.formState.errors.beneficiaryName && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.beneficiaryName.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="accountNumber">Account Number / IBAN</Label>
                      <Input 
                        id="accountNumber" 
                        {...remittanceForm.register("accountNumber")} 
                        placeholder="International account number"
                      />
                      {remittanceForm.formState.errors.accountNumber && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.accountNumber.message}</p>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Bank Details</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="swiftCode">SWIFT / BIC Code</Label>
                      <Input 
                        id="swiftCode" 
                        {...remittanceForm.register("swiftCode")} 
                        placeholder="e.g., BOFAUS3N"
                      />
                      {remittanceForm.formState.errors.swiftCode && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.swiftCode.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bankName">Bank Name</Label>
                      <Input 
                        id="bankName" 
                        {...remittanceForm.register("bankName")} 
                        placeholder="Beneficiary's bank name"
                      />
                      {remittanceForm.formState.errors.bankName && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.bankName.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="bankAddress">Bank Address</Label>
                      <Input 
                        id="bankAddress" 
                        {...remittanceForm.register("bankAddress")} 
                        placeholder="Bank's branch address"
                      />
                      {remittanceForm.formState.errors.bankAddress && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.bankAddress.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="country">Country</Label>
                      <Select 
                        defaultValue={remittanceForm.getValues("country")} 
                        onValueChange={(value) => remittanceForm.setValue("country", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select country" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="US">United States</SelectItem>
                          <SelectItem value="GB">United Kingdom</SelectItem>
                          <SelectItem value="CA">Canada</SelectItem>
                          <SelectItem value="AU">Australia</SelectItem>
                          <SelectItem value="SG">Singapore</SelectItem>
                          <SelectItem value="AE">UAE</SelectItem>
                          <SelectItem value="DE">Germany</SelectItem>
                          <SelectItem value="FR">France</SelectItem>
                        </SelectContent>
                      </Select>
                      {remittanceForm.formState.errors.country && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.country.message}</p>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Transfer Details</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="currency">Currency</Label>
                      <Select 
                        defaultValue={remittanceForm.getValues("currency")} 
                        onValueChange={(value) => remittanceForm.setValue("currency", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select currency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD - US Dollar</SelectItem>
                          <SelectItem value="EUR">EUR - Euro</SelectItem>
                          <SelectItem value="GBP">GBP - British Pound</SelectItem>
                          <SelectItem value="AUD">AUD - Australian Dollar</SelectItem>
                          <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                          <SelectItem value="SGD">SGD - Singapore Dollar</SelectItem>
                          <SelectItem value="AED">AED - UAE Dirham</SelectItem>
                        </SelectContent>
                      </Select>
                      {remittanceForm.formState.errors.currency && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.currency.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="amount">Amount</Label>
                      <Input 
                        id="amount" 
                        {...remittanceForm.register("amount")} 
                        placeholder="Transfer amount"
                      />
                      {remittanceForm.formState.errors.amount && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.amount.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="purpose">Purpose of Remittance</Label>
                      <Select 
                        defaultValue={remittanceForm.getValues("purpose")} 
                        onValueChange={(value) => remittanceForm.setValue("purpose", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select purpose" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Family Maintenance">Family Maintenance</SelectItem>
                          <SelectItem value="Education">Education</SelectItem>
                          <SelectItem value="Medical Treatment">Medical Treatment</SelectItem>
                          <SelectItem value="Business Travel">Business Travel</SelectItem>
                          <SelectItem value="Trade Payment">Trade Payment</SelectItem>
                          <SelectItem value="Investment">Investment</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      {remittanceForm.formState.errors.purpose && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.purpose.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="chargesBearer">Charges Bearer</Label>
                      <Select 
                        defaultValue={remittanceForm.getValues("chargesBearer")} 
                        onValueChange={(value) => remittanceForm.setValue("chargesBearer", value)}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select charges bearer" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="OUR">OUR (Remitter bears all charges)</SelectItem>
                          <SelectItem value="SHA">SHA (Shared charges)</SelectItem>
                          <SelectItem value="BEN">BEN (Beneficiary bears all charges)</SelectItem>
                        </SelectContent>
                      </Select>
                      {remittanceForm.formState.errors.chargesBearer && (
                        <p className="text-xs text-destructive">{remittanceForm.formState.errors.chargesBearer.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="remitterReference">Remitter Reference (Optional)</Label>
                      <Input 
                        id="remitterReference" 
                        {...remittanceForm.register("remitterReference")} 
                        placeholder="Your reference"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="saveAsBeneficiary" 
                    checked={saveAsBeneficiary}
                    onCheckedChange={setSaveAsBeneficiary}
                  />
                  <Label htmlFor="saveAsBeneficiary">Save this beneficiary for future transactions</Label>
                </div>
                
                <div className="flex gap-4">
                  <Button 
                    type="submit" 
                    variant="international"
                    disabled={isProcessing}
                    className="flex-1"
                  >
                    {isProcessing ? "Processing..." : "Submit Remittance"}
                  </Button>
                  
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => remittanceForm.reset()}
                    className="flex-1"
                  >
                    Reset Form
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
          
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Saved Beneficiaries</CardTitle>
              <CardDescription>Your frequently used international beneficiaries</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {popularBeneficiaries.map((beneficiary) => (
                  <Card key={beneficiary.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="h-10 w-10 rounded-full bg-vyom-light flex items-center justify-center">
                          <UserCheck className="h-5 w-5 text-vyom-blue" />
                        </div>
                        <div>
                          <p className="font-medium">{beneficiary.name}</p>
                          <p className="text-sm">{beneficiary.bank}, {beneficiary.country}</p>
                          <p className="text-xs text-muted-foreground">{beneficiary.currency} • Last: {beneficiary.lastTransfer}</p>
                        </div>
                      </div>
                      <div className="mt-3 pt-2 border-t flex justify-end">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-xs"
                          onClick={() => {
                            remittanceForm.setValue("beneficiaryName", beneficiary.name);
                            remittanceForm.setValue("accountNumber", beneficiary.accountNo);
                            remittanceForm.setValue("bankName", beneficiary.bank);
                            remittanceForm.setValue("country", beneficiary.country);
                            remittanceForm.setValue("currency", beneficiary.currency);
                            toast({
                              title: "Beneficiary Selected",
                              description: `${beneficiary.name} details loaded successfully.`,
                            });
                          }}
                        >
                          Use this beneficiary
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Transaction History</CardTitle>
              <CardDescription>Your recent international transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div 
                    key={transaction.id} 
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-lg border hover:bg-vyom-light/30 cursor-pointer transition-colors"
                    onClick={() => toast({
                      title: "Transaction Details",
                      description: `Viewing details for ${transaction.id}`,
                    })}
                  >
                    <div className="flex items-start gap-3 mb-3 sm:mb-0">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        transaction.type === "Outward" 
                          ? "bg-red-100" 
                          : "bg-green-100"
                      }`}>
                        <ArrowRightLeft className={`h-5 w-5 ${
                          transaction.type === "Outward" 
                            ? "text-red-600" 
                            : "text-green-600"
                        }`} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{transaction.id}</p>
                          <Badge variant="outline" className={`text-xs ${
                            transaction.type === "Outward" 
                              ? "bg-red-50 text-red-600 border-red-200" 
                              : "bg-green-50 text-green-600 border-green-200"
                          }`}>
                            {transaction.type}
                          </Badge>
                        </div>
                        <p className="text-sm">{transaction.recipient}</p>
                        <p className="text-xs text-muted-foreground">{transaction.date} • {transaction.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{transaction.amount}</p>
                      <p className="text-sm">{transaction.amountInr}</p>
                      <Badge variant="outline" className="mt-1 text-xs bg-blue-50 text-blue-600 border-blue-200">
                        {transaction.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 flex justify-center">
                <Button variant="outline" onClick={() => toast({
                  title: "View All Transactions",
                  description: "Redirecting to transaction history page...",
                })}>
                  View All Transactions
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Pending Transactions</CardTitle>
              <CardDescription>Transactions that are awaiting processing or approval</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-8 text-center">
                <Clock className="h-12 w-12 mx-auto text-vyom-blue opacity-70 mb-4" />
                <h3 className="text-lg font-medium mb-2">No Pending Transactions</h3>
                <p className="text-muted-foreground mb-6">
                  You don't have any international transactions pending approval or processing.
                </p>
                <Button onClick={() => setCurrentTab("remittance")}>Start New Transaction</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="rates" className="space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Foreign Exchange Rates</CardTitle>
              <CardDescription>Current forex rates for popular currencies (as of today)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg border overflow-hidden">
                <div className="grid grid-cols-4 bg-vyom-light p-3 text-sm font-medium">
                  <div>Currency</div>
                  <div className="text-center">Buy (Cash)</div>
                  <div className="text-center">Sell (Cash)</div>
                  <div className="text-center">Sell (TT)</div>
                </div>
                
                {forexRates.map((rate, index) => (
                  <div key={index} className={`grid grid-cols-4 p-3 ${
                    index % 2 === 0 ? "bg-white" : "bg-slate-50"
                  }`}>
                    <div className="flex items-center gap-2">
                      {getCurrencyIcon(rate.currency)}
                      <div>
                        <p className="font-medium">{rate.currency}</p>
                        <p className="text-xs text-muted-foreground">{rate.name}</p>
                      </div>
                    </div>
                    <div className="text-center">₹{rate.buy.toFixed(2)}</div>
                    <div className="text-center">₹{rate.sell.toFixed(2)}</div>
                    <div className="text-center">₹{(rate.sell - 0.15).toFixed(2)}</div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 text-xs text-muted-foreground">
                <p>Note: These rates are indicative and subject to change without prior notice. The actual rate applicable will be the rate prevailing at the time of transaction.</p>
                <ul className="list-disc pl-5 mt-2 space-y-1">
                  <li>Buy (Cash): Rate at which bank buys foreign currency notes from customers</li>
                  <li>Sell (Cash): Rate at which bank sells foreign currency notes to customers</li>
                  <li>Sell (TT): Rate at which bank sells foreign currency through telegraphic transfer</li>
                </ul>
              </div>
              
              <div className="mt-6 flex justify-center">
                <Button 
                  variant="outline" 
                  onClick={() => toast({
                    title: "Rate Alert",
                    description: "You will be notified when your preferred currency rate changes.",
                  })}
                >
                  Set Rate Alert
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Currency Converter</CardTitle>
              <CardDescription>Quick currency conversion calculator</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="fromCurrencyCalc">From</Label>
                  <div className="flex gap-2">
                    <Select defaultValue="USD">
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD</SelectItem>
                        <SelectItem value="EUR">EUR</SelectItem>
                        <SelectItem value="GBP">GBP</SelectItem>
                        <SelectItem value="AUD">AUD</SelectItem>
                        <SelectItem value="CAD">CAD</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Input 
                      id="fromAmountCalc" 
                      placeholder="Amount" 
                      defaultValue="100"
                    />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="toCurrencyCalc">To</Label>
                  <div className="flex gap-2">
                    <Select defaultValue="INR">
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="INR">INR</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Input 
                      id="toAmountCalc" 
                      placeholder="Amount" 
                      value="8,312.00"
                      readOnly
                    />
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-center">
                <Button 
                  variant="international"
                  onClick={() => toast({
                    title: "Conversion Calculated",
                    description: "100 USD = ₹8,312.00 at current rates",
                  })}
                >
                  Calculate
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8">
        <Button 
          variant="outline" 
          onClick={() => navigate("/dashboard")}
          className="flex items-center gap-2"
        >
          <span>Back to Dashboard</span>
        </Button>
      </div>
    </div>
  );
};

export default InternationalTransactions;
