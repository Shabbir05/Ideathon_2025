
import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Send, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import LanguageToggle from "@/components/LanguageToggle";

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      
      toast({
        title: "Reset link sent",
        description: "If an account exists with that email, you'll receive a password reset link shortly.",
        duration: 5000,
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-vyom-light to-white">
      {/* Top Navigation */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-red flex items-center justify-center text-white font-bold text-xl">V</div>
            <span className="text-xl font-bold">Vyom</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <LanguageToggle />
            <Link to="/login" className="text-vyom-blue hover:text-vyom-red transition-colors duration-200 text-sm">
              Back to Login
            </Link>
          </div>
        </div>
      </div>
      
      {/* Forgot Password Form */}
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-fade-in">
          <Card className="border-none shadow-xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center text-vyom-blue">
                {isSubmitted ? "Check Your Email" : "Reset Password"}
              </CardTitle>
              <CardDescription className="text-center">
                {isSubmitted 
                  ? "We've sent you an email with instructions to reset your password." 
                  : "Enter your email address and we'll send you a reset link"}
              </CardDescription>
            </CardHeader>
            
            {!isSubmitted ? (
              <CardContent className="space-y-4">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                      <Input 
                        id="email" 
                        type="email" 
                        placeholder="name@example.com" 
                        className="pl-10 form-input" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      "Sending reset link..."
                    ) : (
                      <>
                        <Send size={18} />
                        Send Reset Link
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            ) : (
              <CardContent className="py-6 space-y-6">
                <div className="flex justify-center">
                  <div className="p-4 rounded-full bg-vyom-light/50 text-vyom-blue">
                    <Mail size={40} />
                  </div>
                </div>
                <p className="text-center text-vyom-gray">
                  We've sent reset instructions to: <span className="font-medium text-foreground">{email}</span>
                </p>
                <p className="text-center text-sm text-vyom-gray">
                  If you don't see the email in your inbox, please check your spam folder.
                </p>
              </CardContent>
            )}
            
            <CardFooter className="flex flex-col space-y-3">
              <Link 
                to="/login" 
                className="w-full flex items-center justify-center text-sm text-vyom-blue hover:text-vyom-red"
              >
                <ArrowLeft size={16} className="mr-2" />
                Back to login
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      {/* Footer */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-vyom-gray">
          <div className="mb-4 md:mb-0">
            © {new Date().getFullYear()} Vyom by Union Bank of India. All rights reserved.
          </div>
          <div className="flex space-x-6">
            <Link to="/privacy-policy" className="hover:text-vyom-red transition-colors duration-200">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-vyom-red transition-colors duration-200">Terms of Service</Link>
            <Link to="/contact" className="hover:text-vyom-red transition-colors duration-200">Contact Support</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
