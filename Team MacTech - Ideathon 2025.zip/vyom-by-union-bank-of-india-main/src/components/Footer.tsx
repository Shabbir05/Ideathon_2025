
import { Link } from "react-router-dom";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  Mail, 
  Phone, 
  MapPin 
} from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-vyom-blue text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 mb-12">
          {/* Column 1: About */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-teal to-white/80 flex items-center justify-center text-vyom-blue font-bold text-xl">V</div>
              <span className="text-xl font-bold">Vyom</span>
            </div>
            <p className="text-white/80 text-sm leading-relaxed">
              Vyom by Union Bank of India is a next-generation digital banking platform 
              offering secure, AI-powered financial services for modern banking needs.
            </p>
            <div className="flex space-x-4 pt-2">
              <a href="https://www.facebook.com/unionbankofindia" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-vyom-teal transition-colors duration-200">
                <Facebook size={20} />
              </a>
              <a href="https://twitter.com/unionbank_india" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-vyom-teal transition-colors duration-200">
                <Twitter size={20} />
              </a>
              <a href="https://www.instagram.com/unionbankofind" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-vyom-teal transition-colors duration-200">
                <Instagram size={20} />
              </a>
              <a href="https://www.linkedin.com/company/union-bank-of-india" target="_blank" rel="noopener noreferrer" className="text-white/70 hover:text-vyom-teal transition-colors duration-200">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
          
          {/* Column 2: Quick Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4 border-b border-white/10 pb-2">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Home</Link>
              </li>
              <li>
                <Link to="/about" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">About Us</Link>
              </li>
              <li>
                <Link to="/features" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Features</Link>
              </li>
              <li>
                <Link to="/login" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Login</Link>
              </li>
              <li>
                <Link to="/signup" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Sign Up</Link>
              </li>
            </ul>
          </div>
          
          {/* Column 3: Services */}
          <div>
            <h3 className="font-semibold text-lg mb-4 border-b border-white/10 pb-2">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services/personal-banking" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Personal Banking</Link>
              </li>
              <li>
                <Link to="/services/business-banking" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Business Banking</Link>
              </li>
              <li>
                <Link to="/services/loans" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Loans</Link>
              </li>
              <li>
                <Link to="/services/investments" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Investments</Link>
              </li>
              <li>
                <Link to="/services/insurance" className="text-white/70 hover:text-vyom-teal transition-colors duration-200 text-sm">Insurance</Link>
              </li>
            </ul>
          </div>
          
          {/* Column 4: Contact */}
          <div>
            <h3 className="font-semibold text-lg mb-4 border-b border-white/10 pb-2">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="text-vyom-teal mt-0.5" />
                <span className="text-white/70 text-sm">Union Bank Headquarters, Mumbai, Maharashtra, India</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone size={18} className="text-vyom-teal" />
                <span className="text-white/70 text-sm">+91 1800-XXX-XXXX</span>
              </li>
              <li className="flex items-center space-x-3">
                <Mail size={18} className="text-vyom-teal" />
                <span className="text-white/70 text-sm">support@vyombank.in</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-white/60 text-sm">
            © {currentYear} Vyom by Union Bank of India. All rights reserved.
          </div>
          <div className="flex space-x-6">
            <Link to="/privacy-policy" className="text-white/60 hover:text-vyom-teal transition-colors duration-200 text-sm">Privacy Policy</Link>
            <Link to="/terms-of-service" className="text-white/60 hover:text-vyom-teal transition-colors duration-200 text-sm">Terms of Service</Link>
            <Link to="/security" className="text-white/60 hover:text-vyom-teal transition-colors duration-200 text-sm">Security</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
