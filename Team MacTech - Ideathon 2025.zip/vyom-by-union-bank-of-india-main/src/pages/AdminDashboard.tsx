
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import AdminOverview from "@/components/admin/dashboard/AdminOverview";
import AdminRequests from "@/components/admin/dashboard/AdminRequests";
import AdminVerification from "@/components/admin/dashboard/AdminVerification";
import FraudMonitoring from "@/components/admin/dashboard/FraudMonitoring";
import EmployeeActivity from "@/components/admin/dashboard/EmployeeActivity";
import MFAPanel from "@/components/admin/dashboard/MFAPanel";
import Compliance from "@/components/admin/dashboard/Compliance";
import AdminSettings from "@/components/admin/dashboard/AdminSettings";
import RiskAssessment from "@/components/admin/dashboard/RiskAssessment";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [systemStatus, setSystemStatus] = useState("online");
  
  const toggleSystemStatus = () => {
    const newStatus = systemStatus === "online" ? "offline" : "online";
    setSystemStatus(newStatus);
    toast({
      title: "System Status Changed",
      description: `System is now ${newStatus}.`,
      variant: newStatus === "online" ? "default" : "destructive"
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-vyom-blue">Admin Dashboard</h1>
          <p className="text-vyom-gray">Fraud Monitoring and Security Management System</p>
        </div>
        <div className="flex items-center gap-4">
          <Alert className="w-auto py-2 px-4 bg-yellow-50 border-yellow-200">
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
            <AlertTitle className="text-yellow-600 ml-2 text-sm">Security Alert Level: Moderate</AlertTitle>
          </Alert>
          <Badge 
            variant="outline" 
            className={`flex items-center gap-1 cursor-pointer ${
              systemStatus === "online" 
                ? "bg-green-50 text-green-700 border-green-200" 
                : "bg-red-50 text-red-700 border-red-200"
            }`}
            onClick={toggleSystemStatus}
          >
            <div className={`w-2 h-2 rounded-full ${
              systemStatus === "online" ? "bg-green-500 animate-pulse" : "bg-red-500"
            }`}></div>
            System {systemStatus === "online" ? "Online" : "Offline"}
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-9 max-w-full bg-vyom-light overflow-x-auto">
          <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Overview
          </TabsTrigger>
          <TabsTrigger value="requests" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            User Requests
          </TabsTrigger>
          <TabsTrigger value="verification" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            User Verification
          </TabsTrigger>
          <TabsTrigger value="fraud" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Fraud Monitoring
          </TabsTrigger>
          <TabsTrigger value="risk" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Risk Assessment
          </TabsTrigger>
          <TabsTrigger value="employees" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Employee Activity
          </TabsTrigger>
          <TabsTrigger value="mfa" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            MFA Panel
          </TabsTrigger>
          <TabsTrigger value="compliance" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Compliance
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">
            Admin Settings
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <AdminOverview systemStatus={systemStatus} toggleSystemStatus={toggleSystemStatus} />
        </TabsContent>
        
        <TabsContent value="requests">
          <AdminRequests />
        </TabsContent>
        
        <TabsContent value="verification">
          <AdminVerification />
        </TabsContent>
        
        <TabsContent value="fraud">
          <FraudMonitoring />
        </TabsContent>

        <TabsContent value="risk">
          <RiskAssessment />
        </TabsContent>
        
        <TabsContent value="employees">
          <EmployeeActivity />
        </TabsContent>
        
        <TabsContent value="mfa">
          <MFAPanel />
        </TabsContent>
        
        <TabsContent value="compliance">
          <Compliance />
        </TabsContent>
        
        <TabsContent value="settings">
          <AdminSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
