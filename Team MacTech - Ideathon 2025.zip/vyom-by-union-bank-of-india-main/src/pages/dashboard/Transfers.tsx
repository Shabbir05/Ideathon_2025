
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  ArrowRight, 
  Clock, 
  Users, 
  Building, 
  Globe, 
  Search, 
  CreditCard, 
  Check, 
  AlertCircle, 
  ArrowRightLeft, 
  Calendar, 
  ChevronRight,
  BadgeCheck,
  UserCheck,
  CalendarClock
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

const transferSchema = z.object({
  fromAccount: z.string({
    required_error: "Please select an account",
  }),
  toAccount: z.string({
    required_error: "Please select or enter recipient details",
  }),
  amount: z.string().min(1, "Amount is required"),
  transferType: z.enum(["IMPS", "NEFT", "RTGS"], {
    required_error: "Please select a transfer type",
  }),
  purpose: z.string().optional(),
  remarks: z.string().optional(),
  scheduleTransfer: z.boolean().default(false),
  transferDate: z.string().optional(),
});

// More specific schema for other bank transfers
const otherBankSchema = z.object({
  accountNo: z.string().min(1, "Account number is required"),
  confirmAccountNo: z.string().min(1, "Confirm account number is required"),
  ifsc: z.string().min(11, "Valid IFSC code is required"),
  bankName: z.string().min(1, "Bank name is required"),
  beneficiaryName: z.string().min(1, "Beneficiary name is required"),
  amount: z.string().min(1, "Amount is required"),
  remarks: z.string().optional(),
  transferMode: z.enum(["IMPS", "NEFT", "RTGS"], {
    required_error: "Please select a transfer type",
  }),
});

const Transfers = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [amount, setAmount] = useState("");
  const [activeTab, setActiveTab] = useState("quick");
  const [isTransferring, setIsTransferring] = useState(false);
  const [recentRecipients, setRecentRecipients] = useState([
    { id: 1, name: "Rahul Sharma", account: "XXXX1234", bank: "Vyom Bank", lastSent: "2 days ago", avatar: "RS" },
    { id: 2, name: "Priya Patel", account: "XXXX5678", bank: "Vyom Bank", lastSent: "1 week ago", avatar: "PP" },
    { id: 3, name: "Digital Payment", account: "XXXX9012", bank: "HDFC Bank", lastSent: "2 weeks ago", avatar: "DP" },
    { id: 4, name: "Electricity Bill", account: "XXXX3456", bank: "Bill Payment", lastSent: "1 month ago", avatar: "EB" },
  ]);
  
  const [savedBeneficiaries, setSavedBeneficiaries] = useState([
    { id: 1, name: "Rahul Sharma", accountNo: "50100112233445", bank: "ICICI Bank", ifsc: "ICIC0001234", verified: true },
    { id: 2, name: "Priya Patel", accountNo: "36251000012345", bank: "SBI Bank", ifsc: "SBIN0005678", verified: true },
    { id: 3, name: "Ajay Kumar", accountNo: "91501011123456", bank: "HDFC Bank", ifsc: "HDFC0009876", verified: true },
    { id: 4, name: "Vijay Singh", accountNo: "02051000067890", bank: "Axis Bank", ifsc: "UTIB0000124", verified: false },
    { id: 5, name: "Neha Gupta", accountNo: "30901010056789", bank: "Bank of Baroda", ifsc: "BARB0NEWDEL", verified: true },
    { id: 6, name: "Sanjay Verma", accountNo: "11501013454321", bank: "Punjab National Bank", ifsc: "PUNB0112200", verified: true },
  ]);
  
  const [recentTransactions, setRecentTransactions] = useState([
    { 
      id: "TRX001", 
      date: "23 Jun 2023, 14:30", 
      amount: "₹12,500", 
      beneficiary: "Rahul Sharma", 
      status: "Completed", 
      type: "IMPS"
    },
    { 
      id: "TRX002", 
      date: "18 Jun 2023, 10:15", 
      amount: "₹8,750", 
      beneficiary: "Electricity Bill", 
      status: "Completed", 
      type: "NEFT"
    },
    { 
      id: "TRX003", 
      date: "10 Jun 2023, 17:45", 
      amount: "₹23,000", 
      beneficiary: "Priya Patel", 
      status: "Completed", 
      type: "RTGS"
    },
    { 
      id: "TRX004", 
      date: "05 Jun 2023, 09:00", 
      amount: "₹5,300", 
      beneficiary: "Digital Payment", 
      status: "Completed", 
      type: "IMPS"
    },
  ]);
  
  const [accounts, setAccounts] = useState([
    { id: 1, type: "Savings Account", number: "XXXX XXXX XXXX 4523", balance: 157892.45 },
    { id: 2, type: "Current Account", number: "XXXX XXXX XXXX 8967", balance: 245630.20 },
  ]);
  
  const form = useForm<z.infer<typeof transferSchema>>({
    resolver: zodResolver(transferSchema),
    defaultValues: {
      fromAccount: "",
      toAccount: "",
      amount: "",
      transferType: "IMPS",
      purpose: "",
      remarks: "",
      scheduleTransfer: false,
      transferDate: "",
    },
  });
  
  const otherBankForm = useForm<z.infer<typeof otherBankSchema>>({
    resolver: zodResolver(otherBankSchema),
    defaultValues: {
      accountNo: "",
      confirmAccountNo: "",
      ifsc: "",
      bankName: "",
      beneficiaryName: "",
      amount: "",
      remarks: "",
      transferMode: "IMPS",
    },
  });
  
  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!amount) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount",
        variant: "destructive",
      });
      return;
    }
    
    setIsTransferring(true);
    
    setTimeout(() => {
      toast({
        title: "Transfer initiated",
        description: `₹${amount} will be transferred shortly.`,
      });
      
      setIsTransferring(false);
      setAmount("");
    }, 1500);
  };
  
  const onQuickTransferSubmit = (values: z.infer<typeof transferSchema>) => {
    setIsTransferring(true);
    
    setTimeout(() => {
      toast({
        title: "Transfer Successful",
        description: `₹${values.amount} has been transferred to ${values.toAccount}.`,
      });
      
      // Add to recent transactions
      const newTransaction = {
        id: `TRX${Math.floor(Math.random() * 1000)}`,
        date: new Date().toLocaleString('en-IN', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        amount: `₹${parseFloat(values.amount).toLocaleString('en-IN')}`,
        beneficiary: values.toAccount.split(' (')[0],
        status: "Completed",
        type: values.transferType,
      };
      
      setRecentTransactions([newTransaction, ...recentTransactions]);
      setIsTransferring(false);
      form.reset();
    }, 1500);
  };
  
  const onOtherBankSubmit = (values: z.infer<typeof otherBankSchema>) => {
    if (values.accountNo !== values.confirmAccountNo) {
      toast({
        title: "Account Numbers Don't Match",
        description: "Please ensure the account numbers match",
        variant: "destructive",
      });
      return;
    }
    
    setIsTransferring(true);
    
    setTimeout(() => {
      toast({
        title: "Transfer Initiated",
        description: `₹${values.amount} will be transferred to ${values.beneficiaryName} via ${values.transferMode}.`,
      });
      
      // Add to recent transactions
      const newTransaction = {
        id: `TRX${Math.floor(Math.random() * 1000)}`,
        date: new Date().toLocaleString('en-IN', {
          day: '2-digit',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        amount: `₹${parseFloat(values.amount).toLocaleString('en-IN')}`,
        beneficiary: values.beneficiaryName,
        status: "Processing",
        type: values.transferMode,
      };
      
      setRecentTransactions([newTransaction, ...recentTransactions]);
      setIsTransferring(false);
      otherBankForm.reset();
    }, 1500);
  };
  
  const handleSelectRecipient = (recipient: any) => {
    form.setValue("toAccount", `${recipient.name} (${recipient.account})`);
    toast({
      title: "Recipient Selected",
      description: `${recipient.name} has been selected for the transfer.`,
    });
  };
  
  const handleSelectBeneficiary = (beneficiary: any) => {
    otherBankForm.setValue("accountNo", beneficiary.accountNo);
    otherBankForm.setValue("confirmAccountNo", beneficiary.accountNo);
    otherBankForm.setValue("ifsc", beneficiary.ifsc);
    otherBankForm.setValue("bankName", beneficiary.bank);
    otherBankForm.setValue("beneficiaryName", beneficiary.name);
    
    toast({
      title: "Beneficiary Selected",
      description: `${beneficiary.name} has been selected for the transfer.`,
    });
  };
  
  const validateIFSC = (ifsc: string) => {
    // Basic IFSC code validation
    if (ifsc.length === 11 && /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc)) {
      otherBankForm.setValue("bankName", "Example Bank (Auto-detected)");
      
      toast({
        title: "IFSC Validated",
        description: "Bank details have been auto-populated based on the IFSC code.",
      });
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-vyom-blue">Transfers & Payments</h1>
          <p className="text-muted-foreground">Transfer money securely to accounts within and outside Vyom Bank</p>
        </div>
        <Button 
          variant="secondary" 
          onClick={() => navigate("/dashboard/scan-qr")}
          className="flex items-center gap-2"
        >
          <span>Scan & Pay</span>
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
      
      <Tabs defaultValue="quick" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-3xl grid-cols-4">
          <TabsTrigger value="quick">Quick Transfer</TabsTrigger>
          <TabsTrigger value="beneficiary">To Beneficiary</TabsTrigger>
          <TabsTrigger value="bank">Other Bank</TabsTrigger>
          <TabsTrigger value="international">International</TabsTrigger>
        </TabsList>
        
        <TabsContent value="quick" className="mt-6 space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Quick Transfer</CardTitle>
              <CardDescription>Transfer money to your frequent contacts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="col-span-1 md:col-span-2">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onQuickTransferSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="fromAccount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>From Account</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select account" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {accounts.map((account) => (
                                  <SelectItem
                                    key={account.id}
                                    value={`${account.type} (₹${account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})`}
                                  >
                                    {account.type} - ₹{account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="toAccount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Select Recipient</FormLabel>
                            <div className="relative">
                              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                              <FormControl>
                                <Input
                                  {...field}
                                  placeholder="Search contact or account number"
                                  className="pl-8"
                                />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="amount"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount (₹)</FormLabel>
                            <FormControl>
                              <Input
                                {...field}
                                type="number"
                                placeholder="Enter amount"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="transferType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Transfer Mode</FormLabel>
                            <div className="flex flex-wrap gap-4">
                              {["IMPS", "NEFT", "RTGS"].map((type) => (
                                <div key={type} className="flex items-center space-x-2">
                                  <input
                                    type="radio"
                                    id={type}
                                    name="transferType"
                                    value={type}
                                    checked={field.value === type}
                                    onChange={() => field.onChange(type)}
                                    className="h-4 w-4"
                                  />
                                  <Label htmlFor={type} className="cursor-pointer">
                                    {type} {type === "IMPS" && "(Instant)"}
                                    {type === "NEFT" && "(Within 30 mins)"}
                                    {type === "RTGS" && "(For ₹2L & above)"}
                                  </Label>
                                </div>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="remarks"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Remarks (Optional)</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Purpose of transfer" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="scheduleTransfer"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md border p-3">
                            <FormControl>
                              <Switch
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>Schedule Transfer</FormLabel>
                              <p className="text-sm text-muted-foreground">
                                Set a future date for this transfer
                              </p>
                            </div>
                          </FormItem>
                        )}
                      />
                      
                      {form.watch("scheduleTransfer") && (
                        <FormField
                          control={form.control}
                          name="transferDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transfer Date</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  type="date"
                                  min={new Date().toISOString().split("T")[0]}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}
                      
                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={isTransferring}
                      >
                        {isTransferring ? "Processing..." : "Transfer Now"}
                      </Button>
                    </form>
                  </Form>
                </div>
                
                <div className="border rounded-lg p-4">
                  <h3 className="font-medium mb-3">Recent Recipients</h3>
                  <ScrollArea className="h-[300px]">
                    <div className="space-y-3">
                      {recentRecipients.map((recipient) => (
                        <div 
                          key={recipient.id} 
                          className="flex items-center gap-3 p-2 hover:bg-accent rounded-md cursor-pointer"
                          onClick={() => handleSelectRecipient(recipient)}
                        >
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            {recipient.avatar}
                          </div>
                          <div>
                            <p className="text-sm font-medium">{recipient.name}</p>
                            <p className="text-xs text-muted-foreground">{recipient.bank} • Last: {recipient.lastSent}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Recent Transfers</CardTitle>
              <CardDescription>Your recent transfer transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.slice(0, 3).map((transaction, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Clock className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{transaction.beneficiary}</p>
                        <p className="text-sm text-muted-foreground">{transaction.date}</p>
                      </div>
                    </div>
                    <div>
                      <p className="font-medium text-right">{transaction.amount}</p>
                      <div className="flex items-center justify-end gap-1">
                        <Badge variant="outline" className="text-xs">
                          {transaction.type}
                        </Badge>
                        <Badge variant="outline" className="text-xs bg-green-50 text-green-600">
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm" onClick={() => navigate("/dashboard/transactions")}>
                  View All Transactions
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="beneficiary" className="mt-6 space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Transfer to Beneficiary</CardTitle>
                  <CardDescription>Send money to your saved beneficiaries</CardDescription>
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => {
                    toast({
                      title: "Add New Beneficiary",
                      description: "Redirecting to add beneficiary form...",
                    });
                  }}
                >
                  + Add New Beneficiary
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {savedBeneficiaries.map((beneficiary) => (
                  <Card 
                    key={beneficiary.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => handleSelectBeneficiary(beneficiary)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Users className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1">
                            <p className="font-medium">{beneficiary.name}</p>
                            {beneficiary.verified && (
                              <Badge variant="outline" className="ml-1 text-xs bg-green-50 text-green-600">
                                <BadgeCheck className="h-3 w-3 mr-1" />
                                Verified
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{beneficiary.bank}</p>
                          <p className="text-xs text-muted-foreground">A/C: {beneficiary.accountNo.slice(0, 4)}...{beneficiary.accountNo.slice(-4)}</p>
                          <p className="text-xs text-muted-foreground">IFSC: {beneficiary.ifsc}</p>
                        </div>
                      </div>
                      <div className="mt-3 pt-2 border-t flex justify-between">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            toast({
                              title: "Edit Beneficiary",
                              description: "Redirecting to edit beneficiary form...",
                            });
                          }}
                        >
                          Edit
                        </Button>
                        <Button 
                          variant="secondary" 
                          size="sm" 
                          className="text-xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectBeneficiary(beneficiary);
                            setActiveTab("bank");
                          }}
                        >
                          Transfer
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Recent Beneficiary Transfers</CardTitle>
              <CardDescription>Your recent transfers to saved beneficiaries</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTransactions.slice(0, 3).map((transaction, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <UserCheck className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{transaction.beneficiary}</p>
                        <p className="text-sm text-muted-foreground">{transaction.date}</p>
                      </div>
                    </div>
                    <div>
                      <p className="font-medium text-right">{transaction.amount}</p>
                      <div className="flex items-center justify-end gap-1">
                        <Badge variant="outline" className="text-xs">
                          {transaction.type}
                        </Badge>
                        <Badge variant="outline" className="text-xs bg-green-50 text-green-600">
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="bank" className="mt-6 space-y-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>Other Bank Transfer</CardTitle>
              <CardDescription>Transfer to other banks via NEFT, RTGS, or IMPS</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...otherBankForm}>
                <form onSubmit={otherBankForm.handleSubmit(onOtherBankSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={otherBankForm.control}
                      name="accountNo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Number</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Enter account number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={otherBankForm.control}
                      name="confirmAccountNo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Account Number</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Confirm account number" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={otherBankForm.control}
                      name="ifsc"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>IFSC Code</FormLabel>
                          <FormControl>
                            <Input 
                              {...field} 
                              placeholder="Enter IFSC code" 
                              onChange={(e) => {
                                field.onChange(e);
                                if (e.target.value.length === 11) {
                                  validateIFSC(e.target.value);
                                }
                              }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={otherBankForm.control}
                      name="bankName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bank Name</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Bank name will appear here" readOnly />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={otherBankForm.control}
                      name="beneficiaryName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Beneficiary Name</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Enter beneficiary name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={otherBankForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (₹)</FormLabel>
                          <FormControl>
                            <Input {...field} type="number" placeholder="Enter amount" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={otherBankForm.control}
                    name="remarks"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Remarks (Optional)</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Add remarks" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={otherBankForm.control}
                    name="transferMode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Transfer Mode</FormLabel>
                        <div className="flex flex-wrap gap-4">
                          {["IMPS", "NEFT", "RTGS"].map((type) => (
                            <div key={type} className="flex items-center space-x-2">
                              <input
                                type="radio"
                                id={`other-${type}`}
                                name="transferMode"
                                value={type}
                                checked={field.value === type}
                                onChange={() => field.onChange(type)}
                                className="h-4 w-4"
                              />
                              <Label htmlFor={`other-${type}`} className="cursor-pointer">
                                {type} {type === "IMPS" && "(Instant)"}
                                {type === "NEFT" && "(Within 30 mins)"}
                                {type === "RTGS" && "(For ₹2L & above)"}
                              </Label>
                            </div>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="border rounded-lg p-4 bg-slate-50">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-vyom-blue mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">Important Information</p>
                        <ul className="text-xs text-muted-foreground list-disc pl-4 mt-1 space-y-1">
                          <li>IMPS transfers are processed instantly, 24x7 (limit: up to ₹5 lakhs)</li>
                          <li>NEFT transfers are processed hourly during banking hours (no limit)</li>
                          <li>RTGS transfers are processed in real-time during banking hours (minimum: ₹2 lakhs)</li>
                          <li>Please verify all details before proceeding with the transfer</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full md:w-auto"
                    disabled={isTransferring}
                  >
                    {isTransferring ? "Processing..." : "Proceed to Transfer"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="international" className="mt-6">
          <Card className="shadow-md hover:shadow-lg transition-all duration-300">
            <CardHeader>
              <CardTitle>International Transfer</CardTitle>
              <CardDescription>Send money overseas safely and quickly</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="p-6 border rounded-lg bg-slate-50">
                    <div className="flex flex-col items-center text-center">
                      <Globe className="h-12 w-12 text-vyom-blue opacity-70 mb-4" />
                      <h3 className="text-lg font-medium mb-2">International Banking Services</h3>
                      <p className="text-muted-foreground mb-6">
                        Transfer money to international accounts with competitive exchange rates and low fees.
                      </p>
                      <Button 
                        variant="international"
                        onClick={() => navigate("/dashboard/international")}
                        className="w-full sm:w-auto"
                      >
                        Start International Transfer
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-medium">International Transfer Features</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5 h-5 w-5 rounded-full bg-vyom-light flex items-center justify-center">
                          <Check className="h-3 w-3 text-vyom-blue" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Global Reach</p>
                          <p className="text-xs text-muted-foreground">Transfer to 100+ countries</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5 h-5 w-5 rounded-full bg-vyom-light flex items-center justify-center">
                          <Check className="h-3 w-3 text-vyom-blue" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Multiple Currencies</p>
                          <p className="text-xs text-muted-foreground">Support for major currencies</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5 h-5 w-5 rounded-full bg-vyom-light flex items-center justify-center">
                          <Check className="h-3 w-3 text-vyom-blue" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Competitive Rates</p>
                          <p className="text-xs text-muted-foreground">Best exchange rates available</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5 h-5 w-5 rounded-full bg-vyom-light flex items-center justify-center">
                          <Check className="h-3 w-3 text-vyom-blue" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Secure Transfers</p>
                          <p className="text-xs text-muted-foreground">End-to-end encrypted</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-6">
                  <h3 className="font-medium">Our International Services</h3>
                  <div className="space-y-4">
                    <div className="border rounded-lg p-4 hover:bg-slate-50 cursor-pointer transition-colors" onClick={() => navigate("/dashboard/international")}>
                      <div className="flex items-start gap-3">
                        <ArrowRightLeft className="h-5 w-5 text-vyom-blue mt-0.5" />
                        <div>
                          <p className="font-medium">Wire Transfers</p>
                          <p className="text-sm text-muted-foreground">Send money directly to overseas bank accounts</p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto" />
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4 hover:bg-slate-50 cursor-pointer transition-colors" onClick={() => navigate("/dashboard/international")}>
                      <div className="flex items-start gap-3">
                        <CreditCard className="h-5 w-5 text-vyom-purple mt-0.5" />
                        <div>
                          <p className="font-medium">Forex Cards</p>
                          <p className="text-sm text-muted-foreground">Pre-loaded multi-currency travel cards</p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto" />
                      </div>
                    </div>
                    
                    <div className="border rounded-lg p-4 hover:bg-slate-50 cursor-pointer transition-colors" onClick={() => navigate("/dashboard/international")}>
                      <div className="flex items-start gap-3">
                        <CalendarClock className="h-5 w-5 text-vyom-teal mt-0.5" />
                        <div>
                          <p className="font-medium">Recurring Transfers</p>
                          <p className="text-sm text-muted-foreground">Schedule regular overseas payments</p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-muted-foreground ml-auto" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="border rounded-lg p-4 bg-blue-50 border-blue-200">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-5 w-5 text-vyom-blue mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">Need Help?</p>
                        <p className="text-xs text-muted-foreground">Our international banking experts are available 24/7 to assist you with any queries.</p>
                        <Button 
                          variant="link" 
                          className="h-auto p-0 text-xs mt-1"
                          onClick={() => toast({
                            title: "Contact Support",
                            description: "Connecting you to our international banking team...",
                          })}
                        >
                          Contact Support
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="justify-start border-t pt-4">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => navigate("/dashboard/international")}
                className="flex items-center gap-2"
              >
                <Globe className="h-4 w-4" />
                <span>Go to International Banking</span>
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default Transfers;
