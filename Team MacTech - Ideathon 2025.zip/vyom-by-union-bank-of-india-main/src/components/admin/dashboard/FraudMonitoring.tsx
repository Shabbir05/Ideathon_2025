
import React, { useState } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell } from "recharts";
import { faker } from "@faker-js/faker";
import { fraudWeeklyData, fraudMonthlyData, requestTypeData, fraudActivityData, transactionCategoriesData, anomalyDetectionData } from "@/data/adminDashboardData";

// Import Heroicons
import { ArrowUpCircle, ArrowDownCircle, AlertTriangle, Clock, Eye, Shield, Bell, Calendar } from "lucide-react";

const FraudMonitoring = () => {
  const [timeframe, setTimeframe] = useState("weekly");
  const [pendingAlerts, setPendingAlerts] = useState(
    fraudActivityData.map((item) => ({ ...item, reviewed: false }))
  );

  // Function to handle marking an alert as reviewed
  const markAsReviewed = (id: string) => {
    setPendingAlerts(
      pendingAlerts.map((alert) =>
        alert.id === id ? { ...alert, reviewed: true } : alert
      )
    );
  };

  // Function to generate random statistics
  const generateRandomStats = () => {
    return {
      totalAttempts: faker.number.int({ min: 100, max: 500 }),
      preventedAttempts: faker.number.int({ min: 80, max: 450 }),
      riskScore: faker.number.int({ min: 30, max: 80 }),
      openAlerts: faker.number.int({ min: 5, max: 25 }),
    };
  };

  const stats = generateRandomStats();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Total Fraud Attempts
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">
                  {stats.totalAttempts}
                </h3>
                <p className="text-sm text-red-500 flex items-center mt-1">
                  <ArrowUpCircle className="h-4 w-4 mr-1" />
                  +12.5% from last week
                </p>
              </div>
              <Shield className="h-10 w-10 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Prevented Attempts
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">
                  {stats.preventedAttempts}
                </h3>
                <p className="text-sm text-green-500 flex items-center mt-1">
                  <ArrowUpCircle className="h-4 w-4 mr-1" />
                  +8.3% from last week
                </p>
              </div>
              <Shield className="h-10 w-10 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Current Risk Score
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">
                  {stats.riskScore}/100
                </h3>
                <p className="text-sm text-yellow-500 flex items-center mt-1">
                  <ArrowDownCircle className="h-4 w-4 mr-1" />
                  -2.1% from last week
                </p>
              </div>
              <AlertTriangle className="h-10 w-10 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">
                  Open Alerts
                </p>
                <h3 className="text-2xl font-bold text-gray-900 mt-1">
                  {stats.openAlerts}
                </h3>
                <p className="text-sm text-gray-500 flex items-center mt-1">
                  <Clock className="h-4 w-4 mr-1" />
                  Last updated 10m ago
                </p>
              </div>
              <Bell className="h-10 w-10 text-indigo-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fraud Attempts Chart */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Fraud Attempts</CardTitle>
                <CardDescription>
                  Detected vs Prevented Fraud Attempts
                </CardDescription>
              </div>
              <Tabs defaultValue="weekly" className="w-[240px]">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger 
                    value="weekly"
                    onClick={() => setTimeframe("weekly")}
                  >
                    Weekly
                  </TabsTrigger>
                  <TabsTrigger 
                    value="monthly"
                    onClick={() => setTimeframe("monthly")}
                  >
                    Monthly
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={timeframe === "weekly" ? fraudWeeklyData : fraudMonthlyData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="attempts" fill="#f43f5e" name="Detected" />
                  <Bar dataKey="prevented" fill="#10b981" name="Prevented" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Anomaly Detection Chart */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Anomaly Detection</CardTitle>
                <CardDescription>
                  Monitoring abnormal transaction patterns
                </CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Calendar className="mr-2 h-4 w-4" /> 
                May 2025
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={anomalyDetectionData}
                  margin={{
                    top: 20,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="normal"
                    stackId="1"
                    stroke="#8884d8"
                    fill="#8884d8"
                    name="Normal Transactions (%)"
                  />
                  <Area
                    type="monotone"
                    dataKey="anomaly"
                    stackId="1"
                    stroke="#f43f5e"
                    fill="#f43f5e"
                    name="Anomalous Transactions (%)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Request Type Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Request Type Distribution</CardTitle>
            <CardDescription>
              Types of fraudulent activity attempts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={requestTypeData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    label={({
                      cx,
                      cy,
                      midAngle,
                      innerRadius,
                      outerRadius,
                      percent,
                      name,
                    }) => {
                      const radius =
                        innerRadius + (outerRadius - innerRadius) * 1.4;
                      const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                      const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                      return (
                        <text
                          x={x}
                          y={y}
                          fill="#888"
                          textAnchor={x > cx ? "start" : "end"}
                          dominantBaseline="central"
                          fontSize="12"
                        >
                          {name} ({(percent * 100).toFixed(0)}%)
                        </text>
                      );
                    }}
                  >
                    {requestTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Transaction Categories */}
        <Card>
          <CardHeader>
            <CardTitle>Transaction Categories</CardTitle>
            <CardDescription>
              Categories most susceptible to fraud
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={transactionCategoriesData}
                    cx="50%"
                    cy="50%"
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="value"
                    label={({
                      cx,
                      cy,
                      midAngle,
                      innerRadius,
                      outerRadius,
                      percent,
                      name,
                    }) => {
                      const radius = outerRadius * 1.4;
                      const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                      const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                      return (
                        <text
                          x={x}
                          y={y}
                          fill="#888"
                          textAnchor={x > cx ? "start" : "end"}
                          dominantBaseline="central"
                          fontSize="12"
                        >
                          {name} ({(percent * 100).toFixed(0)}%)
                        </text>
                      );
                    }}
                  >
                    {transactionCategoriesData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Pending Approvals/Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Pending Alerts</CardTitle>
            <CardDescription>
              Fraud activities requiring attention
            </CardDescription>
          </CardHeader>
          <CardContent className="px-2">
            <div className="max-h-[300px] overflow-auto">
              {pendingAlerts.filter((alert) => !alert.reviewed).length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Risk</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingAlerts
                      .filter((alert) => !alert.reviewed)
                      .map((alert) => (
                        <TableRow key={alert.id}>
                          <TableCell className="font-medium">{alert.id}</TableCell>
                          <TableCell>{alert.type}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                alert.risk === "High"
                                  ? "bg-red-500"
                                  : alert.risk === "Medium"
                                  ? "bg-yellow-500"
                                  : "bg-green-500"
                              }
                            >
                              {alert.risk}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 w-8 p-0"
                              onClick={() => markAsReviewed(alert.id)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex items-center justify-center h-[200px]">
                  <div className="text-center">
                    <Shield className="h-10 w-10 text-gray-400 mx-auto" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">
                      No pending alerts
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      All fraud alerts have been reviewed.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Fraud Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Fraud Activity</CardTitle>
          <CardDescription>
            Detailed list of recent fraud attempts and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>Account</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Timestamp</TableHead>
                  <TableHead>Risk Level</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fraudActivityData.map((activity) => (
                  <TableRow key={activity.id}>
                    <TableCell className="font-medium">{activity.id}</TableCell>
                    <TableCell>{activity.accountId}</TableCell>
                    <TableCell>{activity.type}</TableCell>
                    <TableCell>{activity.amount}</TableCell>
                    <TableCell>{activity.timestamp}</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          activity.risk === "High"
                            ? "bg-red-500"
                            : activity.risk === "Medium"
                            ? "bg-yellow-500"
                            : "bg-green-500"
                        }
                      >
                        {activity.risk}
                      </Badge>
                    </TableCell>
                    <TableCell>{activity.location}</TableCell>
                    <TableCell>
                      {activity.flagged ? (
                        <Badge className="bg-red-500">Flagged</Badge>
                      ) : (
                        <Badge className="bg-green-500">Cleared</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FraudMonitoring;
