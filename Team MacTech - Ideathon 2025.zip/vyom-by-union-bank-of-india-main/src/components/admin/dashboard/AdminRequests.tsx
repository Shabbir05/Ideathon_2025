
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { User, Activity } from "lucide-react";
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip
} from "recharts";
import { toast } from "@/hooks/use-toast";
import { requestTypeData } from "@/data/adminDashboardData";

const AdminRequests = () => {
  const [requestFilterStatus, setRequestFilterStatus] = useState("all");
  const [justifications, setJustifications] = useState<Record<string, string>>({});

  const handleRequestApproval = (requestId: string, action: 'approve' | 'reject') => {
    if (!justifications[requestId] || justifications[requestId].trim() === '') {
      toast({
        title: "Justification Required",
        description: "Please provide a reason for your decision.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: action === 'approve' ? "Request Approved" : "Request Rejected",
      description: `Request ${requestId} has been ${action === 'approve' ? 'approved' : 'rejected'}.`,
      variant: action === 'approve' ? "default" : "destructive"
    });
    
    setJustifications({
      ...justifications,
      [requestId]: ''
    });
  };
  
  const handleJustificationChange = (requestId: string, value: string) => {
    setJustifications({
      ...justifications,
      [requestId]: value
    });
  };
  
  const handleViewUserProfile = (userId: string) => {
    toast({
      title: "User Profile",
      description: `Viewing profile for user ${userId}`
    });
  };
  
  const handleViewTransactions = (userId: string) => {
    toast({
      title: "Transaction History",
      description: `Viewing transactions for user ${userId}`
    });
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-semibold">User Access Requests</h2>
          <p className="text-muted-foreground">Review and process user requests requiring approval</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant={requestFilterStatus === "all" ? "secondary" : "outline"} 
            size="sm" 
            onClick={() => setRequestFilterStatus("all")}
          >
            All
          </Button>
          <Button 
            variant={requestFilterStatus === "high" ? "secondary" : "outline"} 
            size="sm" 
            onClick={() => setRequestFilterStatus("high")}
          >
            High Priority
          </Button>
          <Button 
            variant={requestFilterStatus === "medium" ? "secondary" : "outline"} 
            size="sm" 
            onClick={() => setRequestFilterStatus("medium")}
          >
            Medium
          </Button>
          <Button 
            variant={requestFilterStatus === "low" ? "secondary" : "outline"} 
            size="sm" 
            onClick={() => setRequestFilterStatus("low")}
          >
            Low
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Request Type Distribution</CardTitle>
            <CardDescription>Analysis of access request types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={requestTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {requestTypeData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Pending Access Requests</CardTitle>
            <CardDescription>
              Requires admin review and approval
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Request ID</TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Risk Score</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">REQ-7829</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>Amit Sharma</span>
                      <span className="text-xs text-gray-500">ID87245</span>
                    </div>
                  </TableCell>
                  <TableCell>Password Reset</TableCell>
                  <TableCell>Today, 10:23 AM</TableCell>
                  <TableCell>
                    <Badge className="bg-red-100 text-red-800">High (87/100)</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUserProfile("ID87245")}>
                        <User className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewTransactions("ID87245")}>
                        <Activity className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                
                <TableRow className="relative">
                  <TableCell colSpan={6} className="p-0">
                    <div className="p-4 bg-gray-50">
                      <div className="mb-3">
                        <p className="text-sm font-medium mb-2">Admin Decision</p>
                        <Textarea 
                          placeholder="Provide justification for your decision..." 
                          className="w-full h-20 text-sm"
                          value={justifications["REQ-7829"] || ""}
                          onChange={(e) => handleJustificationChange("REQ-7829", e.target.value)}
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7829", "reject")}
                        >
                          Reject
                        </Button>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7829", "approve")}
                        >
                          Approve
                        </Button>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
                
                <TableRow>
                  <TableCell className="font-medium">REQ-7830</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>Priya Patel</span>
                      <span className="text-xs text-gray-500">ID45982</span>
                    </div>
                  </TableCell>
                  <TableCell>Transaction Limit Increase</TableCell>
                  <TableCell>Today, 9:48 AM</TableCell>
                  <TableCell>
                    <Badge className="bg-yellow-100 text-yellow-800">Medium (54/100)</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUserProfile("ID45982")}>
                        <User className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewTransactions("ID45982")}>
                        <Activity className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                
                <TableRow className="relative">
                  <TableCell colSpan={6} className="p-0">
                    <div className="p-4 bg-gray-50">
                      <div className="mb-3">
                        <p className="text-sm font-medium mb-2">Admin Decision</p>
                        <Textarea 
                          placeholder="Provide justification for your decision..." 
                          className="w-full h-20 text-sm"
                          value={justifications["REQ-7830"] || ""}
                          onChange={(e) => handleJustificationChange("REQ-7830", e.target.value)}
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7830", "reject")}
                        >
                          Reject
                        </Button>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7830", "approve")}
                        >
                          Approve
                        </Button>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
                
                <TableRow>
                  <TableCell className="font-medium">REQ-7831</TableCell>
                  <TableCell>
                    <div className="flex flex-col">
                      <span>Rahul Singh</span>
                      <span className="text-xs text-gray-500">ID32456</span>
                    </div>
                  </TableCell>
                  <TableCell>Add Beneficiary</TableCell>
                  <TableCell>Yesterday, 4:12 PM</TableCell>
                  <TableCell>
                    <Badge className="bg-green-100 text-green-800">Low (23/100)</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewUserProfile("ID32456")}>
                        <User className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="h-8 w-8 p-0" onClick={() => handleViewTransactions("ID32456")}>
                        <Activity className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                
                <TableRow className="relative">
                  <TableCell colSpan={6} className="p-0">
                    <div className="p-4 bg-gray-50">
                      <div className="mb-3">
                        <p className="text-sm font-medium mb-2">Admin Decision</p>
                        <Textarea 
                          placeholder="Provide justification for your decision..." 
                          className="w-full h-20 text-sm"
                          value={justifications["REQ-7831"] || ""}
                          onChange={(e) => handleJustificationChange("REQ-7831", e.target.value)}
                        />
                      </div>
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7831", "reject")}
                        >
                          Reject
                        </Button>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => handleRequestApproval("REQ-7831", "approve")}
                        >
                          Approve
                        </Button>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-sm text-muted-foreground">
              Showing 3 of 12 pending requests
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">Previous</Button>
              <Button variant="outline" size="sm">Next</Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default AdminRequests;
