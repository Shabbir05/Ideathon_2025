
import React from "react";
import LoginHeader from "@/components/login/LoginHeader";
import LoginCard from "@/components/login/LoginCard";
import LoginFooter from "@/components/login/LoginFooter";

const Login = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-vyom-light to-white">
      {/* Top Navigation */}
      <LoginHeader />
      
      {/* Login Form */}
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-fade-in">
          <LoginCard />
        </div>
      </div>
      
      {/* Footer */}
      <LoginFooter />
    </div>
  );
};

export default Login;
