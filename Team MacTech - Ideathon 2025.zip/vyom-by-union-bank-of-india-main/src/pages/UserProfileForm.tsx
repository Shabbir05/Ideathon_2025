
import React from "react";
import ProfileForm from "@/components/user/ProfileForm";

const UserProfileForm = () => {
  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold text-center mb-8 text-vyom-blue">
        User Profile Information
      </h1>
      <ProfileForm />
    </div>
  );
};

export default UserProfileForm;
