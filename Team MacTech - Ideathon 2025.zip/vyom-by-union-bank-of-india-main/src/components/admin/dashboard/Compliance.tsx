
import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, FileText, Download, CheckSquare, UserCheck, AlertCircle, Shield, Clock, Lock, ExternalLink, List
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { 
  Collapsible, CollapsibleContent, CollapsibleTrigger 
} from "@/components/ui/collapsible";

// Mock data for compliance alerts
const complianceAlerts = [
  { 
    id: 1, 
    title: "Daily Transaction Limit Exceeded", 
    description: "Multiple accounts exceeded daily transaction limits - potential money laundering risk", 
    timestamp: "2023-10-05 13:25:17", 
    severity: "high", 
    status: "open", 
    regulation: "AML-CFT",
    category: "Transaction Monitoring"
  },
  { 
    id: 2, 
    title: "KYC Documentation Expiring", 
    description: "24 customer accounts have KYC documentation expiring in next 7 days", 
    timestamp: "2023-10-05 09:12:35", 
    severity: "medium", 
    status: "open", 
    regulation: "RBI-KYC",
    category: "Documentation"
  },
  { 
    id: 3, 
    title: "Suspicious International Transfers", 
    description: "Pattern of small international transfers to high-risk jurisdiction detected", 
    timestamp: "2023-10-05 07:55:22", 
    severity: "critical", 
    status: "investigating", 
    regulation: "FATF Guidelines",
    category: "International Transfers"
  },
  { 
    id: 4, 
    title: "Missing Consent Records", 
    description: "17 accounts missing required consent for data sharing", 
    timestamp: "2023-10-04 16:40:12", 
    severity: "medium", 
    status: "resolved", 
    regulation: "GDPR/DPA",
    category: "Data Protection"
  },
  { 
    id: 5, 
    title: "Audit Log Tampering Attempt", 
    description: "Potential attempt to modify system audit logs detected", 
    timestamp: "2023-10-04 11:22:19", 
    severity: "critical", 
    status: "investigating", 
    regulation: "IT Security",
    category: "System Security"
  }
];

// Mock data for audit logs
const auditLogs = [
  {
    id: 1,
    user: "Amit Singh (Admin)",
    action: "approved_transaction",
    details: "Manually approved high-value transaction for CUST87654",
    timestamp: "2023-10-05 14:22:17",
    ipAddress: "192.168.1.45",
    status: "completed"
  },
  {
    id: 2,
    user: "Priya Mehta (Compliance)",
    action: "generated_report",
    details: "Generated monthly AML compliance report",
    timestamp: "2023-10-05 11:05:32",
    ipAddress: "192.168.1.67",
    status: "completed"
  },
  {
    id: 3,
    user: "Vikram Singh (Admin)",
    action: "modified_user_rights",
    details: "Elevated privileges for user EMP00432",
    timestamp: "2023-10-05 10:17:45",
    ipAddress: "192.168.1.22",
    status: "completed"
  },
  {
    id: 4,
    user: "System",
    action: "auto_froze_account",
    details: "Automatically froze account CUST45678 due to fraud detection",
    timestamp: "2023-10-05 09:22:11",
    ipAddress: "127.0.0.1",
    status: "completed"
  },
  {
    id: 5,
    user: "Rajiv Gupta (Security)",
    action: "whitelisted_ip",
    details: "Added IP 203.45.78.90 to whitelist for international access",
    timestamp: "2023-10-05 08:55:30",
    ipAddress: "192.168.1.36",
    status: "completed"
  }
];

// Mock data for available reports
const availableReports = [
  {
    id: 1,
    title: "Monthly Compliance Summary - September 2023",
    type: "Monthly",
    category: "General",
    format: "PDF",
    size: "4.2 MB",
    generated: "2023-10-01 00:00:00",
    status: "ready"
  },
  {
    id: 2,
    title: "Suspicious Activity Report - Q3 2023",
    type: "Quarterly",
    category: "AML/CFT",
    format: "PDF",
    size: "8.7 MB",
    generated: "2023-10-01 00:00:00",
    status: "ready"
  },
  {
    id: 3,
    title: "KYC Compliance Audit Report",
    type: "Ad-hoc",
    category: "KYC",
    format: "Excel",
    size: "5.1 MB",
    generated: "2023-09-28 14:22:17",
    status: "ready"
  },
  {
    id: 4,
    title: "Regulatory Examination Preparation Report",
    type: "Annual",
    category: "Regulatory",
    format: "PDF",
    size: "12.3 MB",
    generated: "2023-09-15 09:30:45",
    status: "ready"
  },
  {
    id: 5,
    title: "Data Privacy Compliance Status",
    type: "Monthly",
    category: "Data Protection",
    format: "PDF",
    size: "3.8 MB",
    generated: "2023-09-30 23:59:59",
    status: "ready"
  }
];

const Compliance = () => {
  const [consentTrackingEnabled, setConsentTrackingEnabled] = useState(true);
  
  const handleResolveAlert = (alertId: number) => {
    toast({
      title: "Alert Marked as Resolved",
      description: `Compliance alert ID ${alertId} has been marked as resolved.`,
    });
  };
  
  const handleInvestigateAlert = (alertId: number) => {
    toast({
      title: "Investigation Initiated",
      description: `Investigation started for compliance alert ID ${alertId}.`,
    });
  };
  
  const handleDownloadReport = (reportId: number) => {
    toast({
      title: "Report Download Started",
      description: "The compliance report is being downloaded.",
    });
  };
  
  const generateComplianceReport = () => {
    toast({
      title: "Report Generation Initiated",
      description: "A new compliance report is being generated. You will be notified when it's ready.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Active Alerts
            </CardTitle>
            <CardDescription>Compliance issues requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-500">5</div>
            <p className="text-sm text-vyom-gray">
              <span className="text-red-500 font-medium">2 critical</span>,
              <span className="text-amber-500 font-medium"> 2 high</span>
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <CheckSquare className="h-5 w-5 text-green-500" />
              Compliance Score
            </CardTitle>
            <CardDescription>Overall regulatory compliance status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-500">92%</div>
            <p className="text-sm text-vyom-gray">↑ 3% from last month</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <FileText className="h-5 w-5 text-vyom-blue" />
              Reports Ready
            </CardTitle>
            <CardDescription>Compliance reports available for download</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-vyom-blue">5</div>
            <p className="text-sm text-vyom-gray">Last generated: Today</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <UserCheck className="h-5 w-5 text-purple-500" />
              Consent Compliance
            </CardTitle>
            <CardDescription>Customer consent tracking status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-500">98.5%</div>
            <p className="text-sm text-vyom-gray">17 records pending update</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Compliance Alerts & Violations
          </CardTitle>
          <CardDescription>Real-time compliance monitoring alerts requiring attention</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Alert</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Regulation</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {complianceAlerts.map((alert) => (
                <TableRow key={alert.id}>
                  <TableCell className="font-medium">{alert.title}</TableCell>
                  <TableCell className="max-w-xs truncate" title={alert.description}>
                    {alert.description}
                  </TableCell>
                  <TableCell>{alert.timestamp}</TableCell>
                  <TableCell>
                    {alert.severity === "critical" && (
                      <Badge className="bg-red-100 text-red-800 border-red-200">Critical</Badge>
                    )}
                    {alert.severity === "high" && (
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200">High</Badge>
                    )}
                    {alert.severity === "medium" && (
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200">Medium</Badge>
                    )}
                    {alert.severity === "low" && (
                      <Badge className="bg-green-100 text-green-800 border-green-200">Low</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {alert.status === "open" && (
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200">Open</Badge>
                    )}
                    {alert.status === "investigating" && (
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">Investigating</Badge>
                    )}
                    {alert.status === "resolved" && (
                      <Badge className="bg-green-100 text-green-800 border-green-200">Resolved</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-xs">{alert.regulation}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      {alert.status !== "resolved" && (
                        <>
                          {alert.status === "open" ? (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="h-8 px-2 text-xs"
                              onClick={() => handleInvestigateAlert(alert.id)}
                            >
                              Investigate
                            </Button>
                          ) : (
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="h-8 px-2 text-xs bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                              onClick={() => handleResolveAlert(alert.id)}
                            >
                              Resolve
                            </Button>
                          )}
                        </>
                      )}
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="h-8 px-2 text-xs"
                      >
                        Details
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-vyom-gray">Showing 5 of 13 alerts</div>
          <Button variant="outline" size="sm">View All Alerts</Button>
        </CardFooter>
      </Card>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <List className="h-5 w-5 text-vyom-blue" />
              Audit Log Tracking
            </CardTitle>
            <CardDescription>Record of admin and system actions for compliance</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {auditLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="font-medium">{log.user}</TableCell>
                    <TableCell>
                      <Collapsible>
                        <CollapsibleTrigger className="text-vyom-blue hover:underline cursor-pointer">
                          {log.action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </CollapsibleTrigger>
                        <CollapsibleContent className="text-xs text-vyom-gray mt-1 bg-gray-50 p-2 rounded-md">
                          <div><span className="font-medium">Details:</span> {log.details}</div>
                          <div><span className="font-medium">IP:</span> {log.ipAddress}</div>
                        </CollapsibleContent>
                      </Collapsible>
                    </TableCell>
                    <TableCell>{log.timestamp}</TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-800 border-green-200">Completed</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="mt-4 text-center">
              <Button variant="outline" size="sm">View Complete Audit Log</Button>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-vyom-blue" />
              Compliance Reports
            </CardTitle>
            <CardDescription>Generated reports for regulatory compliance</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Generated</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {availableReports.map((report) => (
                  <TableRow key={report.id}>
                    <TableCell className="font-medium">
                      {report.title}
                      <div className="text-xs text-vyom-gray">{report.category} · {report.format} · {report.size}</div>
                    </TableCell>
                    <TableCell>
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200">{report.type}</Badge>
                    </TableCell>
                    <TableCell>{new Date(report.generated).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="h-8 px-2 text-xs flex items-center gap-1"
                        onClick={() => handleDownloadReport(report.id)}
                      >
                        <Download className="h-3 w-3" />
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <div className="mt-4 flex justify-center">
              <Button 
                variant="default" 
                className="flex items-center gap-2"
                onClick={generateComplianceReport}
              >
                <FileText className="h-4 w-4" />
                Generate New Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-vyom-blue" />
            Regulatory Compliance Calendar
          </CardTitle>
          <CardDescription>Upcoming regulatory deadlines and compliance tasks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-md">
              <div className="flex-shrink-0 bg-red-100 p-2 rounded-full mr-4">
                <Clock className="h-5 w-5 text-red-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-red-800">Quarterly AML Report Submission</h4>
                <p className="text-sm text-red-600">Due in 3 days - October 8, 2023</p>
              </div>
              <Button variant="outline" size="sm" className="ml-4">
                Prepare
              </Button>
            </div>
            
            <div className="flex items-center p-3 bg-amber-50 border border-amber-200 rounded-md">
              <div className="flex-shrink-0 bg-amber-100 p-2 rounded-full mr-4">
                <Clock className="h-5 w-5 text-amber-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-amber-800">Monthly KYC Compliance Review</h4>
                <p className="text-sm text-amber-600">Due in 7 days - October 12, 2023</p>
              </div>
              <Button variant="outline" size="sm" className="ml-4">
                Review
              </Button>
            </div>
            
            <div className="flex items-center p-3 bg-blue-50 border border-blue-200 rounded-md">
              <div className="flex-shrink-0 bg-blue-100 p-2 rounded-full mr-4">
                <Clock className="h-5 w-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-blue-800">Annual Cybersecurity Assessment</h4>
                <p className="text-sm text-blue-600">Due in 14 days - October 19, 2023</p>
              </div>
              <Button variant="outline" size="sm" className="ml-4">
                Schedule
              </Button>
            </div>
            
            <div className="flex items-center p-3 bg-gray-50 border border-gray-200 rounded-md">
              <div className="flex-shrink-0 bg-gray-100 p-2 rounded-full mr-4">
                <Clock className="h-5 w-5 text-gray-600" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium">Data Privacy Policy Review</h4>
                <p className="text-sm text-vyom-gray">Due in 30 days - November 4, 2023</p>
              </div>
              <Button variant="outline" size="sm" className="ml-4">
                Plan
              </Button>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="text-sm text-vyom-gray">4 upcoming compliance deadlines</div>
          <Button variant="outline" size="sm">View Complete Calendar</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Compliance;
