
import { useState } from "react";
import { 
  CreditCard, 
  TrendingUp, 
  Shield, 
  ArrowUpRight, 
  Clock, 
  Download,
  Eye,
  EyeOff,
  QrCode,
  Book,
  Smartphone,
  LineChart,
  FileText,
  Lock,
  Wallet,
  CreditCard as CreditCardIcon,
  BadgePercent,
  ArrowRight,
  Landmark,
  BarChart3,
  PieChart,
  DollarSign,
  ShoppingCart,
  Home,
  Car,
  Coffee
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { Carousel, CarouselContent, CarouselItem, CarouselPrevious, CarouselNext } from "@/components/ui/carousel";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useNavigate } from "react-router-dom";
import { 
  ChartContainer, 
  ChartLegend, 
  ChartLegendContent, 
  ChartTooltip, 
  ChartTooltipContent 
} from "@/components/ui/chart";
import { BarChart, Bar, PieChart as RechartsChart, Pie, Cell, ResponsiveContainer, LineChart as RLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

interface AccountOverviewProps {
  accountType?: string;
  accountNumber?: string;
  balance?: number;
  currency?: string;
}

const AccountOverview = ({
  accountType = "Savings Account",
  accountNumber = "XXXX XXXX XXXX 4523",
  balance = 157892.45,
  currency = "₹",
}: AccountOverviewProps) => {
  // Define BanknoteIcon here at the top (moved from the bottom)
  const BanknoteIcon = Wallet; // Using Wallet icon for Banknote

  const [isBalanceVisible, setIsBalanceVisible] = useState(false);
  const [isAccountNumberVisible, setIsAccountNumberVisible] = useState(false);
  const [showDetailedReport, setShowDetailedReport] = useState(false);
  const [showAllTransactions, setShowAllTransactions] = useState(false);
  const navigate = useNavigate();

  // Format the balance with commas and two decimal places
  const formattedBalance = new Intl.NumberFormat("en-IN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(balance);

  // Masked versions
  const maskedBalance = "XX,XXX.XX";
  const maskedAccountNumber = "XXXX XXXX XXXX XXXX";
  const displayedAccountNumber = isAccountNumberVisible ? accountNumber : maskedAccountNumber;

  // Recent transactions data
  const recentTransactions = [
    { id: 1, type: "credit", description: "Salary Deposit", amount: 75000, date: "Yesterday", category: "Income" },
    { id: 2, type: "debit", description: "Amazon Payment", amount: 3540.50, date: "2 days ago", category: "Shopping" },
    { id: 3, type: "debit", description: "Electric Bill", amount: 1260.75, date: "3 days ago", category: "Utilities" },
    { id: 4, type: "debit", description: "Grocery Store", amount: 2150.25, date: "4 days ago", category: "Groceries" },
    { id: 5, type: "debit", description: "Movie Tickets", amount: 600.00, date: "5 days ago", category: "Entertainment" },
    { id: 6, type: "debit", description: "Fuel", amount: 1850.50, date: "6 days ago", category: "Transport" },
    { id: 7, type: "credit", description: "Freelance Payment", amount: 15000.00, date: "1 week ago", category: "Income" },
    { id: 8, type: "debit", description: "Phone Bill", amount: 999.00, date: "1 week ago", category: "Utilities" },
    { id: 9, type: "debit", description: "Restaurant", amount: 1750.25, date: "1 week ago", category: "Dining" },
    { id: 10, type: "debit", description: "Online Course", amount: 4999.00, date: "2 weeks ago", category: "Education" }
  ];

  // Chart data for financial insights
  const spendingData = [
    { name: 'Mon', amount: 1200 },
    { name: 'Tue', amount: 1800 },
    { name: 'Wed', amount: 1000 },
    { name: 'Thu', amount: 2200 },
    { name: 'Fri', amount: 1500 },
    { name: 'Sat', amount: 2500 },
    { name: 'Sun', amount: 1900 }
  ];

  const categorySpendingData = [
    { name: 'Shopping', value: 8500, fill: '#3b82f6' },
    { name: 'Food', value: 5200, fill: '#10b981' },
    { name: 'Transport', value: 3800, fill: '#f59e0b' },
    { name: 'Bills', value: 6300, fill: '#ef4444' },
    { name: 'Entertainment', value: 2100, fill: '#8b5cf6' }
  ];

  const savingsData = [
    { month: 'Jan', amount: 35000 },
    { month: 'Feb', amount: 38000 },
    { month: 'Mar', amount: 37500 },
    { month: 'Apr', amount: 42000 },
    { month: 'May', amount: 45000 },
    { month: 'Jun', amount: 48000 }
  ];

  // Offers data
  const offers = [
    { 
      id: 1, 
      title: "Personal Loan", 
      description: "Get instant personal loans at 9.5% p.a.", 
      image: "loan-offer.png", 
      bgColor: "from-blue-50 to-blue-100",
      icon: <BanknoteIcon className="text-vyom-blue" />
    },
    { 
      id: 2, 
      title: "Travel Credit Card", 
      description: "2X rewards on travel bookings & lounge access", 
      image: "card-offer.png", 
      bgColor: "from-purple-50 to-purple-100",
      icon: <CreditCardIcon className="text-vyom-purple" />
    },
    { 
      id: 3, 
      title: "Forex Account", 
      description: "Zero conversion fee on foreign transactions", 
      image: "forex-offer.png",
      bgColor: "from-green-50 to-green-100",
      icon: <Landmark className="text-vyom-green" />
    },
    { 
      id: 4, 
      title: "Term Insurance", 
      description: "Secure your family's future from ₹500/month", 
      image: "insurance-offer.png",
      bgColor: "from-amber-50 to-amber-100",
      icon: <Shield className="text-amber-600" />
    }
  ];

  const handleToggleBalanceVisibility = () => {
    setIsBalanceVisible(!isBalanceVisible);
  };

  const handleToggleAccountNumberVisibility = () => {
    setIsAccountNumberVisible(!isAccountNumberVisible);
  };

  const handleDownloadReport = () => {
    // Simulate download
    setTimeout(() => {
      toast({
        title: "Report Downloaded",
        description: "Your account report has been downloaded successfully.",
      });
      setShowDetailedReport(false);
    }, 1500);
  };

  const handleNavigateTo = (path: string) => {
    // Show toast notification
    toast({
      title: "Navigating",
      description: `Going to ${path}...`,
    });
    
    // Navigate to the path
    navigate(path);
  };

  const handleApplyNow = (offerId: number) => {
    const offer = offers.find(o => o.id === offerId);
    if (offer) {
      toast({
        title: "Applying for Offer",
        description: `Taking you to ${offer.title} application page...`,
      });
      handleNavigateTo("/dashboard/apply-offer");
    }
  };

  const handleViewAllTransactions = () => {
    setShowAllTransactions(true);
  };

  const handleViewDetailedReport = () => {
    setShowDetailedReport(true);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <Card className="overflow-hidden border-none shadow-lg">
        <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-teal" />
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex justify-between items-center">
            <span>{accountType}</span>
            <Shield size={20} className="text-vyom-teal" />
          </CardTitle>
          <CardDescription className="flex items-center gap-2">
            <span>{displayedAccountNumber}</span>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-6 w-6 rounded-full" 
              onClick={handleToggleAccountNumberVisibility}
            >
              {isAccountNumberVisible ? 
                <EyeOff size={14} className="text-vyom-gray" /> : 
                <Eye size={14} className="text-vyom-gray" />
              }
            </Button>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            <p className="text-sm text-vyom-gray">Available Balance</p>
            <p className="text-3xl font-semibold flex items-center gap-1 gradient-text">
              <span className="text-lg">{currency}</span>
              <span className="transition-all duration-300">
                {isBalanceVisible ? formattedBalance : maskedBalance}
              </span>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 rounded-full ml-1" 
                onClick={handleToggleBalanceVisibility}
              >
                {isBalanceVisible ? 
                  <EyeOff size={14} className="text-vyom-gray" /> : 
                  <Eye size={14} className="text-vyom-gray" />
                }
              </Button>
            </p>
          </div>
          
          <div className="mt-4 border-t pt-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-vyom-gray">Quick Actions</span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="link" className="text-vyom-blue p-0 h-auto">
                    View All <ArrowUpRight size={14} />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[200px]">
                  <DropdownMenuItem onClick={() => handleNavigateTo("/dashboard/rewards")}>
                    <BadgePercent size={16} className="mr-2" /> Rewards
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigateTo("/dashboard/loans")}>
                    <BanknoteIcon size={16} className="mr-2" /> Loans
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigateTo("/dashboard/deposits")}>
                    <Landmark size={16} className="mr-2" /> Deposits
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigateTo("/dashboard/insights")}>
                    <LineChart size={16} className="mr-2" /> Investments
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigateTo("/dashboard/insurance")}>
                    <Shield size={16} className="mr-2" /> Insurance
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/cards")}
              >
                <div className="bg-vyom-blue/10 p-2 rounded-full">
                  <CreditCard size={16} className="text-vyom-blue" />
                </div>
                <span className="text-xs font-medium">Cards</span>
              </div>
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/transfers")}
              >
                <div className="bg-vyom-teal/10 p-2 rounded-full">
                  <TrendingUp size={16} className="text-vyom-teal" />
                </div>
                <span className="text-xs font-medium">Transfers</span>
              </div>
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/statement")}
              >
                <div className="bg-vyom-purple/10 p-2 rounded-full">
                  <Download size={16} className="text-vyom-purple" />
                </div>
                <span className="text-xs font-medium">Statement</span>
              </div>
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/bhim-upi")}
              >
                <div className="bg-green-100 p-2 rounded-full">
                  <Smartphone size={16} className="text-vyom-green" />
                </div>
                <span className="text-xs font-medium">BHIM UPI</span>
              </div>
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/scan-qr")}
              >
                <div className="bg-red-100 p-2 rounded-full">
                  <QrCode size={16} className="text-vyom-red" />
                </div>
                <span className="text-xs font-medium">Scan QR</span>
              </div>
              <div 
                className="flex flex-col items-center gap-1 p-2 rounded-lg hover:bg-vyom-light transition-colors cursor-pointer"
                onClick={() => handleNavigateTo("/dashboard/mpassbook")}
              >
                <div className="bg-amber-100 p-2 rounded-full">
                  <Book size={16} className="text-amber-600" />
                </div>
                <span className="text-xs font-medium">mPassbook</span>
              </div>
            </div>
          </div>
          
          {/* Offers Carousel */}
          <div className="mt-4 border-t pt-4">
            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-vyom-gray">Offers For You</span>
              <Button 
                variant="link" 
                className="text-vyom-blue p-0 h-auto"
                onClick={() => handleNavigateTo("/dashboard/all-offers")}
              >
                All Offers <ArrowRight size={14} />
              </Button>
            </div>
            <Carousel
              opts={{
                align: "start",
                loop: true,
              }}
              className="w-full"
            >
              <CarouselContent>
                {offers.map((offer) => (
                  <CarouselItem key={offer.id} className="basis-full sm:basis-1/2 md:basis-1/2 lg:basis-1/3">
                    <div 
                      className={`p-3 rounded-lg cursor-pointer border border-gray-100 hover:shadow-md transition-all bg-gradient-to-br ${offer.bgColor}`}
                      onClick={() => handleNavigateTo("/dashboard/apply-offer")}
                    >
                      <div className="flex items-start gap-3">
                        <div className="bg-white p-2 rounded-full">
                          {offer.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-sm">{offer.title}</h3>
                          <p className="text-xs text-vyom-gray mt-1">{offer.description}</p>
                          <Button 
                            variant="link" 
                            className="text-xs p-0 h-4 mt-2"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleApplyNow(offer.id);
                            }}
                          >
                            Apply Now
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="hidden sm:flex justify-end gap-1 mt-2">
                <CarouselPrevious className="static transform-none mx-0 bg-white" />
                <CarouselNext className="static transform-none mx-0 bg-white" />
              </div>
            </Carousel>
          </div>

          {/* Enhanced Graphical Insights Section */}
          <div className="mt-4 border-t pt-4">
            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-vyom-gray">Financial Insights</span>
              <Button 
                variant="link" 
                className="text-vyom-blue p-0 h-auto"
                onClick={() => handleNavigateTo("/dashboard/insights")}
              >
                See More <ArrowUpRight size={14} />
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Spending Trend Chart */}
              <div className="p-3 rounded-lg border border-gray-100 bg-gradient-to-br from-gray-50 to-white">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium flex items-center gap-1">
                    <BarChart3 size={14} className="text-vyom-blue" />
                    Weekly Spending
                  </h3>
                </div>
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={spendingData} margin={{ top: 10, right: 10, left: 0, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <Tooltip 
                        cursor={{ fill: 'rgba(0, 0, 0, 0.05)' }}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                        formatter={(value) => [`₹${value}`, 'Amount']}
                        labelFormatter={(label) => `Day: ${label}`}
                      />
                      <Bar dataKey="amount" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Category Spending Chart */}
              <div className="p-3 rounded-lg border border-gray-100 bg-gradient-to-br from-gray-50 to-white">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium flex items-center gap-1">
                    <PieChart size={14} className="text-vyom-teal" />
                    Spending by Category
                  </h3>
                </div>
                <div className="h-[180px] flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsChart>
                      <Pie
                        data={categorySpendingData}
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={70}
                        dataKey="value"
                        paddingAngle={2}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        labelLine={false}
                      >
                        {categorySpendingData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => [`₹${value}`, 'Amount']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                    </RechartsChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Savings Growth Chart */}
              <div className="p-3 rounded-lg border border-gray-100 bg-gradient-to-br from-gray-50 to-white sm:col-span-2">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium flex items-center gap-1">
                    <TrendingUp size={14} className="text-vyom-green" />
                    Savings Growth
                  </h3>
                </div>
                <div className="h-[180px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RLineChart data={savingsData} margin={{ top: 10, right: 10, left: 10, bottom: 10 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10 }} axisLine={false} tickLine={false} />
                      <Tooltip 
                        cursor={{ stroke: '#ccc', strokeWidth: 1 }}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                        formatter={(value) => [`₹${value}`, 'Amount']}
                        labelFormatter={(label) => `Month: ${label}`}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="amount" 
                        stroke="#22c55e" 
                        strokeWidth={2} 
                        activeDot={{ r: 6 }} 
                        dot={{ r: 4, strokeWidth: 2, fill: '#fff' }}
                      />
                    </RLineChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              {/* Spending Advice Section */}
              <div className="p-3 rounded-lg border border-gray-100 bg-gradient-to-br from-blue-50 to-white sm:col-span-2">
                <h3 className="text-sm font-medium mb-2">Financial Recommendations</h3>
                <ul className="text-xs space-y-3">
                  <li className="flex items-start gap-2">
                    <div className="min-w-4 h-4 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                      <TrendingUp size={10} className="text-vyom-green" />
                    </div>
                    <div>
                      <span className="text-vyom-gray">Consider increasing your monthly SIP contribution by 10% to accelerate your retirement fund growth.</span>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="min-w-4 h-4 bg-red-100 rounded-full flex items-center justify-center mt-0.5">
                      <ShoppingCart size={10} className="text-vyom-red" />
                    </div>
                    <div>
                      <span className="text-vyom-gray">Your shopping expenses have increased by 15% compared to last month. Consider reviewing discretionary purchases.</span>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="min-w-4 h-4 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                      <Shield size={10} className="text-vyom-blue" />
                    </div>
                    <div>
                      <span className="text-vyom-gray">You don't have adequate health insurance coverage. Explore our comprehensive health plans starting at just ₹500/month.</span>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="mt-4 border-t pt-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-vyom-gray">Recent Transactions</span>
              <Button 
                variant="link" 
                className="text-vyom-blue p-0 h-auto"
                onClick={() => handleNavigateTo("/dashboard/transactions")}
              >
                See All <ArrowUpRight size={14} />
              </Button>
            </div>
            <div className="space-y-3">
              {recentTransactions.slice(0, 3).map(transaction => (
                <div key={transaction.id} className="flex items-center justify-between py-1 dashboard-item rounded-lg px-2">
                  <div className="flex items-center gap-3">
                    <div className={`${transaction.type === 'credit' ? 'bg-green-100' : 'bg-red-100'} p-2 rounded-full`}>
                      {transaction.type === 'credit' ? (
                        <ArrowUpRight size={14} className="text-vyom-green" />
                      ) : (
                        <Clock size={14} className="text-vyom-red" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{transaction.description}</p>
                      <p className="text-xs text-vyom-gray">{transaction.date}</p>
                    </div>
                  </div>
                  <p className={`text-sm font-medium ${transaction.type === 'credit' ? 'text-vyom-green' : 'text-vyom-red'}`}>
                    {transaction.type === 'credit' ? '+' : '-'}
                    {currency} {transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Center Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <Card className="shadow-md hover:shadow-lg transition-all duration-300 card-hover cursor-pointer"
              onClick={() => handleNavigateTo("/dashboard/security")}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-3 rounded-full">
                <Lock className="text-vyom-blue h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Security Center</h3>
                <p className="text-sm text-vyom-gray">Review security settings</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all duration-300 card-hover cursor-pointer"
              onClick={() => handleNavigateTo("/dashboard/cards-management")}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-teal-100 p-3 rounded-full">
                <CreditCardIcon className="text-vyom-teal h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Card Management</h3>
                <p className="text-sm text-vyom-gray">Manage your cards</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-md hover:shadow-lg transition-all duration-300 card-hover cursor-pointer"
              onClick={() => handleNavigateTo("/dashboard/quick-pay")}>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-3 rounded-full">
                <Wallet className="text-vyom-purple h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium">Quick Pay</h3>
                <p className="text-sm text-vyom-gray">UPI & other payment methods</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Report Dialog */}
      <Dialog open={showDetailedReport} onOpenChange={setShowDetailedReport}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Detailed Financial Report</DialogTitle>
            <DialogDescription>
              Your personalized financial report with detailed analysis and recommendations.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <div className="p-4 bg-vyom-light rounded-lg">
                <h4 className="font-medium mb-2">Report Contents</h4>
                <ul className="text-sm space-y-2">
                  <li className="flex items-center gap-2">
                    <FileText size={16} className="text-vyom-blue" />
                    <span>Account Summary</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <LineChart size={16} className="text-vyom-blue" />
                    <span>Transaction Analysis</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <TrendingUp size={16} className="text-vyom-blue" />
                    <span>Spending Patterns</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <BanknoteIcon size={16} className="text-vyom-blue" />
                    <span>Savings Recommendations</span>
                  </li>
                </ul>
              </div>
              <div className="text-sm text-vyom-gray">
                This report contains your personal financial information. Please ensure you're in a private location before downloading.
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetailedReport(false)}>
              Cancel
            </Button>
            <Button onClick={handleDownloadReport}>
              Download Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* All Transactions Dialog */}
      <Dialog open={showAllTransactions} onOpenChange={setShowAllTransactions}>
        <DialogContent className="sm:max-w-[800px]">
          <DialogHeader>
            <DialogTitle>Transaction History</DialogTitle>
            <DialogDescription>
              View all your recent transactions and download statements
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium">Recent Transactions</h3>
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-1"
                onClick={() => {
                  toast({
                    title: "Statement Downloaded",
                    description: "Your account statement has been downloaded successfully.",
                  });
                }}
              >
                <Download size={14} /> Download Statement
              </Button>
            </div>
            <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
              {recentTransactions.map(transaction => (
                <div key={transaction.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                  <div className="flex items-center gap-3">
                    <div className={`${transaction.type === 'credit' ? 'bg-green-100' : 'bg-red-100'} p-2 rounded-full`}>
                      {
                        transaction.type === 'credit' ? (
                          <ArrowUpRight size={14} className="text-vyom-green" />
                        ) : transaction.category === 'Shopping' ? (
                          <ShoppingCart size={14} className="text-vyom-red" />
                        ) : transaction.category === 'Utilities' ? (
                          <Home size={14} className="text-vyom-red" />
                        ) : transaction.category === 'Transport' ? (
                          <Car size={14} className="text-vyom-red" />
                        ) : transaction.category === 'Dining' ? (
                          <Coffee size={14} className="text-vyom-red" />
                        ) : (
                          <Clock size={14} className="text-vyom-red" />
                        )
                      }
                    </div>
                    <div>
                      <p className="text-sm font-medium">{transaction.description}</p>
                      <div className="flex items-center gap-2">
                        <p className="text-xs text-vyom-gray">{transaction.date}</p>
                        <span className="text-xs px-2 py-0.5 bg-gray-100 rounded-full">{transaction.category}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-medium ${transaction.type === 'credit' ? 'text-vyom-green' : 'text-vyom-red'}`}>
                      {transaction.type === 'credit' ? '+' : '-'}
                      {currency} {transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </p>
                    <Button 
                      variant="link" 
                      className="text-xs p-0 h-4"
                      onClick={() => {
                        toast({
                          title: "Transaction Details",
                          description: `Viewing details for ${transaction.description}`,
                        });
                      }}
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAllTransactions(false)}>
              Close
            </Button>
            <Button 
              onClick={() => {
                setShowAllTransactions(false); 
                handleNavigateTo("/dashboard/transactions");
              }}
            >
              View Full History
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AccountOverview;
