
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  Smartphone, 
  QrCode, 
  Send, 
  CreditCard, 
  Landmark, 
  Clock, 
  UserPlus, 
  Search, 
  BadgePercent, 
  Download,
  Wallet,
  Receipt,
  History
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const QuickPay = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("upi");
  const [paymentAmount, setPaymentAmount] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState("");
  
  const recentContacts = [
    { id: 1, name: "Rahul", upiId: "rahul@vyombank", mobile: "9876543210", image: null },
    { id: 2, name: "Priya", upiId: "priya@vyombank", mobile: "9876543211", image: null },
    { id: 3, name: "Ajay", upiId: "ajay@vyombank", mobile: "9876543212", image: null },
    { id: 4, name: "Sunita", upiId: "sunita@vyombank", mobile: "9876543213", image: null },
    { id: 5, name: "Rohan", upiId: "rohan@vyombank", mobile: "9876543214", image: null },
    { id: 6, name: "Neha", upiId: "neha@vyombank", mobile: "9876543215", image: null }
  ];
  
  const recentTransactions = [
    { id: 1, name: "Rahul", amount: "5,000.00", date: "Today, 14:30", type: "sent" },
    { id: 2, name: "Electricity Bill", amount: "1,450.00", date: "Yesterday", type: "bill" },
    { id: 3, name: "Priya", amount: "2,500.00", date: "2 days ago", type: "sent" },
    { id: 4, name: "Mobile Recharge", amount: "799.00", date: "3 days ago", type: "recharge" }
  ];

  const filteredContacts = recentContacts.filter(contact => 
    contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.upiId.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.mobile.includes(searchQuery)
  );

  const handlePayment = (contactId?: number) => {
    if (!paymentAmount || isNaN(Number(paymentAmount)) || Number(paymentAmount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than zero.",
        variant: "destructive",
      });
      return;
    }
    
    const contact = contactId ? recentContacts.find(c => c.id === contactId) : null;
    
    toast({
      title: "Payment Initiated",
      description: contact 
        ? `Sending ₹${paymentAmount} to ${contact.name} (${contact.upiId})`
        : `Payment of ₹${paymentAmount} initiated`,
    });
    
    // Reset after payment
    setTimeout(() => {
      setPaymentAmount("");
      toast({
        title: "Payment Successful",
        description: contact 
          ? `₹${paymentAmount} sent to ${contact.name} successfully`
          : `Payment of ₹${paymentAmount} completed successfully`,
      });
    }, 1500);
  };

  const handleAddContact = () => {
    toast({
      title: "Add New Contact",
      description: "Opening contact form...",
    });
  };

  const presetAmounts = [100, 500, 1000, 2000, 5000];

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => navigate("/dashboard")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="col-span-1 md:col-span-2">
          <Card className="shadow-md border-none overflow-hidden">
            <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-purple"></div>
            <CardHeader>
              <CardTitle className="text-lg">Quick Pay</CardTitle>
              <CardDescription>Send money instantly via UPI, cards or net banking</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-3 w-full mb-6">
                  <TabsTrigger value="upi" className="flex items-center gap-1">
                    <Smartphone className="h-4 w-4" /> UPI
                  </TabsTrigger>
                  <TabsTrigger value="qr" className="flex items-center gap-1">
                    <QrCode className="h-4 w-4" /> Scan QR
                  </TabsTrigger>
                  <TabsTrigger value="netbanking" className="flex items-center gap-1">
                    <Landmark className="h-4 w-4" /> Net Banking
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="upi" className="space-y-6">
                  <div className="bg-vyom-light p-4 rounded-lg">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium mb-1 block">From Account</label>
                        <div className="flex items-center gap-2 p-2 border rounded-lg bg-white">
                          <Wallet className="h-4 w-4 text-vyom-blue" />
                          <span className="text-sm">Savings Account (₹157,892.45)</span>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium mb-1 block">Your UPI ID</label>
                        <div className="flex items-center gap-2 p-2 border rounded-lg bg-white">
                          <Smartphone className="h-4 w-4 text-vyom-blue" />
                          <span className="text-sm">9876543210@vyombank</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-vyom-gray" />
                      <Input 
                        placeholder="Search by name, UPI ID or phone number" 
                        className="pl-9"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                      />
                    </div>
                    <Button onClick={handleAddContact}>
                      <UserPlus className="h-4 w-4 mr-1" /> Add
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                    {filteredContacts.map(contact => (
                      <div 
                        key={contact.id} 
                        className="flex flex-col items-center p-3 rounded-lg hover:bg-vyom-light cursor-pointer transition-all"
                        onClick={() => {
                          if (paymentAmount) {
                            handlePayment(contact.id);
                          } else {
                            toast({
                              title: "Enter Amount First",
                              description: "Please enter an amount before selecting a contact.",
                            });
                          }
                        }}
                      >
                        <Avatar className="h-12 w-12 mb-2">
                          <AvatarImage src={contact.image || undefined} />
                          <AvatarFallback className="bg-vyom-blue/10 text-vyom-blue">
                            {contact.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs font-medium">{contact.name}</span>
                        <span className="text-xs text-vyom-gray">{contact.upiId}</span>
                      </div>
                    ))}
                    <div 
                      className="flex flex-col items-center p-3 rounded-lg hover:bg-vyom-light cursor-pointer transition-all"
                      onClick={handleAddContact}
                    >
                      <div className="h-12 w-12 rounded-full bg-vyom-purple/10 flex items-center justify-center mb-2">
                        <UserPlus className="h-6 w-6 text-vyom-purple" />
                      </div>
                      <span className="text-xs font-medium">Add New</span>
                      <span className="text-xs text-vyom-gray">Contact</span>
                    </div>
                  </div>
                  
                  <div className="border-t pt-6">
                    <div className="mb-6">
                      <label className="text-sm font-medium mb-2 block">Enter Amount (₹)</label>
                      <div className="flex flex-col gap-4">
                        <Input 
                          type="number" 
                          placeholder="Enter amount" 
                          className="text-lg"
                          value={paymentAmount}
                          onChange={(e) => setPaymentAmount(e.target.value)}
                        />
                        <div className="flex flex-wrap gap-2">
                          {presetAmounts.map(amount => (
                            <Button 
                              key={amount} 
                              variant="outline" 
                              size="sm"
                              onClick={() => setPaymentAmount(amount.toString())}
                            >
                              ₹{amount.toLocaleString()}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full"
                      disabled={!paymentAmount || isNaN(Number(paymentAmount)) || Number(paymentAmount) <= 0}
                      onClick={() => handlePayment()}
                    >
                      <Send className="h-4 w-4 mr-2" /> Pay Now
                    </Button>
                  </div>
                </TabsContent>
                
                <TabsContent value="qr" className="flex flex-col items-center justify-center p-6 space-y-4">
                  <div className="bg-white p-4 rounded-lg border shadow-sm">
                    <QrCode className="h-48 w-48 text-vyom-blue mx-auto" />
                  </div>
                  <p className="text-sm text-vyom-gray text-center">
                    Scan this QR code with any UPI app to pay
                  </p>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" /> Download QR Code
                  </Button>
                </TabsContent>
                
                <TabsContent value="netbanking" className="space-y-6">
                  <div className="bg-vyom-light p-4 rounded-lg">
                    <h3 className="font-medium mb-3">Transfer via Net Banking</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium mb-1 block">From Account</label>
                        <div className="flex items-center gap-2 p-2 border rounded-lg bg-white">
                          <Wallet className="h-4 w-4 text-vyom-blue" />
                          <span className="text-sm">Savings Account (₹157,892.45)</span>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium mb-1 block">Transfer Mode</label>
                        <select className="w-full p-2 border rounded-lg bg-white">
                          <option>IMPS - Immediate Payment</option>
                          <option>NEFT - National Electronic Fund Transfer</option>
                          <option>RTGS - Real Time Gross Settlement</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-1 block">Recipient Name</label>
                      <Input placeholder="Enter recipient name" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Account Number</label>
                      <Input placeholder="Enter account number" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">IFSC Code</label>
                      <Input placeholder="Enter IFSC code" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-1 block">Amount (₹)</label>
                      <Input 
                        type="number" 
                        placeholder="Enter amount" 
                        value={paymentAmount}
                        onChange={(e) => setPaymentAmount(e.target.value)}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-1 block">Remarks (Optional)</label>
                    <Input placeholder="Add remarks for this transaction" />
                  </div>
                  
                  <Button className="w-full">
                    <Send className="h-4 w-4 mr-2" /> Transfer Money
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        <div className="col-span-1 space-y-6">
          <Card className="shadow-md border-none overflow-hidden">
            <div className="h-1 bg-vyom-teal"></div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Clock className="h-4 w-4 text-vyom-teal" />
                Recent Activities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentTransactions.map(transaction => (
                <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg border">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full ${
                      transaction.type === 'sent' 
                        ? 'bg-blue-100' 
                        : transaction.type === 'bill'
                          ? 'bg-red-100'
                          : 'bg-purple-100'
                    }`}>
                      {transaction.type === 'sent' ? (
                        <Send className="h-3 w-3 text-vyom-blue" />
                      ) : transaction.type === 'bill' ? (
                        <Receipt className="h-3 w-3 text-vyom-red" />
                      ) : (
                        <Smartphone className="h-3 w-3 text-vyom-purple" />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{transaction.name}</p>
                      <p className="text-xs text-vyom-gray">{transaction.date}</p>
                    </div>
                  </div>
                  <p className="text-sm font-medium text-vyom-red">-₹{transaction.amount}</p>
                </div>
              ))}
              
              <Button variant="outline" className="w-full" onClick={() => navigate("/dashboard/transactions")}>
                <History className="h-4 w-4 mr-2" /> View All Transactions
              </Button>
            </CardContent>
          </Card>
          
          <Card className="shadow-md border-none overflow-hidden">
            <div className="h-1 bg-vyom-purple"></div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <BadgePercent className="h-4 w-4 text-vyom-purple" />
                Offers & Rewards
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-blue-50 rounded-lg">
                <h3 className="text-sm font-medium text-vyom-blue">Cashback on UPI Transactions</h3>
                <p className="text-xs text-vyom-gray mt-1">Get 1% cashback on all UPI transactions above ₹500</p>
                <p className="text-xs text-vyom-blue mt-2">Valid till: 30 Jun 2023</p>
              </div>
              
              <div className="p-3 bg-purple-50 rounded-lg">
                <h3 className="text-sm font-medium text-vyom-purple">Zero Fee Transfers</h3>
                <p className="text-xs text-vyom-gray mt-1">No charges on IMPS, NEFT, and RTGS transfers this month</p>
                <p className="text-xs text-vyom-purple mt-2">Valid till: 15 Jun 2023</p>
              </div>
              
              <Button variant="outline" className="w-full" onClick={() => navigate("/dashboard/rewards")}>
                <BadgePercent className="h-4 w-4 mr-2" /> View All Rewards
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default QuickPay;
