
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ProfileWithRisk, Profile, RiskAssessment, AssessmentDetails } from "./types";

export const useRiskAssessment = () => {
  const [profiles, setProfiles] = useState<ProfileWithRisk[]>([]);
  const [loading, setLoading] = useState(true);
  const [assessingId, setAssessingId] = useState<string | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState<RiskAssessment | null>(null);
  const { toast } = useToast();

  const fetchProfiles = async () => {
    setLoading(true);
    try {
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("*")
        .order("created_at", { ascending: false });

      if (profilesError) throw profilesError;

      const { data: assessmentsData, error: assessmentsError } = await supabase
        .from("risk_assessments")
        .select("*");

      if (assessmentsError) throw assessmentsError;

      const profilesWithRisk: ProfileWithRisk[] = profilesData.map((profile: Profile) => {
        const assessment = assessmentsData.find(
          (a: any) => a.profile_id === profile.id
        );
        
        let typedAssessment: RiskAssessment | null = null;
        if (assessment) {
          let parsedDetails: AssessmentDetails | null = null;
          
          if (assessment.assessment_details) {
            if (typeof assessment.assessment_details === 'string') {
              try {
                parsedDetails = JSON.parse(assessment.assessment_details) as AssessmentDetails;
              } catch (e) {
                console.error("Error parsing assessment details string:", e);
              }
            } else {
              parsedDetails = assessment.assessment_details as unknown as AssessmentDetails;
            }
          }
          
          typedAssessment = {
            ...assessment,
            assessment_details: parsedDetails
          };
        }
        
        return { 
          ...profile, 
          risk_assessment: typedAssessment 
        };
      });

      setProfiles(profilesWithRisk);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast({
        title: "Error fetching data",
        description: "Could not load profiles and risk assessments.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  // New function to calculate risk score directly without using edge function
  const calculateRiskScore = (profile: Profile) => {
    // Default medium risk
    let riskScore = 50;
    let riskFactors = [];
    
    // Age factor (younger and older users are higher risk)
    if (profile.age) {
      if (profile.age < 25) {
        riskScore += 15;
        riskFactors.push("Young age increases risk.");
      } else if (profile.age > 60) {
        riskScore += 10;
        riskFactors.push("Senior age slightly increases risk.");
      } else {
        riskScore -= 5;
        riskFactors.push("Middle age reduces risk.");
      }
    }
    
    // Income factor
    if (profile.annual_income) {
      if (profile.annual_income > 100000) {
        riskScore -= 15;
        riskFactors.push("High income reduces risk significantly.");
      } else if (profile.annual_income > 50000) {
        riskScore -= 5;
        riskFactors.push("Average income slightly reduces risk.");
      } else {
        riskScore += 10;
        riskFactors.push("Lower income increases risk.");
      }
    }
    
    // KYC verification is a major factor
    if (profile.kyc_verified) {
      riskScore -= 20;
      riskFactors.push("KYC verification significantly reduces risk.");
    } else {
      riskScore += 20;
      riskFactors.push("Lack of KYC verification significantly increases risk.");
    }
    
    // Marital status
    if (profile.marital_status === "Married") {
      riskScore -= 5;
      riskFactors.push("Married status slightly reduces risk.");
    }
    
    // Ensure score is within 0-100 range
    riskScore = Math.max(0, Math.min(100, riskScore));
    
    // Determine risk category
    let riskCategory;
    if (riskScore < 30) {
      riskCategory = "Low";
    } else if (riskScore < 70) {
      riskCategory = "Medium";
    } else {
      riskCategory = "High";
    }
    
    // Create assessment details
    const assessmentDetails = {
      age_factor: profile.age ? `Age ${profile.age} is a ${profile.age < 25 || profile.age > 60 ? 'risk' : 'positive'} factor.` : "Age is unknown.",
      occupation_factor: `Occupation "${profile.occupation || 'Unknown'}" has been considered in risk assessment.`,
      income_factor: profile.annual_income ? `Annual income of ${profile.annual_income} is a ${profile.annual_income > 50000 ? 'positive' : 'risk'} factor.` : "Income is unknown.",
      kyc_factor: `KYC verification is ${profile.kyc_verified ? 'complete which significantly reduces' : 'not complete which increases'} risk.`,
      marital_status_factor: `Marital status "${profile.marital_status || 'Unknown'}" has been factored into assessment.`,
      summary: `This is a ${riskCategory.toLowerCase()} risk profile (score: ${riskScore}) based on ${riskFactors.join(' ')}`,
    };
    
    return {
      riskScore,
      riskCategory,
      assessmentDetails
    };
  };

  const assessRisk = async (profileId: string) => {
    setAssessingId(profileId);
    try {
      // Find the profile to assess
      const profile = profiles.find(p => p.id === profileId);
      if (!profile) {
        throw new Error("Profile not found");
      }
      
      console.log("Calculating risk assessment locally for profile:", profileId);
      
      // Calculate risk directly without edge function
      const { riskScore, riskCategory, assessmentDetails } = calculateRiskScore(profile);
      
      console.log("Risk assessment calculation complete:", { riskScore, riskCategory });
      
      // Generate a UUID for the assessment
      const assessmentId = crypto.randomUUID();
      
      // Save the assessment to the database
      const { error } = await supabase
        .from("risk_assessments")
        .insert({
          id: assessmentId,
          profile_id: profileId,
          risk_score: riskScore,
          risk_category: riskCategory,
          assessment_details: assessmentDetails,
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error("Error saving assessment:", error);
        throw new Error(`Failed to save assessment: ${error.message}`);
      }
      
      toast({
        title: "Risk assessment complete",
        description: `Risk score: ${riskScore}, Category: ${riskCategory}`,
      });

      fetchProfiles();
    } catch (error) {
      console.error("Error assessing risk:", error);
      toast({
        title: "Risk assessment failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setAssessingId(null);
    }
  };

  const showAssessmentDetails = (profileId: string) => {
    const profile = profiles.find(p => p.id === profileId);
    if (profile?.risk_assessment) {
      setSelectedAssessment(profile.risk_assessment);
      setDetailsOpen(true);
    }
  };

  return {
    profiles,
    loading,
    assessingId,
    detailsOpen,
    selectedAssessment,
    setDetailsOpen,
    fetchProfiles,
    assessRisk,
    showAssessmentDetails
  };
};
