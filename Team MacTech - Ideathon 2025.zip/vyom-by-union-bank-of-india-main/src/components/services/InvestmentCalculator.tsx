
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface InvestmentCalculatorProps {
  onClose: () => void;
}

const InvestmentCalculator: React.FC<InvestmentCalculatorProps> = ({ onClose }) => {
  const [formData, setFormData] = useState({
    initialInvestment: 100000,
    monthlyContribution: 10000,
    timeHorizon: 10,
    expectedReturn: 12,
  });
  
  const [chartData, setChartData] = useState<{ year: number; investment: number; returns: number }[]>([]);

  useEffect(() => {
    calculateReturns();
  }, [formData]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const calculateReturns = () => {
    const { initialInvestment, monthlyContribution, timeHorizon, expectedReturn } = formData;
    
    const data = [];
    let totalInvestment = initialInvestment;
    let currentValue = initialInvestment;
    
    const monthlyRate = expectedReturn / 100 / 12;
    
    for (let year = 0; year <= timeHorizon; year++) {
      if (year > 0) {
        for (let month = 1; month <= 12; month++) {
          currentValue = (currentValue + monthlyContribution) * (1 + monthlyRate);
          totalInvestment += monthlyContribution;
        }
      }
      
      data.push({
        year,
        investment: Math.round(totalInvestment),
        returns: Math.round(currentValue),
      });
    }
    
    setChartData(data);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(value);
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl p-6 md:p-8 max-w-4xl w-full animate-fade-in overflow-y-auto max-h-[90vh]">
        <h3 className="text-2xl font-bold mb-4 text-vyom-blue">Investment Calculator</h3>
        <p className="text-vyom-gray mb-6">Plan your financial future with our investment calculator.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div>
              <label htmlFor="initialInvestment" className="block text-sm font-medium mb-1">
                Initial Investment (₹)
              </label>
              <Input 
                id="initialInvestment" 
                name="initialInvestment" 
                type="number" 
                value={formData.initialInvestment} 
                onChange={handleInputChange} 
                min="1000"
              />
            </div>
            
            <div>
              <label htmlFor="monthlyContribution" className="block text-sm font-medium mb-1">
                Monthly Contribution (₹)
              </label>
              <Input 
                id="monthlyContribution" 
                name="monthlyContribution" 
                type="number" 
                value={formData.monthlyContribution} 
                onChange={handleInputChange}
                min="0" 
              />
            </div>
            
            <div>
              <label htmlFor="timeHorizon" className="block text-sm font-medium mb-1">
                Investment Period (Years)
              </label>
              <Input 
                id="timeHorizon" 
                name="timeHorizon" 
                type="number" 
                value={formData.timeHorizon} 
                onChange={handleInputChange}
                min="1"
                max="40"
              />
            </div>
            
            <div>
              <label htmlFor="expectedReturn" className="block text-sm font-medium mb-1">
                Expected Annual Return (%)
              </label>
              <Input 
                id="expectedReturn" 
                name="expectedReturn" 
                type="number" 
                value={formData.expectedReturn} 
                onChange={handleInputChange}
                min="1"
                max="30"
                step="0.1"
              />
            </div>
            
            <div className="bg-vyom-light p-4 rounded-lg mt-6">
              <h4 className="font-semibold mb-2">Summary</h4>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm">Total Investment:</div>
                <div className="text-sm font-medium text-right">
                  {chartData.length > 0 ? formatCurrency(chartData[chartData.length - 1].investment) : 'N/A'}
                </div>
                <div className="text-sm">Estimated Returns:</div>
                <div className="text-sm font-medium text-vyom-blue text-right">
                  {chartData.length > 0 ? formatCurrency(chartData[chartData.length - 1].returns) : 'N/A'}
                </div>
                <div className="text-sm">Gain:</div>
                <div className="text-sm font-medium text-vyom-teal text-right">
                  {chartData.length > 0 ? formatCurrency(chartData[chartData.length - 1].returns - chartData[chartData.length - 1].investment) : 'N/A'}
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-4">Growth Projection</h4>
            <div className="h-64 md:h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={chartData}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="year" />
                  <YAxis tickFormatter={(value) => `₹${(value / 100000).toFixed(1)}L`} />
                  <Tooltip
                    formatter={(value: number) => formatCurrency(value)}
                    labelFormatter={(label) => `Year ${label}`}
                  />
                  <Legend />
                  <Line type="monotone" dataKey="investment" name="Total Investment" stroke="#3F83F8" />
                  <Line type="monotone" dataKey="returns" name="Projected Value" stroke="#0E9F6E" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
        
        <div className="flex justify-end mt-8">
          <Button onClick={onClose}>Close Calculator</Button>
        </div>
      </div>
    </div>
  );
};

export default InvestmentCalculator;
