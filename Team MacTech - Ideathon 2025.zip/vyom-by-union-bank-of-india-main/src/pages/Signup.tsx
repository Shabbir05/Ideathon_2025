
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Lock, Mail, User, Check, AlertCircle, Briefcase, CreditCard, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LanguageToggle from "@/components/LanguageToggle";
import { useToast } from "@/components/ui/use-toast";

const Signup = () => {
  const [userFormData, setUserFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    kycType: "aadhaar",
    kycNumber: "",
    occupation: "",
    annualIncome: "",
    gender: ""
  });
  
  const [adminFormData, setAdminFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
    employeeId: "",
    department: "",
    accessLevel: "standard",
    contactNumber: ""
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const handleUserFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserFormData((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleAdminFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAdminFormData((prev) => ({ ...prev, [name]: value }));
  };

  const toggleShowPassword = () => setShowPassword(!showPassword);
  const toggleShowConfirmPassword = () => setShowConfirmPassword(!showConfirmPassword);

  // Password strength indicators - used for both forms
  const checkPassword = (password: string) => {
    const hasMinLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return {
      hasMinLength, 
      hasUpperCase, 
      hasLowerCase, 
      hasNumber, 
      hasSpecialChar,
      strength: [hasMinLength, hasUpperCase, hasLowerCase, hasNumber, hasSpecialChar].filter(Boolean).length
    };
  };
  
  const userPasswordStrength = checkPassword(userFormData.password);
  const adminPasswordStrength = checkPassword(adminFormData.password);
  
  const getPasswordStrengthLabel = (strength: number, password: string) => {
    if (password === "") return "";
    if (strength <= 2) return "Weak";
    if (strength <= 4) return "Good";
    return "Strong";
  };
  
  const getPasswordStrengthColor = (strength: number, password: string) => {
    if (password === "") return "bg-gray-200";
    if (strength <= 2) return "bg-red-500";
    if (strength <= 4) return "bg-yellow-500";
    return "bg-green-500";
  };

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (userFormData.password !== userFormData.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    if (!agreedToTerms) {
      toast({
        title: "Terms and Conditions",
        description: "Please agree to the terms and conditions to continue.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    if (!userFormData.kycNumber) {
      toast({
        title: "KYC Verification Required",
        description: "Please provide your KYC details to continue.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "User account created successfully!",
        description: "Welcome to Vyom Banking. You can now log in.",
        duration: 3000,
      });
      navigate("/login");
    }, 1500);
  };
  
  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (adminFormData.password !== adminFormData.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    if (!agreedToTerms) {
      toast({
        title: "Terms and Conditions",
        description: "Please agree to the terms and conditions to continue.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    if (!adminFormData.employeeId) {
      toast({
        title: "Employee ID Required",
        description: "Please provide your employee ID to continue.",
        variant: "destructive",
        duration: 3000,
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Admin account created successfully!",
        description: "Welcome to Vyom Banking Admin Portal.",
        duration: 3000,
      });
      navigate("/login");
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-vyom-light to-white">
      {/* Top Navigation */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-teal flex items-center justify-center text-white font-bold text-xl">V</div>
            <span className="text-xl font-bold">Vyom</span>
          </Link>
          
          <div className="flex items-center space-x-4">
            <LanguageToggle />
            <Link to="/" className="text-vyom-blue hover:text-vyom-red transition-colors duration-200 text-sm">
              Back to Home
            </Link>
          </div>
        </div>
      </div>
      
      {/* Signup Form with Tabs */}
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="w-full max-w-md animate-fade-in">
          <Card className="border-none shadow-xl">
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold text-center text-vyom-blue">Create an account</CardTitle>
              <CardDescription className="text-center">
                Choose your account type and enter your details
              </CardDescription>
            </CardHeader>
            
            <Tabs defaultValue="user" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="user">User Account</TabsTrigger>
                <TabsTrigger value="admin">Admin Access</TabsTrigger>
              </TabsList>
              
              {/* User Account Form */}
              <TabsContent value="user">
                <CardContent>
                  <form onSubmit={handleUserSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="fullName" 
                          name="fullName"
                          placeholder="John Doe" 
                          className="pl-10 form-input" 
                          value={userFormData.fullName}
                          onChange={handleUserFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="email" 
                          name="email"
                          type="email" 
                          placeholder="name@example.com" 
                          className="pl-10 form-input" 
                          value={userFormData.email}
                          onChange={handleUserFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    {/* KYC Details */}
                    <div className="space-y-2">
                      <Label htmlFor="kycType">KYC Document Type</Label>
                      <Select 
                        value={userFormData.kycType}
                        onValueChange={(value) => setUserFormData(prev => ({...prev, kycType: value}))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select ID type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="aadhaar">Aadhaar Card</SelectItem>
                          <SelectItem value="pan">PAN Card</SelectItem>
                          <SelectItem value="passport">Passport</SelectItem>
                          <SelectItem value="drivingLicense">Driving License</SelectItem>
                          <SelectItem value="voterID">Voter ID</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="kycNumber">KYC Document Number</Label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="kycNumber" 
                          name="kycNumber"
                          placeholder="Enter your document number" 
                          className="pl-10 form-input" 
                          value={userFormData.kycNumber}
                          onChange={handleUserFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    {/* Occupation */}
                    <div className="space-y-2">
                      <Label htmlFor="occupation">Occupation</Label>
                      <div className="relative">
                        <Briefcase className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="occupation" 
                          name="occupation"
                          placeholder="e.g. Software Engineer" 
                          className="pl-10 form-input" 
                          value={userFormData.occupation}
                          onChange={handleUserFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    {/* Annual Income */}
                    <div className="space-y-2">
                      <Label htmlFor="annualIncome">Annual Income (₹)</Label>
                      <Select 
                        value={userFormData.annualIncome}
                        onValueChange={(value) => setUserFormData(prev => ({...prev, annualIncome: value}))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select income range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="below5lakh">Below ₹5 Lakhs</SelectItem>
                          <SelectItem value="5to10lakh">₹5 Lakhs - ₹10 Lakhs</SelectItem>
                          <SelectItem value="10to20lakh">₹10 Lakhs - ₹20 Lakhs</SelectItem>
                          <SelectItem value="above20lakh">Above ₹20 Lakhs</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Gender */}
                    <div className="space-y-2">
                      <Label>Gender</Label>
                      <RadioGroup 
                        value={userFormData.gender}
                        onValueChange={(value) => setUserFormData(prev => ({...prev, gender: value}))}
                        className="flex space-x-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="male" id="male" />
                          <Label htmlFor="male" className="cursor-pointer">Male</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="female" id="female" />
                          <Label htmlFor="female" className="cursor-pointer">Female</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="other" id="other" />
                          <Label htmlFor="other" className="cursor-pointer">Other</Label>
                        </div>
                      </RadioGroup>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="password" 
                          name="password"
                          type={showPassword ? "text" : "password"} 
                          className="pl-10 pr-10 form-input" 
                          value={userFormData.password}
                          onChange={handleUserFormChange}
                          required
                        />
                        <button 
                          type="button" 
                          onClick={toggleShowPassword}
                          className="absolute right-3 top-3 text-vyom-gray hover:text-vyom-blue transition-colors"
                        >
                          {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                      
                      {/* Password strength indicator */}
                      {userFormData.password && (
                        <div className="mt-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <div className="text-xs">Password Strength</div>
                            <div className={`text-xs font-medium ${
                              userPasswordStrength.strength <= 2 ? "text-red-500" : 
                              userPasswordStrength.strength <= 4 ? "text-yellow-500" : 
                              "text-green-500"
                            }`}>
                              {getPasswordStrengthLabel(userPasswordStrength.strength, userFormData.password)}
                            </div>
                          </div>
                          <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${getPasswordStrengthColor(userPasswordStrength.strength, userFormData.password)} transition-all duration-300`} 
                              style={{ width: `${(userPasswordStrength.strength / 5) * 100}%` }}
                            ></div>
                          </div>
                          
                          <ul className="space-y-1 mt-2">
                            <li className="flex items-center gap-2 text-xs">
                              {userPasswordStrength.hasMinLength ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={userPasswordStrength.hasMinLength ? "text-green-500" : "text-vyom-gray"}>
                                At least 8 characters
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {userPasswordStrength.hasUpperCase && userPasswordStrength.hasLowerCase ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={userPasswordStrength.hasUpperCase && userPasswordStrength.hasLowerCase ? "text-green-500" : "text-vyom-gray"}>
                                Upper and lowercase letters
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {userPasswordStrength.hasNumber ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={userPasswordStrength.hasNumber ? "text-green-500" : "text-vyom-gray"}>
                                At least one number
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {userPasswordStrength.hasSpecialChar ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={userPasswordStrength.hasSpecialChar ? "text-green-500" : "text-vyom-gray"}>
                                At least one special character
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="confirmPassword" 
                          name="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"} 
                          className="pl-10 pr-10 form-input" 
                          value={userFormData.confirmPassword}
                          onChange={handleUserFormChange}
                          required
                        />
                        <button 
                          type="button" 
                          onClick={toggleShowConfirmPassword}
                          className="absolute right-3 top-3 text-vyom-gray hover:text-vyom-blue transition-colors"
                        >
                          {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                      {userFormData.password && userFormData.confirmPassword && userFormData.password !== userFormData.confirmPassword && (
                        <p className="text-xs text-red-500 mt-1">Passwords don't match</p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="terms" 
                        checked={agreedToTerms}
                        onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
                      />
                      <label
                        htmlFor="terms"
                        className="text-sm text-vyom-gray leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        I agree to the{" "}
                        <Link to="/terms-of-service" className="text-vyom-blue hover:underline">
                          terms of service
                        </Link>{" "}
                        and{" "}
                        <Link to="/privacy-policy" className="text-vyom-blue hover:underline">
                          privacy policy
                        </Link>
                      </label>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-vyom-red hover:bg-vyom-red/90 text-white mt-6"
                      disabled={isLoading}
                    >
                      {isLoading ? "Creating account..." : "Create User Account"}
                    </Button>
                    
                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-gray-300"></span>
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-white px-2 text-vyom-gray">Or continue with</span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <Button variant="outline" className="border-gray-300 hover:bg-vyom-light">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-5 w-5 mr-2">
                          <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
                          <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
                          <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
                          <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
                        </svg>
                        Google
                      </Button>
                      <Button variant="outline" className="border-gray-300 hover:bg-vyom-light">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="h-5 w-5 mr-2">
                          <path d="M22,12c0-5.52-4.48-10-10-10S2,6.48,2,12c0,4.84,3.44,8.87,8,9.8V15H8v-3h2V9.5C10,7.57,11.57,6,13.5,6H16v3h-2 c-0.55,0-1,0.45-1,1v2h3v3h-3v6.95C18.05,21.45,22,17.19,22,12z" />
                        </svg>
                        Facebook
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </TabsContent>
              
              {/* Admin Account Form */}
              <TabsContent value="admin">
                <CardContent>
                  <form onSubmit={handleAdminSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="adminFullName">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="adminFullName" 
                          name="fullName"
                          placeholder="John Doe" 
                          className="pl-10 form-input" 
                          value={adminFormData.fullName}
                          onChange={handleAdminFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="adminEmail">Work Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="adminEmail" 
                          name="email"
                          type="email" 
                          placeholder="name@unionbankofindia.com" 
                          className="pl-10 form-input" 
                          value={adminFormData.email}
                          onChange={handleAdminFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    {/* Employee ID */}
                    <div className="space-y-2">
                      <Label htmlFor="employeeId">Employee ID</Label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="employeeId" 
                          name="employeeId"
                          placeholder="UBI-XXXXX" 
                          className="pl-10 form-input" 
                          value={adminFormData.employeeId}
                          onChange={handleAdminFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    {/* Department */}
                    <div className="space-y-2">
                      <Label htmlFor="department">Department</Label>
                      <Select 
                        value={adminFormData.department}
                        onValueChange={(value) => setAdminFormData(prev => ({...prev, department: value}))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="digital-banking">Digital Banking</SelectItem>
                          <SelectItem value="customer-service">Customer Service</SelectItem>
                          <SelectItem value="credit">Credit & Loans</SelectItem>
                          <SelectItem value="operations">Operations</SelectItem>
                          <SelectItem value="technology">Information Technology</SelectItem>
                          <SelectItem value="hr">Human Resources</SelectItem>
                          <SelectItem value="finance">Finance</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Access Level */}
                    <div className="space-y-2">
                      <Label htmlFor="accessLevel">System Access Level</Label>
                      <Select 
                        value={adminFormData.accessLevel}
                        onValueChange={(value) => setAdminFormData(prev => ({...prev, accessLevel: value}))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select access level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="standard">Standard (View Only)</SelectItem>
                          <SelectItem value="advanced">Advanced (View & Edit)</SelectItem>
                          <SelectItem value="supervisor">Supervisor (All Access)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    {/* Contact Number */}
                    <div className="space-y-2">
                      <Label htmlFor="contactNumber">Contact Number</Label>
                      <div className="relative">
                        <Users className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="contactNumber" 
                          name="contactNumber"
                          placeholder="+91 XXXXX XXXXX" 
                          className="pl-10 form-input" 
                          value={adminFormData.contactNumber}
                          onChange={handleAdminFormChange}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="adminPassword">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="adminPassword" 
                          name="password"
                          type={showPassword ? "text" : "password"} 
                          className="pl-10 pr-10 form-input" 
                          value={adminFormData.password}
                          onChange={handleAdminFormChange}
                          required
                        />
                        <button 
                          type="button" 
                          onClick={toggleShowPassword}
                          className="absolute right-3 top-3 text-vyom-gray hover:text-vyom-blue transition-colors"
                        >
                          {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                      
                      {/* Password strength indicator */}
                      {adminFormData.password && (
                        <div className="mt-2 space-y-2">
                          <div className="flex justify-between items-center">
                            <div className="text-xs">Password Strength</div>
                            <div className={`text-xs font-medium ${
                              adminPasswordStrength.strength <= 2 ? "text-red-500" : 
                              adminPasswordStrength.strength <= 4 ? "text-yellow-500" : 
                              "text-green-500"
                            }`}>
                              {getPasswordStrengthLabel(adminPasswordStrength.strength, adminFormData.password)}
                            </div>
                          </div>
                          <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${getPasswordStrengthColor(adminPasswordStrength.strength, adminFormData.password)} transition-all duration-300`} 
                              style={{ width: `${(adminPasswordStrength.strength / 5) * 100}%` }}
                            ></div>
                          </div>
                          
                          <ul className="space-y-1 mt-2">
                            <li className="flex items-center gap-2 text-xs">
                              {adminPasswordStrength.hasMinLength ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={adminPasswordStrength.hasMinLength ? "text-green-500" : "text-vyom-gray"}>
                                At least 8 characters
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {adminPasswordStrength.hasUpperCase && adminPasswordStrength.hasLowerCase ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={adminPasswordStrength.hasUpperCase && adminPasswordStrength.hasLowerCase ? "text-green-500" : "text-vyom-gray"}>
                                Upper and lowercase letters
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {adminPasswordStrength.hasNumber ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={adminPasswordStrength.hasNumber ? "text-green-500" : "text-vyom-gray"}>
                                At least one number
                              </span>
                            </li>
                            <li className="flex items-center gap-2 text-xs">
                              {adminPasswordStrength.hasSpecialChar ? 
                                <Check size={14} className="text-green-500" /> : 
                                <AlertCircle size={14} className="text-vyom-gray" />
                              }
                              <span className={adminPasswordStrength.hasSpecialChar ? "text-green-500" : "text-vyom-gray"}>
                                At least one special character
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="adminConfirmPassword">Confirm Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-5 w-5 text-vyom-gray" />
                        <Input 
                          id="adminConfirmPassword" 
                          name="confirmPassword"
                          type={showConfirmPassword ? "text" : "password"} 
                          className="pl-10 pr-10 form-input" 
                          value={adminFormData.confirmPassword}
                          onChange={handleAdminFormChange}
                          required
                        />
                        <button 
                          type="button" 
                          onClick={toggleShowConfirmPassword}
                          className="absolute right-3 top-3 text-vyom-gray hover:text-vyom-blue transition-colors"
                        >
                          {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                      </div>
                      {adminFormData.password && adminFormData.confirmPassword && adminFormData.password !== adminFormData.confirmPassword && (
                        <p className="text-xs text-red-500 mt-1">Passwords don't match</p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="adminTerms" 
                        checked={agreedToTerms}
                        onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
                      />
                      <label
                        htmlFor="adminTerms"
                        className="text-sm text-vyom-gray leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        I agree to the{" "}
                        <Link to="/terms-of-service" className="text-vyom-blue hover:underline">
                          terms of service
                        </Link>{" "}
                        and{" "}
                        <Link to="/privacy-policy" className="text-vyom-blue hover:underline">
                          privacy policy
                        </Link>
                      </label>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-vyom-blue hover:bg-vyom-blue/90 text-white mt-6"
                      disabled={isLoading}
                    >
                      {isLoading ? "Creating account..." : "Create Admin Account"}
                    </Button>
                  </form>
                </CardContent>
              </TabsContent>
              
            </Tabs>
            
            <CardFooter className="flex justify-center">
              <p className="text-sm text-vyom-gray">
                Already have an account?{" "}
                <Link to="/login" className="text-vyom-blue hover:underline font-medium">
                  Sign in
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
      
      {/* Footer */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-vyom-gray">
          <div className="mb-4 md:mb-0">
            © {new Date().getFullYear()} Vyom by Union Bank of India. All rights reserved.
          </div>
          <div className="flex space-x-6">
            <Link to="/privacy-policy" className="hover:text-vyom-blue transition-colors duration-200">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-vyom-blue transition-colors duration-200">Terms of Service</Link>
            <Link to="/contact" className="hover:text-vyom-blue transition-colors duration-200">Contact Support</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
