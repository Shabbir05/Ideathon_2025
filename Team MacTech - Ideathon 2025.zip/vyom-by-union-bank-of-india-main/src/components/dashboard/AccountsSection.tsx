
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Eye } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { 
  ArrowRightLeft, 
  CreditCard,
  AlertCircle,
  Send,
  Receipt,
  Briefcase,
  LineChart,
  Clock
} from "lucide-react";

// Account and transaction types
export interface Transaction {
  id: number;
  type: string;
  description: string;
  amount: number;
  date: string;
  category?: string;
}

export interface Account {
  id: number;
  type: string;
  number: string;
  balance: number;
  interestRate: string;
  lastTransaction: string;
  lastTransactionDate: string;
  status: string;
  branch: string | null;
  openDate: string;
  availableCredit: number | null;
  creditLimit?: number;
  dueDate?: string;
  minimumDue?: number;
  maturityDate?: string;
  transactions: Transaction[];
}

interface AccountsSectionProps {
  accounts: Account[];
  onAccountAction: (accountId: number, action: string) => void;
}

export const AccountsSection = ({ accounts, onAccountAction }: AccountsSectionProps) => {
  const [selectedAccount, setSelectedAccount] = useState<number | null>(null);
  const [showAccountDetails, setShowAccountDetails] = useState(false);

  const handleViewAccountDetails = (accountId: number) => {
    const account = accounts.find(acc => acc.id === accountId);
    if (account) {
      setSelectedAccount(accountId);
      setShowAccountDetails(true);
      
      toast({
        title: "Account Details",
        description: `Viewing details for ${account.type}`,
      });
    }
  };

  const renderTransactionIcon = (type: string, category?: string) => {
    if (type === "credit") {
      return <ArrowRightLeft size={14} className="text-vyom-green" />;
    } else {
      switch(category) {
        case "Shopping":
          return <CreditCard size={14} className="text-vyom-red" />;
        case "Utilities":
          return <AlertCircle size={14} className="text-vyom-red" />;
        case "Transport":
          return <Send size={14} className="text-vyom-red" />;
        case "Dining":
          return <Receipt size={14} className="text-vyom-red" />;
        case "Business":
          return <Briefcase size={14} className="text-vyom-red" />;
        case "Entertainment":
          return <LineChart size={14} className="text-vyom-red" />;
        default:
          return <Clock size={14} className="text-vyom-red" />;
      }
    }
  };

  return (
    <>
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-vyom-blue">My Accounts</h2>
          <Button 
            onClick={() => {
              toast({
                title: "Open New Account",
                description: "Taking you to account opening form...",
              });
            }}
            className="bg-gradient-to-r from-vyom-blue to-vyom-teal text-white hover:shadow-lg transition-all duration-300"
          >
            Open New Account
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {accounts.map(account => (
            <Card 
              key={account.id} 
              className={`overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 ${
                selectedAccount === account.id ? "ring-2 ring-vyom-blue/50" : ""
              }`}
            >
              <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-teal" />
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <CardTitle className="text-lg flex items-center">
                    {account.type}
                    <Badge 
                      variant="outline" 
                      className="ml-2 text-xs bg-green-50 text-green-600 hover:bg-green-50"
                    >
                      {account.status}
                    </Badge>
                  </CardTitle>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8" 
                    onClick={() => handleViewAccountDetails(account.id)}
                  >
                    <Eye size={16} />
                  </Button>
                </div>
                <CardDescription className="flex items-center gap-2">
                  <span>{account.number}</span>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-vyom-gray">Balance</p>
                      <p className="text-2xl font-semibold gradient-text">
                        <span>₹{account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                      </p>
                    </div>
                    
                    {account.type === "Credit Card" && (
                      <div className="text-right">
                        <p className="text-sm text-vyom-gray">Available Credit</p>
                        <p className="text-lg font-medium">
                          <span>₹{account.availableCredit?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                        </p>
                      </div>
                    )}
                  </div>
                  
                  {account.type === "Credit Card" && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-vyom-gray">Credit Utilization</span>
                        <span className="text-sm font-medium">{Math.round((account.balance / -account.creditLimit!) * 100)}%</span>
                      </div>
                      <Progress 
                        value={Math.round((account.balance / -account.creditLimit!) * 100)} 
                        className="h-2"
                      />
                      <div className="flex justify-between text-xs text-vyom-gray">
                        <span>Due: ₹{account.minimumDue?.toLocaleString('en-IN')}</span>
                        <span>Date: {account.dueDate}</span>
                      </div>
                    </div>
                  )}
                  
                  {account.type === "Fixed Deposit" && (
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Interest Rate</span>
                        <span className="text-sm font-medium text-vyom-teal">{account.interestRate}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Maturity Date</span>
                        <span className="text-sm font-medium">{account.maturityDate}</span>
                      </div>
                    </div>
                  )}
                  
                  {(account.type === "Savings Account" || account.type === "Current Account") && (
                    <div className="space-y-1">
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Interest Rate</span>
                        <span className="text-sm font-medium text-vyom-teal">{account.interestRate}</span>
                      </div>
                    </div>
                  )}
                  
                  <div className="border-t pt-3">
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-vyom-gray">Last Transaction</span>
                      <span className="text-xs text-vyom-gray">{account.lastTransactionDate}</span>
                    </div>
                    <p className="text-sm">{account.lastTransaction}</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-xs"
                      onClick={() => onAccountAction(account.id, "details")}
                    >
                      View Details
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-xs"
                      onClick={() => onAccountAction(account.id, "transfer")}
                    >
                      {account.type === "Credit Card" ? "Pay Bill" : "Transfer"}
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="text-xs"
                      onClick={() => onAccountAction(account.id, "statement")}
                    >
                      Statement
                    </Button>
                    
                    {account.type === "Credit Card" && (
                      <Button 
                        variant="default" 
                        size="sm" 
                        className="text-xs ml-auto"
                        onClick={() => onAccountAction(account.id, "payDue")}
                      >
                        Pay Due Now
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      {selectedAccount && showAccountDetails && (
        <Card className="mt-8 shadow-lg overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-purple" />
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Account Details</CardTitle>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setShowAccountDetails(false)}
              >
                Close
              </Button>
            </div>
            <CardDescription>
              {accounts.find(acc => acc.id === selectedAccount)?.type} - {accounts.find(acc => acc.id === selectedAccount)?.number}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm text-vyom-gray mb-1">Account Information</h3>
                    <div className="space-y-2 rounded-lg border p-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Type</span>
                        <span className="text-sm font-medium">{accounts.find(acc => acc.id === selectedAccount)?.type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Number</span>
                        <span className="text-sm font-medium">{accounts.find(acc => acc.id === selectedAccount)?.number}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Status</span>
                        <Badge variant="outline" className="text-xs bg-green-50 text-green-600 hover:bg-green-50">
                          {accounts.find(acc => acc.id === selectedAccount)?.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Opened On</span>
                        <span className="text-sm font-medium">{accounts.find(acc => acc.id === selectedAccount)?.openDate}</span>
                      </div>
                      {accounts.find(acc => acc.id === selectedAccount)?.branch && (
                        <div className="flex justify-between">
                          <span className="text-sm text-vyom-gray">Branch</span>
                          <span className="text-sm font-medium">{accounts.find(acc => acc.id === selectedAccount)?.branch}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm text-vyom-gray mb-1">Balance Information</h3>
                    <div className="space-y-2 rounded-lg border p-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Current Balance</span>
                        <span className="text-sm font-medium">₹{accounts.find(acc => acc.id === selectedAccount)?.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-vyom-gray">Interest Rate</span>
                        <span className="text-sm font-medium text-vyom-teal">{accounts.find(acc => acc.id === selectedAccount)?.interestRate}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm text-vyom-gray mb-1">Recent Transactions</h3>
                    <ScrollArea className="h-[250px] rounded-lg border p-4">
                      <div className="space-y-3">
                        {accounts.find(acc => acc.id === selectedAccount)?.transactions.map(transaction => (
                          <div key={transaction.id} className="flex items-start justify-between pb-2 border-b border-gray-100">
                            <div className="flex gap-2">
                              <div className="mt-0.5">
                                {renderTransactionIcon(transaction.type, transaction.category)}
                              </div>
                              <div>
                                <p className="text-sm font-medium">{transaction.description}</p>
                                <p className="text-xs text-vyom-gray">{transaction.date}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              {transaction.type === "credit" ? (
                                <p className="text-sm font-medium text-vyom-green">+₹{transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</p>
                              ) : (
                                <p className="text-sm font-medium text-vyom-red">-₹{transaction.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</p>
                              )}
                              <p className="text-xs text-vyom-gray">{transaction.category}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
};
