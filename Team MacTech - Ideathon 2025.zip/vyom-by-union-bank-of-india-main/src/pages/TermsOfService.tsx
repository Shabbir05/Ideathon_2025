
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import Footer from "@/components/Footer";

const TermsOfService = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-vyom-light to-white">
      {/* Top Navigation */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <Link 
            to="/" 
            className="flex items-center space-x-2 text-vyom-blue transition-transform duration-300 hover:scale-105"
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-vyom-blue to-vyom-red flex items-center justify-center text-white font-bold text-xl">V</div>
            <span className="text-xl font-bold">Vyom</span>
          </Link>
          
          <Link to="/" className="flex items-center text-vyom-blue hover:text-vyom-red transition-colors duration-200">
            <ArrowLeft size={16} className="mr-2" />
            Back to Home
          </Link>
        </div>
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 py-12 flex-grow">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold mb-8 text-vyom-blue">Terms of Service</h1>
          
          <div className="prose prose-blue max-w-none">
            <p className="text-vyom-gray mb-6">Last Updated: {new Date().toLocaleDateString()}</p>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Agreement to Terms</h2>
              <p className="mb-4">
                These Terms of Service ("Terms") constitute a legally binding agreement made between you, whether personally or on behalf of an entity ("you") and Vyom by Union Bank of India ("we," "us" or "our"), concerning your access to and use of our digital banking platform.
              </p>
              <p>
                By accessing or using our platform, you agree to be bound by these Terms. If you disagree with any part of the Terms, you may not access our platform.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Eligibility</h2>
              <p className="mb-4">
                Our platform is intended for users who are at least 18 years of age and are residents of India. By using our platform, you represent and warrant that you meet these requirements.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">User Accounts</h2>
              <p className="mb-4">
                When you create an account with us, you must provide accurate, complete, and up-to-date information. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account.
              </p>
              <p className="mb-4">
                You are responsible for maintaining the confidentiality of your account and password and for restricting access to your device. You agree to accept responsibility for all activities that occur under your account or password.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Services and Transactions</h2>
              <p className="mb-4">
                Our platform provides various banking services, including but not limited to account management, funds transfer, bill payment, and investment services. All transactions conducted through our platform are subject to verification and processing according to our policies and procedures.
              </p>
              <p className="mb-4">
                We reserve the right to refuse service, terminate accounts, or cancel transactions at our sole discretion, particularly in cases of suspected fraudulent activity or violations of these Terms.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Intellectual Property</h2>
              <p className="mb-4">
                The platform and its original content, features, and functionality are and will remain the exclusive property of Vyom by Union Bank of India and its licensors. The platform is protected by copyright, trademark, and other laws of India and foreign countries.
              </p>
              <p className="mb-4">
                Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of Vyom by Union Bank of India.
              </p>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Limitation of Liability</h2>
              <p className="mb-4">
                In no event shall Vyom by Union Bank of India, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
              </p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Your access to or use of or inability to access or use the platform</li>
                <li>Any conduct or content of any third party on the platform</li>
                <li>Unauthorized access, use, or alteration of your transmissions or content</li>
              </ul>
            </section>
            
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Changes to Terms</h2>
              <p>
                We reserve the right to modify or replace these Terms at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
              </p>
            </section>
            
            <section>
              <h2 className="text-2xl font-semibold mb-4 text-vyom-blue">Contact Us</h2>
              <p>
                If you have any questions about these Terms, please contact us at legal@vyombank.in or write to us at Union Bank Headquarters, Mumbai, Maharashtra, India.
              </p>
            </section>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default TermsOfService;
