
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FeatureCard from "@/components/FeatureCard";
import { 
  ShieldCheck, 
  Smartphone, 
  CreditCard, 
  LineChart, 
  Globe, 
  Lock,
  Zap,
  PieChart,
  Building,
  Award
} from "lucide-react";
import { Button } from "@/components/ui/button";

const Index = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-32 md:pt-40 pb-20 md:pb-32 px-4 bg-gradient-to-b from-white to-vyom-light">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className={`space-y-6 ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="inline-block px-3 py-1 bg-vyom-teal/10 text-vyom-teal rounded-full text-sm font-medium mb-2">
                AI-Powered Banking
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-vyom-blue leading-tight">
                Experience Next-Gen <span className="text-vyom-teal">Digital Banking</span>
              </h1>
              <p className="text-lg text-vyom-gray leading-relaxed">
                Vyom combines AI-powered security, personalized services, and global 
                banking capabilities to provide a seamless financial experience.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link to="/signup">
                  <Button className="btn-primary w-full sm:w-auto">Get Started</Button>
                </Link>
                <Link to="/login">
                  <Button variant="outline" className="btn-secondary w-full sm:w-auto">
                    Login to Vyom
                  </Button>
                </Link>
              </div>
              
              <div className="flex items-center gap-4 pt-6">
                <div className="flex">
                  <div className="w-8 h-8 rounded-full border-2 border-white overflow-hidden">
                    <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="User" className="w-full h-full object-cover" />
                  </div>
                  <div className="w-8 h-8 rounded-full border-2 border-white overflow-hidden -ml-2">
                    <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="User" className="w-full h-full object-cover" />
                  </div>
                  <div className="w-8 h-8 rounded-full border-2 border-white overflow-hidden -ml-2">
                    <img src="https://randomuser.me/api/portraits/men/86.jpg" alt="User" className="w-full h-full object-cover" />
                  </div>
                </div>
                <div className="text-sm text-vyom-gray">
                  <span className="font-semibold">10,000+</span> customers trust Vyom
                </div>
              </div>
            </div>
            
            <div className={`relative flex justify-center ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <div className="relative w-full max-w-lg">
                {/* Card background with glow effect */}
                <div className="absolute -inset-0.5 bg-gradient-to-r from-vyom-blue to-vyom-teal rounded-2xl blur opacity-20 animate-pulse-gentle"></div>
                
                {/* Main card */}
                <div className="relative bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
                  {/* Card header */}
                  <div className="h-2 bg-gradient-to-r from-vyom-blue to-vyom-teal"></div>
                  
                  {/* Card content */}
                  <div className="p-8">
                    <div className="flex justify-between items-center mb-8">
                      <div>
                        <h3 className="text-sm text-vyom-gray font-medium">Available Balance</h3>
                        <div className="flex items-baseline">
                          <span className="text-3xl font-bold text-vyom-blue">₹</span>
                          <span className="text-4xl font-bold text-vyom-blue">157,892</span>
                          <span className="text-xl font-semibold text-vyom-blue">.45</span>
                        </div>
                      </div>
                      <div className="w-14 h-14 rounded-full bg-gradient-to-br from-vyom-blue to-vyom-teal flex items-center justify-center text-white text-lg font-bold">
                        V
                      </div>
                    </div>
                    
                    {/* Card details */}
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-vyom-gray">Account Number</span>
                        <span className="text-sm font-medium">XXXX XXXX XXXX 4523</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-vyom-gray">Account Type</span>
                        <span className="text-sm font-medium">Savings Account</span>
                      </div>
                    </div>
                    
                    {/* Card actions */}
                    <div className="mt-8 grid grid-cols-2 gap-4">
                      <button className="flex items-center justify-center gap-2 py-3 rounded-lg bg-vyom-teal text-white hover:bg-vyom-accent transition-all duration-200 text-sm font-medium">
                        <CreditCard size={16} />
                        <span>Transfer</span>
                      </button>
                      <button className="flex items-center justify-center gap-2 py-3 rounded-lg bg-vyom-light text-vyom-blue hover:bg-gray-200 transition-all duration-200 text-sm font-medium">
                        <LineChart size={16} />
                        <span>Analytics</span>
                      </button>
                    </div>
                    
                    {/* Financial insights */}
                    <div className="mt-6 pt-6 border-t border-gray-100">
                      <h4 className="text-sm font-medium mb-4 flex items-center">
                        <Zap size={16} className="text-vyom-teal mr-2" />
                        Financial Insights
                      </h4>
                      <div className="bg-vyom-light rounded-lg p-4">
                        <p className="text-xs text-vyom-gray leading-relaxed">
                          Your spending is 12% lower than last month. Great job maintaining your budget!
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Floating card elements */}
                <div className="absolute -top-6 -right-6 bg-white rounded-xl p-3 shadow-lg animate-float" style={{ animationDelay: '0.5s' }}>
                  <ShieldCheck className="text-vyom-teal h-8 w-8" />
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-xl p-3 shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                  <Globe className="text-vyom-blue h-8 w-8" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title">Empowered Banking Features</h2>
            <p className="text-vyom-gray">
              Vyom combines cutting-edge technology with personalized banking services to provide 
              a seamless and secure financial experience.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <FeatureCard 
                icon={<ShieldCheck size={28} />}
                title="AI-Powered Security"
                description="Advanced fraud detection and risk assessment powered by artificial intelligence to keep your finances secure."
              />
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
              <FeatureCard 
                icon={<Smartphone size={28} />}
                title="Seamless Mobile Banking"
                description="Access your accounts, make transactions, and manage your finances from anywhere with our intuitive mobile app."
                color="from-vyom-teal to-vyom-accent"
              />
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <FeatureCard 
                icon={<CreditCard size={28} />}
                title="Smart Payment Solutions"
                description="Make secure transactions with UPI, RTGS, NEFT, IMPS, and international transfers with competitive rates."
              />
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.5s' }}>
              <FeatureCard 
                icon={<LineChart size={28} />}
                title="Financial Insights"
                description="Get personalized financial analytics and insights to help you make informed decisions about your money."
                color="from-vyom-teal to-vyom-accent"
              />
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
              <FeatureCard 
                icon={<Globe size={28} />}
                title="Global Banking"
                description="Access your finances globally with multi-currency support and international transaction capabilities."
              />
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.7s' }}>
              <FeatureCard 
                icon={<Lock size={28} />}
                title="Secure KYC Process"
                description="Complete your verification process securely with our encrypted document upload and verification system."
                color="from-vyom-teal to-vyom-accent"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Services Section */}
      <section className="py-20 px-4 bg-vyom-light">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className={`order-2 lg:order-1 ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="relative">
                {/* Main image */}
                <div className="rounded-2xl overflow-hidden shadow-xl">
                  <img 
                    src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                    alt="Financial services" 
                    className="w-full h-auto object-cover"
                  />
                </div>
                
                {/* Floating card 1 */}
                <div className="absolute -top-8 -left-8 bg-white rounded-xl p-4 shadow-lg max-w-[200px] animate-float">
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-vyom-teal/20 flex items-center justify-center">
                      <PieChart size={20} className="text-vyom-teal" />
                    </div>
                    <h4 className="font-semibold text-vyom-blue">Investments</h4>
                  </div>
                  <p className="text-xs text-vyom-gray">Grow your wealth with our diverse investment options.</p>
                </div>
                
                {/* Floating card 2 */}
                <div className="absolute -bottom-8 -right-8 bg-white rounded-xl p-4 shadow-lg max-w-[200px] animate-float" style={{ animationDelay: '0.7s' }}>
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-vyom-blue/20 flex items-center justify-center">
                      <Building size={20} className="text-vyom-blue" />
                    </div>
                    <h4 className="font-semibold text-vyom-blue">Loans</h4>
                  </div>
                  <p className="text-xs text-vyom-gray">Get quick and hassle-free loans for all your needs.</p>
                </div>
              </div>
            </div>
            
            <div className={`order-1 lg:order-2 ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <h2 className="section-title">Comprehensive Financial Services</h2>
              <p className="text-vyom-gray mb-8">
                From personal banking to investments, loans, and insurance - Vyom offers a complete 
                suite of financial services to meet all your needs.
              </p>
              
              <div className="space-y-6">
                <div className="flex space-x-4">
                  <div className="w-12 h-12 rounded-full bg-vyom-teal/20 flex items-center justify-center shrink-0">
                    <CreditCard size={24} className="text-vyom-teal" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-vyom-blue text-lg mb-1">Personal & Business Banking</h3>
                    <p className="text-vyom-gray text-sm">
                      Manage your personal and business finances with savings accounts, current accounts, 
                      and merchant services tailored to your needs.
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <div className="w-12 h-12 rounded-full bg-vyom-blue/20 flex items-center justify-center shrink-0">
                    <LineChart size={24} className="text-vyom-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-vyom-blue text-lg mb-1">Investments & Wealth Management</h3>
                    <p className="text-vyom-gray text-sm">
                      Grow your wealth with our range of investment options including mutual funds, 
                      fixed deposits, and personalized wealth management services.
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <div className="w-12 h-12 rounded-full bg-vyom-teal/20 flex items-center justify-center shrink-0">
                    <Building size={24} className="text-vyom-teal" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-vyom-blue text-lg mb-1">Loans & Credit Solutions</h3>
                    <p className="text-vyom-gray text-sm">
                      Access personal, home, education, and business loans with competitive interest 
                      rates and flexible repayment options.
                    </p>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <div className="w-12 h-12 rounded-full bg-vyom-blue/20 flex items-center justify-center shrink-0">
                    <ShieldCheck size={24} className="text-vyom-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-vyom-blue text-lg mb-1">Insurance & Protection</h3>
                    <p className="text-vyom-gray text-sm">
                      Secure your future with our comprehensive insurance solutions covering life, 
                      health, and vehicle protection.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-10">
                <Link to="/signup">
                  <Button className="btn-primary">Explore Services</Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="section-title">What Our Customers Say</h2>
            <p className="text-vyom-gray">
              Join thousands of satisfied customers who have transformed their banking experience with Vyom.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="glass-card p-6 rounded-xl h-full flex flex-col">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/men/32.jpg" 
                      alt="Testimonial" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vyom-blue">Rajesh Sharma</h4>
                    <p className="text-xs text-vyom-gray">Business Owner</p>
                  </div>
                </div>
                
                <p className="text-vyom-gray text-sm flex-grow">
                  "The AI-powered insights have transformed how I manage my business finances. 
                  Vyom's platform is intuitive, secure, and has saved me countless hours on financial management."
                </p>
                
                <div className="flex items-center mt-4 text-vyom-gold">
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                </div>
              </div>
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
              <div className="glass-card p-6 rounded-xl h-full flex flex-col">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/women/44.jpg" 
                      alt="Testimonial" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vyom-blue">Priya Patel</h4>
                    <p className="text-xs text-vyom-gray">IT Professional</p>
                  </div>
                </div>
                
                <p className="text-vyom-gray text-sm flex-grow">
                  "The multi-language support makes banking so accessible for my entire family. 
                  The security features give me peace of mind, and the mobile app is incredibly user-friendly."
                </p>
                
                <div className="flex items-center mt-4 text-vyom-gold">
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                </div>
              </div>
            </div>
            
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <div className="glass-card p-6 rounded-xl h-full flex flex-col">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden">
                    <img 
                      src="https://randomuser.me/api/portraits/men/86.jpg" 
                      alt="Testimonial" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-semibold text-vyom-blue">Vikram Singh</h4>
                    <p className="text-xs text-vyom-gray">Real Estate Developer</p>
                  </div>
                </div>
                
                <p className="text-vyom-gray text-sm flex-grow">
                  "The loan application process was the smoothest I've experienced. From application to 
                  approval, everything was digital, transparent, and quick. Vyom has set a new standard for banking."
                </p>
                
                <div className="flex items-center mt-4 text-vyom-gold">
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                  <Award size={16} className="fill-current" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-vyom-blue to-vyom-navy text-white">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Banking Experience?</h2>
            <p className="text-white/80 mb-10 text-lg">
              Join thousands of customers who have already upgraded to the future of banking with Vyom.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/signup">
                <Button className="bg-white text-vyom-blue hover:bg-gray-100 px-8 py-6 rounded-lg text-lg font-medium transition-all duration-300 shadow-lg hover:shadow-xl w-full sm:w-auto">
                  Get Started Now
                </Button>
              </Link>
              <Link to="/contact">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-6 rounded-lg text-lg font-medium transition-all duration-300 w-full sm:w-auto">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Index;
