
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, BellRing, AlertCircle, Map, Shield, Users, Clock, CheckCircle,
  Download
} from "lucide-react";
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, Cell 
} from "recharts";
import { toast } from "@/hooks/use-toast";
import { fraudWeeklyData, fraudMonthlyData, riskHeatmapData } from "@/data/adminDashboardData";

interface AdminOverviewProps {
  systemStatus: string;
  toggleSystemStatus: () => void;
}

const AdminOverview = ({ systemStatus, toggleSystemStatus }: AdminOverviewProps) => {
  const [fraudTimeframe, setFraudTimeframe] = useState("weekly");
  
  const handleDownloadReport = (reportType: string) => {
    toast({
      title: "Report Downloaded",
      description: `${reportType} report has been generated and downloaded.`
    });
  };
  
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
              Fraud Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">37</div>
            <div className="text-sm text-vyom-gray mt-1">12 high priority</div>
            <div className="mt-2 flex justify-between items-center">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-200">8 critical</Badge>
              <span className="text-sm text-red-600">+15% from yesterday</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Shield className="w-5 h-5 mr-2 text-green-500" />
              System Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Authentication Service</span>
                <Badge variant="outline" className="bg-green-50 text-green-700">Operational</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Transaction Processing</span>
                <Badge variant="outline" className="bg-green-50 text-green-700">Operational</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>Fraud Detection Engine</span>
                <Badge variant="outline" className="bg-yellow-50 text-yellow-700">Degraded</Badge>
              </div>
              <div className="flex justify-between text-sm">
                <span>API Services</span>
                <Badge variant="outline" className="bg-green-50 text-green-700">Operational</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-500" />
              User Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">12,543</div>
            <div className="text-sm text-vyom-gray mt-1">Active users in last hour</div>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span>Mobile Banking</span>
                <span>64%</span>
              </div>
              <Progress value={64} className="h-1" />
              <div className="flex justify-between items-center text-sm">
                <span>Web Banking</span>
                <span>36%</span>
              </div>
              <Progress value={36} className="h-1" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center">
              <Clock className="w-5 h-5 mr-2 text-purple-500" />
              Real-time Metrics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="text-sm text-vyom-gray">Transactions/minute</div>
                <div className="text-2xl font-bold">1,267</div>
              </div>
              <div>
                <div className="text-sm text-vyom-gray">Avg. Response Time</div>
                <div className="text-2xl font-bold">324ms</div>
              </div>
              <div>
                <div className="text-sm text-vyom-gray">Failed Authentication</div>
                <div className="text-2xl font-bold text-red-600">42</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Live Fraud Detection</CardTitle>
            <CardDescription>Real-time monitoring of suspicious activities</CardDescription>
            <div className="mt-2 flex items-center gap-3">
              <Button 
                size="sm" 
                variant={fraudTimeframe === "weekly" ? "secondary" : "outline"} 
                onClick={() => setFraudTimeframe("weekly")}
                className="h-7"
              >
                Weekly
              </Button>
              <Button 
                size="sm" 
                variant={fraudTimeframe === "monthly" ? "secondary" : "outline"} 
                onClick={() => setFraudTimeframe("monthly")}
                className="h-7"
              >
                Monthly
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-7 ml-auto" 
                onClick={() => handleDownloadReport("Fraud Analysis")}
              >
                <Download className="w-4 h-4 mr-1" /> Report
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                {fraudTimeframe === "weekly" ? (
                  <AreaChart data={fraudWeeklyData}>
                    <defs>
                      <linearGradient id="colorAttempts" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1}/>
                      </linearGradient>
                      <linearGradient id="colorPrevented" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#82ca9d" stopOpacity={0.1}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-background p-3 border rounded-md shadow-md">
                            <p className="text-sm font-medium">{payload[0].payload.name}</p>
                            <p className="text-sm text-muted-foreground">
                              <span className="inline-block w-3 h-3 bg-indigo-400 rounded-full mr-1"></span>
                              Attempts: {payload[0].value}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              <span className="inline-block w-3 h-3 bg-green-400 rounded-full mr-1"></span>
                              Prevented: {payload[1].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }} />
                    <Area type="monotone" dataKey="attempts" stroke="#8884d8" fillOpacity={1} fill="url(#colorAttempts)" />
                    <Area type="monotone" dataKey="prevented" stroke="#82ca9d" fillOpacity={1} fill="url(#colorPrevented)" />
                  </AreaChart>
                ) : (
                  <BarChart data={fraudMonthlyData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-background p-3 border rounded-md shadow-md">
                            <p className="text-sm font-medium">{payload[0].payload.name}</p>
                            <p className="text-sm text-muted-foreground">
                              <span className="inline-block w-3 h-3 bg-indigo-400 rounded-full mr-1"></span>
                              Attempts: {payload[0].value}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              <span className="inline-block w-3 h-3 bg-green-400 rounded-full mr-1"></span>
                              Prevented: {payload[1].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }} />
                    <Legend />
                    <Bar dataKey="attempts" name="Fraud Attempts" fill="#8884d8" />
                    <Bar dataKey="prevented" name="Prevented" fill="#82ca9d" />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Fraud Risk Heatmap</CardTitle>
            <CardDescription>Regional distribution of fraud incidents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] overflow-hidden">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={riskHeatmapData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
                  <XAxis type="number" />
                  <YAxis dataKey="region" type="category" width={80} />
                  <Tooltip content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-background p-3 border rounded-md shadow-md">
                          <p className="text-sm font-medium">{data.region}</p>
                          <p className="text-sm text-muted-foreground">Risk Score: <span className="font-medium">{data.risk}/100</span></p>
                          <p className="text-sm text-muted-foreground">Incidents: <span className="font-medium">{data.incidents}</span></p>
                          <div className="mt-1 flex items-center gap-1">
                            <div className={`w-2 h-2 rounded-full`} style={{ backgroundColor: data.color }}></div>
                            <span className="text-xs">
                              {data.risk > 70 ? 'High Risk' : data.risk > 50 ? 'Medium Risk' : 'Low Risk'}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }} />
                  <Bar dataKey="risk" name="Risk Score">
                    {riskHeatmapData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div className="flex items-center justify-center gap-6 mt-3">
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span className="text-sm">High Risk</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <span className="text-sm">Medium Risk</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-sm">Low Risk</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Live Fraud Detection</CardTitle>
            <CardDescription>Real-time monitoring of suspicious activities</CardDescription>
          </CardHeader>
          <CardContent className="max-h-[400px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Alert Type</TableHead>
                  <TableHead>User ID</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow className="bg-red-50">
                  <TableCell>
                    <div className="flex items-center">
                      <AlertCircle className="w-4 h-4 text-red-600 mr-2" />
                      <span>Multiple Failed Logins</span>
                    </div>
                  </TableCell>
                  <TableCell>ID43567</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Map className="w-4 h-4 mr-1 text-gray-500" />
                      Mumbai, IN
                    </div>
                  </TableCell>
                  <TableCell>Just now</TableCell>
                  <TableCell><Badge className="bg-red-100 text-red-800">High</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" className="h-8">Review</Button>
                  </TableCell>
                </TableRow>
                <TableRow className="bg-orange-50">
                  <TableCell>
                    <div className="flex items-center">
                      <AlertTriangle className="w-4 h-4 text-orange-600 mr-2" />
                      <span>Unusual Transaction</span>
                    </div>
                  </TableCell>
                  <TableCell>ID98234</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Map className="w-4 h-4 mr-1 text-gray-500" />
                      Delhi, IN
                    </div>
                  </TableCell>
                  <TableCell>2 min ago</TableCell>
                  <TableCell><Badge className="bg-orange-100 text-orange-800">Medium</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" className="h-8">Review</Button>
                  </TableCell>
                </TableRow>
                <TableRow className="bg-red-50">
                  <TableCell>
                    <div className="flex items-center">
                      <AlertCircle className="w-4 h-4 text-red-600 mr-2" />
                      <span>Geolocation Mismatch</span>
                    </div>
                  </TableCell>
                  <TableCell>ID76512</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Map className="w-4 h-4 mr-1 text-gray-500" />
                      Kyiv, UA
                    </div>
                  </TableCell>
                  <TableCell>4 min ago</TableCell>
                  <TableCell><Badge className="bg-red-100 text-red-800">High</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" className="h-8">Review</Button>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <div className="flex items-center">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mr-2" />
                      <span>New Device Login</span>
                    </div>
                  </TableCell>
                  <TableCell>ID34521</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Map className="w-4 h-4 mr-1 text-gray-500" />
                      Bangalore, IN
                    </div>
                  </TableCell>
                  <TableCell>7 min ago</TableCell>
                  <TableCell><Badge className="bg-yellow-100 text-yellow-800">Low</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" className="h-8">Review</Button>
                  </TableCell>
                </TableRow>
                <TableRow>
                  <TableCell>
                    <div className="flex items-center">
                      <AlertTriangle className="w-4 h-4 text-yellow-600 mr-2" />
                      <span>Inactive Account Activity</span>
                    </div>
                  </TableCell>
                  <TableCell>ID12987</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Map className="w-4 h-4 mr-1 text-gray-500" />
                      Hyderabad, IN
                    </div>
                  </TableCell>
                  <TableCell>12 min ago</TableCell>
                  <TableCell><Badge className="bg-yellow-100 text-yellow-800">Low</Badge></TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" className="h-8">Review</Button>
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Fraud Detection Performance</CardTitle>
              <CardDescription>System performance in the last 24 hours</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>True Positives</span>
                    <span className="font-medium">143 cases</span>
                  </div>
                  <Progress value={72} className="h-2 bg-gray-100" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>False Positives</span>
                    <span className="font-medium">28 cases</span>
                  </div>
                  <Progress value={14} className="h-2 bg-gray-100" />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>False Negatives</span>
                    <span className="font-medium">8 cases</span>
                  </div>
                  <Progress value={4} className="h-2 bg-gray-100" />
                </div>
              </div>
              
              <div className="mt-6 pt-4 border-t">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="text-sm text-vyom-gray">Overall Accuracy</div>
                    <div className="text-2xl font-bold text-green-600">94.2%</div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">+1.2% from yesterday</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Critical Security Alerts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="bg-red-50 border-red-200">
                <AlertCircle className="h-4 w-4 text-red-600" />
                <AlertTitle className="text-red-800">Brute Force Attack</AlertTitle>
                <AlertDescription className="text-red-700">
                  Multiple login attempts detected from IP range 172.68.xx.xx. 3 accounts affected.
                </AlertDescription>
              </Alert>
              <Alert className="bg-orange-50 border-orange-200">
                <AlertTriangle className="h-4 w-4 text-orange-600" />
                <AlertTitle className="text-orange-800">API Rate Limiting</AlertTitle>
                <AlertDescription className="text-orange-700">
                  Unusual number of API calls from 5 user accounts. Possible automated attack.
                </AlertDescription>
              </Alert>
              <Alert className="bg-blue-50 border-blue-200">
                <BellRing className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-800">Security Patch</AlertTitle>
                <AlertDescription className="text-blue-700">
                  Critical security update available for authentication system.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminOverview;
