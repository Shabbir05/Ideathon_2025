
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import { QrCode, Phone, UserCircle, Send, Clock, Smartphone } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const BHIMUPI = () => {
  const { toast } = useToast();
  const [upiId, setUpiId] = useState("");
  const [amount, setAmount] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Payment Initiated",
      description: `₹${amount} will be sent to ${upiId}`,
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">BHIM UPI Payments</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="col-span-1 md:col-span-2">
          <CardHeader>
            <div className="flex items-center space-x-3">
              <div className="h-12 w-12 rounded-lg bg-indigo-100 flex items-center justify-center">
                <Smartphone className="h-6 w-6 text-vyom-blue" />
              </div>
              <div>
                <CardTitle>Your UPI ID</CardTitle>
                <CardDescription>vyomuser@vyombank</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="p-4 border rounded-lg text-center hover:bg-accent transition-colors cursor-pointer">
                <div className="h-10 w-10 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-2">
                  <QrCode className="h-5 w-5 text-primary" />
                </div>
                <p className="text-sm font-medium">Scan & Pay</p>
              </div>
              <div className="p-4 border rounded-lg text-center hover:bg-accent transition-colors cursor-pointer">
                <div className="h-10 w-10 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-2">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <p className="text-sm font-medium">Mobile Number</p>
              </div>
              <div className="p-4 border rounded-lg text-center hover:bg-accent transition-colors cursor-pointer">
                <div className="h-10 w-10 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-2">
                  <UserCircle className="h-5 w-5 text-primary" />
                </div>
                <p className="text-sm font-medium">UPI ID</p>
              </div>
            </div>
            
            <Tabs defaultValue="upi" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="upi">Pay via UPI ID</TabsTrigger>
                <TabsTrigger value="mobile">Pay via Mobile</TabsTrigger>
                <TabsTrigger value="saved">Saved Contacts</TabsTrigger>
              </TabsList>
              
              <TabsContent value="upi">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="upiId" className="text-sm font-medium">UPI ID / VPA</label>
                    <Input
                      id="upiId"
                      placeholder="Enter UPI ID (e.g. name@bank)"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="amount" className="text-sm font-medium">Amount (₹)</label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="note" className="text-sm font-medium">Note (Optional)</label>
                    <Input id="note" placeholder="Add a note" />
                  </div>
                  
                  <Button type="submit" className="w-full">Pay Now</Button>
                </form>
              </TabsContent>
              
              <TabsContent value="mobile">
                <form className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="mobileNo" className="text-sm font-medium">Mobile Number</label>
                    <Input id="mobileNo" placeholder="Enter 10-digit mobile number" required />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="mobileAmount" className="text-sm font-medium">Amount (₹)</label>
                    <Input id="mobileAmount" type="number" placeholder="Enter amount" required />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="mobileNote" className="text-sm font-medium">Note (Optional)</label>
                    <Input id="mobileNote" placeholder="Add a note" />
                  </div>
                  
                  <Button type="submit" className="w-full">Pay Now</Button>
                </form>
              </TabsContent>
              
              <TabsContent value="saved">
                <div className="space-y-3">
                  {['Rahul Sharma', 'Mom', 'Electricity Bill', 'Rent Payment'].map((contact, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent transition-colors cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          {contact.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium">{contact}</p>
                          <p className="text-xs text-muted-foreground">
                            {index % 2 === 0 ? `${contact.toLowerCase().replace(' ', '')}@okbank` : '9876XXXXXX'}
                          </p>
                        </div>
                      </div>
                      <Send className="h-4 w-4 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Your QR Code</CardTitle>
            <CardDescription>Scan to pay you</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="h-48 w-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-4">
              <QrCode className="h-24 w-24 text-vyom-blue opacity-70" />
            </div>
            <p className="text-sm text-center text-muted-foreground mb-4">
              Share this QR code to receive payments directly to your account
            </p>
            <div className="flex gap-3">
              <Button variant="outline" size="sm">Download</Button>
              <Button variant="outline" size="sm">Share</Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Recent UPI Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: "Amazon Payment", date: "Today, 10:30 AM", amount: "₹1,250", type: "debit" },
              { name: "Rahul Sharma", date: "Yesterday, 3:15 PM", amount: "₹5,000", type: "credit" },
              { name: "Electricity Bill", date: "21 Mar 2025, 11:45 AM", amount: "₹3,250", type: "debit" },
              { name: "Priya Patel", date: "20 Mar 2025, 5:30 PM", amount: "₹2,500", type: "credit" },
            ].map((transaction, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent transition-colors">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{transaction.name}</p>
                    <p className="text-xs text-muted-foreground">{transaction.date}</p>
                  </div>
                </div>
                <p className={`font-medium ${transaction.type === "credit" ? "text-green-600" : "text-red-500"}`}>
                  {transaction.type === "credit" ? "+" : "-"}{transaction.amount}
                </p>
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <Button variant="outline">View All Transactions</Button>
          </div>
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default BHIMUPI;
