
import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import RiskBadge from "./RiskBadge";
import { ProfileWithRisk } from "./types";

interface ProfilesListProps {
  profiles: ProfileWithRisk[];
  onAssessRisk: (profileId: string) => void;
  onViewDetails: (profileId: string) => void;
  assessingId: string | null;
}

const ProfilesList = ({ 
  profiles, 
  onAssessRisk, 
  onViewDetails, 
  assessingId 
}: ProfilesListProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Name</TableHead>
          <TableHead>Age</TableHead>
          <TableHead>Occupation</TableHead>
          <TableHead>Income</TableHead>
          <TableHead>KYC</TableHead>
          <TableHead>Risk Score</TableHead>
          <TableHead>Risk Category</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {profiles.map((profile) => (
          <TableRow key={profile.id}>
            <TableCell className="font-medium">
              {profile.first_name} {profile.last_name}
            </TableCell>
            <TableCell>{profile.age || "N/A"}</TableCell>
            <TableCell>{profile.occupation || "N/A"}</TableCell>
            <TableCell>
              {profile.annual_income
                ? `₹${profile.annual_income.toLocaleString()}`
                : "N/A"}
            </TableCell>
            <TableCell>
              {profile.kyc_verified ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
            </TableCell>
            <TableCell>
              {profile.risk_assessment
                ? profile.risk_assessment.risk_score
                : "Not assessed"}
            </TableCell>
            <TableCell>
              {profile.risk_assessment
                ? <RiskBadge category={profile.risk_assessment.risk_category} />
                : <Badge variant="outline">Not assessed</Badge>}
            </TableCell>
            <TableCell>
              {profile.risk_assessment ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onViewDetails(profile.id)}
                >
                  View Details
                </Button>
              ) : (
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => onAssessRisk(profile.id)}
                  disabled={assessingId === profile.id}
                >
                  {assessingId === profile.id ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Assessing...
                    </>
                  ) : (
                    "Assess Risk"
                  )}
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default ProfilesList;
