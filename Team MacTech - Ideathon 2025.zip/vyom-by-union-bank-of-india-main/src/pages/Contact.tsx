
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useLanguage } from "@/components/LanguageToggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  MessageSquare,
  Send
} from "lucide-react";

const Contact = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { currentLanguage } = useLanguage();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: ""
  });
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  // Content translations
  const content = {
    en: {
      title: "Contact Us",
      subtitle: "We're here to help",
      description: "Have questions or need assistance? Our team is ready to help you with any inquiries you may have.",
      form: {
        title: "Send us a message",
        name: "Your Name",
        email: "Email Address",
        phone: "Phone Number (Optional)",
        subject: "Subject",
        message: "Your Message",
        button: "Send Message"
      },
      contact: {
        title: "Contact Information",
        visit: "Visit Us",
        call: "Call Us",
        email: "Email Us",
        hours: "Business Hours"
      },
      faq: {
        title: "Frequently Asked Questions",
        questions: [
          {
            question: "How do I open an account?",
            answer: "You can open an account online in just a few minutes. Click on the 'Get Started' button, complete the application form, verify your identity, and your account will be ready to use."
          },
          {
            question: "Is my money safe with Vyom?",
            answer: "Yes, your money is safe with Vyom. We use industry-standard security measures and all deposits are insured up to ₹5 lakh by the Deposit Insurance and Credit Guarantee Corporation (DICGC)."
          },
          {
            question: "How do I report suspicious activity?",
            answer: "If you notice any suspicious activity, please contact our 24/7 customer service immediately. You can call us or use the secure messaging feature in the mobile app."
          },
          {
            question: "What are the fees for using Vyom?",
            answer: "Vyom offers zero-fee accounts with no minimum balance requirements for standard users. Specific services like international transfers may have associated fees, which are transparently disclosed."
          }
        ]
      },
      address: "123 Financial District, Mumbai 400001, India",
      phone: "+91 1800 123 4567",
      email: "support@vyombank.com",
      hours: "Monday to Friday: 9am - 6pm\nSaturday: 10am - 2pm\nSunday: Closed",
      success: "Thank you for your message! We will get back to you soon.",
      error: "Sorry, there was an error sending your message. Please try again."
    },
    hi: {
      title: "संपर्क करें",
      subtitle: "हम मदद के लिए यहां हैं",
      description: "प्रश्न हैं या सहायता की आवश्यकता है? हमारी टीम आपके किसी भी प्रश्न में आपकी सहायता करने के लिए तैयार है।",
      form: {
        title: "हमें एक संदेश भेजें",
        name: "आपका नाम",
        email: "ईमेल पता",
        phone: "फोन नंबर (वैकल्पिक)",
        subject: "विषय",
        message: "आपका संदेश",
        button: "संदेश भेजें"
      },
      contact: {
        title: "संपर्क जानकारी",
        visit: "हमसे मिलें",
        call: "हमें कॉल करें",
        email: "हमें ईमेल करें",
        hours: "कार्य घंटे"
      },
      faq: {
        title: "अक्सर पूछे जाने वाले प्रश्न",
        questions: [
          {
            question: "मैं खाता कैसे खोलूं?",
            answer: "आप कुछ ही मिनटों में ऑनलाइन खाता खोल सकते हैं। 'आरंभ करें' बटन पर क्लिक करें, आवेदन पत्र भरें, अपनी पहचान सत्यापित करें, और आपका खाता उपयोग के लिए तैयार हो जाएगा।"
          },
          {
            question: "क्या व्योम के साथ मेरा पैसा सुरक्षित है?",
            answer: "हां, व्योम के साथ आपका पैसा सुरक्षित है। हम उद्योग-मानक सुरक्षा उपायों का उपयोग करते हैं और सभी जमा डिपॉजिट इंश्योरेंस एंड क्रेडिट गारंटी कॉरपोरेशन (DICGC) द्वारा ₹5 लाख तक बीमित हैं।"
          },
          {
            question: "मैं संदिग्ध गतिविधि की रिपोर्ट कैसे करूं?",
            answer: "यदि आप कोई संदिग्ध गतिविधि देखते हैं, तो कृपया तुरंत हमारी 24/7 ग्राहक सेवा से संपर्क करें। आप हमें कॉल कर सकते हैं या मोबाइल ऐप में सुरक्षित मैसेजिंग सुविधा का उपयोग कर सकते हैं।"
          },
          {
            question: "व्योम का उपयोग करने के लिए शुल्क क्या हैं?",
            answer: "व्योम मानक उपयोगकर्ताओं के लिए बिना न्यूनतम शेष राशि आवश्यकताओं के शून्य-शुल्क खाते प्रदान करता है। अंतर्राष्ट्रीय स्थानांतरण जैसी विशिष्ट सेवाओं के संबंधित शुल्क हो सकते हैं, जो पारदर्शी रूप से प्रकट किए जाते हैं।"
          }
        ]
      },
      address: "123 फाइनेंशियल डिस्ट्रिक्ट, मुंबई 400001, भारत",
      phone: "+91 1800 123 4567",
      email: "support@vyombank.com",
      hours: "सोमवार से शुक्रवार: सुबह 9 बजे - शाम 6 बजे\nशनिवार: सुबह 10 बजे - दोपहर 2 बजे\nरविवार: बंद",
      success: "आपके संदेश के लिए धन्यवाद! हम जल्द ही आपसे संपर्क करेंगे।",
      error: "क्षमा करें, आपका संदेश भेजने में त्रुटि हुई। कृपया पुनः प्रयास करें।"
    },
    mr: {
      title: "संपर्क करा",
      subtitle: "आम्ही मदत करण्यासाठी येथे आहोत",
      description: "प्रश्न आहेत किंवा मदत हवी आहे? आमची टीम तुमच्या कोणत्याही चौकशीत तुम्हाला मदत करण्यासाठी तयार आहे.",
      form: {
        title: "आम्हाला संदेश पाठवा",
        name: "तुमचे नाव",
        email: "ईमेल पत्ता",
        phone: "फोन नंबर (पर्यायी)",
        subject: "विषय",
        message: "तुमचा संदेश",
        button: "संदेश पाठवा"
      },
      contact: {
        title: "संपर्क माहिती",
        visit: "आम्हाला भेट द्या",
        call: "आम्हाला कॉल करा",
        email: "आम्हाला ईमेल करा",
        hours: "कार्यालयीन वेळ"
      },
      faq: {
        title: "वारंवार विचारले जाणारे प्रश्न",
        questions: [
          {
            question: "मी खाते कसे उघडू?",
            answer: "तुम्ही काही मिनिटांत ऑनलाइन खाते उघडू शकता. 'आता सुरू करा' बटणावर क्लिक करा, अर्ज फॉर्म पूर्ण करा, तुमची ओळख पटवा, आणि तुमचे खाते वापरण्यासाठी तयार असेल."
          },
          {
            question: "व्योमसह माझे पैसे सुरक्षित आहेत का?",
            answer: "होय, व्योमसह तुमचे पैसे सुरक्षित आहेत. आम्ही उद्योग-मानक सुरक्षा उपाय वापरतो आणि सर्व ठेवी डिपॉझिट इन्शुरन्स अँड क्रेडिट गॅरंटी कॉर्पोरेशन (DICGC) द्वारे ₹5 लाखापर्यंत विमा आहेत."
          },
          {
            question: "मी संशयास्पद क्रियाकलापाची तक्रार कशी करू?",
            answer: "जर तुम्हाला काही संशयास्पद क्रियाकलाप दिसल्यास, कृपया आमच्या 24/7 ग्राहक सेवेशी त्वरित संपर्क साधा. तुम्ही आम्हाला कॉल करू शकता किंवा मोबाइल अॅपमधील सुरक्षित मेसेजिंग वैशिष्ट्य वापरू शकता."
          },
          {
            question: "व्योम वापरण्यासाठी शुल्क काय आहेत?",
            answer: "व्योम मानक वापरकर्त्यांसाठी कोणतीही किमान शिल्लक आवश्यकता नसलेले शून्य-शुल्क खाती देते. आंतरराष्ट्रीय हस्तांतरणासारख्या विशिष्ट सेवांमध्ये संबंधित शुल्क असू शकते, जे पारदर्शकपणे उघड केले जातात."
          }
        ]
      },
      address: "123 फायनान्शियल डिस्ट्रिक्ट, मुंबई 400001, भारत",
      phone: "+91 1800 123 4567",
      email: "support@vyombank.com",
      hours: "सोमवार ते शुक्रवार: सकाळी 9 - संध्याकाळी 6\nशनिवार: सकाळी 10 - दुपारी 2\nरविवार: बंद",
      success: "तुमच्या संदेशाबद्दल धन्यवाद! आम्ही लवकरच तुमच्याशी संपर्क साधू.",
      error: "क्षमा करा, तुमचा संदेश पाठवताना त्रुटी आली. कृपया पुन्हा प्रयत्न करा."
    }
  };

  // Get content based on current language
  const t = content[currentLanguage.code as keyof typeof content] || content.en;
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simulating form submission
    setTimeout(() => {
      toast({
        title: t.success,
        duration: 3000,
      });
      
      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        subject: "",
        message: ""
      });
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-40 pb-20 px-4 bg-gradient-to-b from-white to-vyom-light">
        <div className="container mx-auto">
          <div className={`max-w-3xl mx-auto text-center ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}>
            <h1 className="text-4xl md:text-5xl font-bold text-vyom-blue mb-6">{t.title}</h1>
            <p className="text-xl text-vyom-red font-medium mb-8">{t.subtitle}</p>
            <p className="text-lg text-vyom-gray">{t.description}</p>
          </div>
        </div>
      </section>
      
      {/* Contact Form & Info */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              <div className="bg-vyom-light p-8 rounded-xl shadow-md">
                <div className="flex items-center mb-6">
                  <MessageSquare className="text-vyom-red mr-3" />
                  <h2 className="text-2xl font-bold text-vyom-blue">{t.form.title}</h2>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-vyom-gray mb-1">
                      {t.form.name}*
                    </label>
                    <Input 
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full"
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-vyom-gray mb-1">
                        {t.form.email}*
                      </label>
                      <Input 
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="block text-sm font-medium text-vyom-gray mb-1">
                        {t.form.phone}
                      </label>
                      <Input 
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-vyom-gray mb-1">
                      {t.form.subject}*
                    </label>
                    <Input 
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-vyom-gray mb-1">
                      {t.form.message}*
                    </label>
                    <Textarea 
                      id="message"
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      className="w-full min-h-[150px]"
                    />
                  </div>
                  
                  <Button type="submit" className="w-full bg-vyom-red hover:bg-vyom-red/90 text-white">
                    <Send className="mr-2 h-4 w-4" />
                    {t.form.button}
                  </Button>
                </form>
              </div>
            </div>
            
            {/* Contact Information */}
            <div className={`${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <div className="bg-vyom-blue text-white p-8 rounded-xl shadow-md h-full">
                <h2 className="text-2xl font-bold mb-8">{t.contact.title}</h2>
                
                <div className="space-y-8">
                  <div className="flex">
                    <div className="mr-4">
                      <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                        <MapPin className="text-white h-6 w-6" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{t.contact.visit}</h3>
                      <p className="text-white/80">{t.address}</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4">
                      <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                        <Phone className="text-white h-6 w-6" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{t.contact.call}</h3>
                      <p className="text-white/80">{t.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4">
                      <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                        <Mail className="text-white h-6 w-6" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{t.contact.email}</h3>
                      <p className="text-white/80">{t.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="mr-4">
                      <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                        <Clock className="text-white h-6 w-6" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">{t.contact.hours}</h3>
                      <p className="text-white/80 whitespace-pre-line">{t.hours}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Map Section */}
      <section className="py-10 px-4">
        <div className="container mx-auto">
          <div className={`w-full h-[400px] rounded-xl overflow-hidden shadow-md ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d60323.90093460653!2d72.80472350865786!3d18.9516318532866!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7d1c73a0d5cad%3A0xc70a25a7209c733c!2sNariman%20Point%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1684925945927!5m2!1sen!2sin" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              loading="lazy" 
            />
          </div>
        </div>
      </section>
      
      {/* FAQ Section */}
      <section className="py-20 px-4 bg-vyom-light">
        <div className="container mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-bold text-vyom-blue mb-4">{t.faq.title}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {t.faq.questions.map((faq, index) => (
              <div 
                key={index}
                className={`bg-white p-6 rounded-xl shadow-md transform transition-all duration-300 hover:shadow-lg ${isLoaded ? 'animate-fade-in' : 'opacity-0'}`}
                style={{ animationDelay: `${0.2 + 0.1 * index}s` }}
              >
                <h3 className="text-xl font-semibold text-vyom-blue mb-3">{faq.question}</h3>
                <p className="text-vyom-gray">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-vyom-blue to-vyom-navy text-white">
        <div className="container mx-auto">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to join Vyom?</h2>
            <p className="text-white/80 mb-8">Experience the future of banking with our innovative digital platform.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/signup">
                <Button className="bg-vyom-red hover:bg-vyom-red/90 text-white px-8 py-6 rounded-lg text-lg font-medium transition-all duration-300 shadow-lg hover:shadow-xl w-full sm:w-auto">
                  Get Started Now
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default Contact;
