
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";

const Cards = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-vyom-blue">Cards Management</h1>
        <Button className="flex items-center gap-2">
          <PlusCircle size={16} />
          Apply for New Card
        </Button>
      </div>
      
      <Tabs defaultValue="credit" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="credit">Credit Cards</TabsTrigger>
          <TabsTrigger value="debit">Debit Cards</TabsTrigger>
          <TabsTrigger value="virtual">Virtual Cards</TabsTrigger>
        </TabsList>
        
        <TabsContent value="credit" className="mt-6 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Vyom Platinum Credit Card</CardTitle>
                <CardDescription>**** **** **** 1234</CardDescription>
              </div>
              <CreditCard className="h-8 w-8 text-vyom-blue" />
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-sm text-muted-foreground">Available Credit</p>
                  <p className="text-2xl font-bold">₹1,45,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Due</p>
                  <p className="text-2xl font-bold text-vyom-red">₹12,450</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Due Date</p>
                  <p className="text-lg">15 Apr 2025</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Reward Points</p>
                  <p className="text-lg">2,450</p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" size="sm">View Statement</Button>
                <Button variant="outline" size="sm">Pay Bill</Button>
                <Button variant="outline" size="sm">Convert to EMI</Button>
                <Button variant="outline" size="sm">Report Lost Card</Button>
                <Button variant="outline" size="sm">Card Settings</Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Vyom Rewards Credit Card</CardTitle>
                <CardDescription>**** **** **** 5678</CardDescription>
              </div>
              <CreditCard className="h-8 w-8 text-vyom-teal" />
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-sm text-muted-foreground">Available Credit</p>
                  <p className="text-2xl font-bold">₹75,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Due</p>
                  <p className="text-2xl font-bold text-vyom-red">₹5,280</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Due Date</p>
                  <p className="text-lg">23 Apr 2025</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Reward Points</p>
                  <p className="text-lg">1,250</p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" size="sm">View Statement</Button>
                <Button variant="outline" size="sm">Pay Bill</Button>
                <Button variant="outline" size="sm">Convert to EMI</Button>
                <Button variant="outline" size="sm">Report Lost Card</Button>
                <Button variant="outline" size="sm">Card Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="debit" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Vyom Gold Debit Card</CardTitle>
                <CardDescription>**** **** **** 9876</CardDescription>
              </div>
              <CreditCard className="h-8 w-8 text-vyom-purple" />
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-sm text-muted-foreground">Linked Account</p>
                  <p className="text-lg">Savings Account (...5467)</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Daily Limit</p>
                  <p className="text-lg">₹1,00,000</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Card Expiry</p>
                  <p className="text-lg">05/2028</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Card Status</p>
                  <p className="text-lg text-green-600">Active</p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" size="sm">View Transactions</Button>
                <Button variant="outline" size="sm">Set Limits</Button>
                <Button variant="outline" size="sm">Block Card</Button>
                <Button variant="outline" size="sm">Report Lost Card</Button>
                <Button variant="outline" size="sm">Card Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="virtual" className="mt-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl font-bold">Vyom Virtual Card</CardTitle>
                <CardDescription>For online transactions</CardDescription>
              </div>
              <CreditCard className="h-8 w-8 text-vyom-blue" />
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-10">
                <p className="text-lg text-muted-foreground mb-4">No virtual cards found</p>
                <Button>Create Virtual Card</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default Cards;
