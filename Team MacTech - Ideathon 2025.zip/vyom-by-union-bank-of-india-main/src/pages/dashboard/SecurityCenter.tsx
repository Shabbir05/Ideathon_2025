
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Eye, EyeOff, Lock, Shield, Smartphone, Bell, UserCog, History, Key } from "lucide-react";
import { useNavigate } from "react-router-dom";

const SecurityCenter = () => {
  const navigate = useNavigate();
  const [showSecurityScore, setShowSecurityScore] = useState(true);
  const [securitySettings, setSecuritySettings] = useState({
    twoFactorAuth: true,
    loginNotifications: true,
    transactionAlerts: true,
    biometricLogin: false,
    deviceManagement: true,
    passwordUpdate: false,
  });

  const handleToggleSetting = (setting: keyof typeof securitySettings) => {
    setSecuritySettings({
      ...securitySettings,
      [setting]: !securitySettings[setting],
    });
    
    toast({
      title: "Setting Updated",
      description: `${setting === 'twoFactorAuth' ? 'Two-Factor Authentication' : 
                    setting === 'loginNotifications' ? 'Login Notifications' :
                    setting === 'transactionAlerts' ? 'Transaction Alerts' :
                    setting === 'biometricLogin' ? 'Biometric Login' :
                    setting === 'deviceManagement' ? 'Device Management' :
                    'Password Update Reminder'} has been ${!securitySettings[setting] ? 'enabled' : 'disabled'}.`,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => navigate("/dashboard")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="col-span-1 md:col-span-2">
          <Card className="shadow-md border-none h-full">
            <CardHeader className="bg-gradient-to-r from-vyom-blue to-vyom-purple text-white">
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Security Center
              </CardTitle>
              <CardDescription className="text-white/80">
                Manage your account security settings
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-vyom-blue/10 p-2 rounded-full">
                      <Smartphone className="h-5 w-5 text-vyom-blue" />
                    </div>
                    <div>
                      <h3 className="font-medium">Two-Factor Authentication</h3>
                      <p className="text-sm text-vyom-gray">Add an extra layer of security</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.twoFactorAuth} 
                    onCheckedChange={() => handleToggleSetting('twoFactorAuth')}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-vyom-purple/10 p-2 rounded-full">
                      <Bell className="h-5 w-5 text-vyom-purple" />
                    </div>
                    <div>
                      <h3 className="font-medium">Login Notifications</h3>
                      <p className="text-sm text-vyom-gray">Get alerted about new logins</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.loginNotifications} 
                    onCheckedChange={() => handleToggleSetting('loginNotifications')}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-vyom-teal/10 p-2 rounded-full">
                      <Bell className="h-5 w-5 text-vyom-teal" />
                    </div>
                    <div>
                      <h3 className="font-medium">Transaction Alerts</h3>
                      <p className="text-sm text-vyom-gray">Get notified about transactions</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.transactionAlerts} 
                    onCheckedChange={() => handleToggleSetting('transactionAlerts')}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-vyom-red/10 p-2 rounded-full">
                      <Smartphone className="h-5 w-5 text-vyom-red" />
                    </div>
                    <div>
                      <h3 className="font-medium">Biometric Login</h3>
                      <p className="text-sm text-vyom-gray">Use fingerprint or face to login</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.biometricLogin} 
                    onCheckedChange={() => handleToggleSetting('biometricLogin')}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-vyom-green/10 p-2 rounded-full">
                      <UserCog className="h-5 w-5 text-vyom-green" />
                    </div>
                    <div>
                      <h3 className="font-medium">Device Management</h3>
                      <p className="text-sm text-vyom-gray">Manage trusted devices</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.deviceManagement} 
                    onCheckedChange={() => handleToggleSetting('deviceManagement')}
                  />
                </div>
                
                <div className="flex items-center justify-between p-4 rounded-lg border bg-gray-50 hover:border-vyom-blue/30 hover:bg-vyom-light/50 transition-all">
                  <div className="flex items-center gap-3">
                    <div className="bg-amber-100 p-2 rounded-full">
                      <Key className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Password Update Reminder</h3>
                      <p className="text-sm text-vyom-gray">Get reminded to update password</p>
                    </div>
                  </div>
                  <Switch 
                    checked={securitySettings.passwordUpdate} 
                    onCheckedChange={() => handleToggleSetting('passwordUpdate')}
                  />
                </div>
              </div>
              
              <div className="border-t pt-6">
                <h3 className="font-medium mb-4">Security Actions</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <Button variant="outline" className="justify-start">
                    <Key className="mr-2 h-4 w-4" /> Change Password
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Smartphone className="mr-2 h-4 w-4" /> Setup Two-Factor Authentication
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <UserCog className="mr-2 h-4 w-4" /> Manage Trusted Devices
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <History className="mr-2 h-4 w-4" /> View Login History
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="col-span-1">
          <Card className="shadow-md border-none h-full">
            <CardHeader className="bg-gradient-to-b from-gray-50 to-white">
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-vyom-blue" />
                Security Score
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex justify-end mb-4">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0" 
                  onClick={() => setShowSecurityScore(!showSecurityScore)}
                >
                  {showSecurityScore ? <EyeOff size={16} /> : <Eye size={16} />}
                </Button>
              </div>
              
              {showSecurityScore ? (
                <div className="space-y-6">
                  <div className="flex flex-col items-center justify-center">
                    <div className="relative h-32 w-32">
                      <div className="h-32 w-32 rounded-full border-8 border-vyom-blue bg-vyom-blue/10 flex items-center justify-center">
                        <span className="text-3xl font-bold text-vyom-blue">85%</span>
                      </div>
                      <div className="absolute bottom-0 right-0 bg-vyom-green text-white p-1 rounded-full">
                        <Shield size={16} />
                      </div>
                    </div>
                    <p className="mt-3 text-center text-sm text-vyom-gray">Your account security is good, but can be improved</p>
                  </div>
                  
                  <div className="space-y-3">
                    <h3 className="font-medium">Recommendations</h3>
                    <div className="p-3 bg-vyom-light rounded-lg text-sm">
                      <p className="font-medium text-vyom-blue">Enable biometric login</p>
                      <p className="text-vyom-gray mt-1">Adds an extra layer of security to your account</p>
                    </div>
                    <div className="p-3 bg-vyom-light rounded-lg text-sm">
                      <p className="font-medium text-vyom-blue">Enable password update reminders</p>
                      <p className="text-vyom-gray mt-1">Regular password changes improve security</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-[300px] flex items-center justify-center">
                  <p className="text-vyom-gray">Click the eye icon to view your security score</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SecurityCenter;
