
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Building, Users, BarChart3, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import BusinessAdvisorForm from "@/components/services/BusinessAdvisorForm";
import { toast } from "@/hooks/use-toast";

const BusinessBanking = () => {
  const [showAdvisorForm, setShowAdvisorForm] = useState(false);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero Section */}
        <section className="py-12 md:py-20 bg-gradient-to-r from-vyom-navy/10 via-white to-vyom-teal/10">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 text-vyom-navy">Business Banking Solutions</h1>
              <p className="text-lg md:text-xl text-vyom-gray mb-8">
                Comprehensive financial solutions designed to help your business grow and thrive in today's competitive landscape.
              </p>
              <Button 
                size="lg" 
                className="bg-vyom-blue hover:bg-vyom-blue/90 text-white"
                onClick={() => setShowAdvisorForm(true)}
              >
                Talk to a Business Advisor
              </Button>
            </div>
          </div>
        </section>
        
        {/* Business Solutions */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Solutions For Every Business</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-blue rounded-full flex items-center justify-center mb-6">
                  <Building className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">Corporate Accounts</h3>
                <p className="text-vyom-gray mb-4">Tailored banking solutions for medium to large enterprises with high transaction volumes.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Multi-user access controls</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Bulk payment processing</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Dedicated relationship manager</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    toast({
                      title: "Corporate Banking",
                      description: "Thank you for your interest in our Corporate Banking solutions. A corporate account manager will contact you shortly.",
                    });
                  }}
                >
                  Learn More
                </Button>
              </div>
              
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-teal rounded-full flex items-center justify-center mb-6">
                  <Briefcase className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">SME Banking</h3>
                <p className="text-vyom-gray mb-4">Specialized solutions for small and medium enterprises to optimize cash flow and growth.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Business loans with competitive rates</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Overdraft facilities</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Payment gateway integration</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    toast({
                      title: "SME Banking",
                      description: "Thank you for your interest in our SME Banking solutions. An SME banking specialist will contact you shortly.",
                    });
                  }}
                >
                  Learn More
                </Button>
              </div>
              
              <div className="bg-vyom-light rounded-xl p-8 hover:shadow-lg transition-all duration-300">
                <div className="w-14 h-14 bg-vyom-purple rounded-full flex items-center justify-center mb-6">
                  <Users className="text-white h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-vyom-blue">Startups & MSMEs</h3>
                <p className="text-vyom-gray mb-4">Enabling young businesses with financial tools and resources needed to succeed.</p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Zero balance business accounts</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Startup-friendly loan schemes</span>
                  </li>
                  <li className="flex items-start">
                    <ArrowRight className="h-5 w-5 text-vyom-blue mr-2 shrink-0 mt-0.5" />
                    <span>Business advisory services</span>
                  </li>
                </ul>
                <Button 
                  variant="outline" 
                  className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white w-full"
                  onClick={() => {
                    toast({
                      title: "Startup Banking",
                      description: "Thank you for your interest in our Startup Banking solutions. A startup specialist will contact you shortly.",
                    });
                  }}
                >
                  Learn More
                </Button>
              </div>
            </div>
          </div>
        </section>
        
        {/* Business Digital Banking */}
        <section className="py-16 bg-gradient-to-br from-vyom-navy/5 to-vyom-teal/5">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row-reverse items-center max-w-6xl mx-auto">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pl-8">
                <img 
                  src="/placeholder.svg" 
                  alt="Vyom Business Banking Dashboard" 
                  className="rounded-xl shadow-lg w-full"
                />
              </div>
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold mb-6 text-vyom-blue">Enterprise-Grade Digital Banking</h2>
                <p className="text-vyom-gray mb-6">Our advanced digital platform offers comprehensive tools designed specifically for business needs.</p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-blue rounded-full flex items-center justify-center shrink-0 mr-4">
                      <Users className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Role-Based Access</h4>
                      <p className="text-vyom-gray">Assign specific banking permissions to different team members based on their roles.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-teal rounded-full flex items-center justify-center shrink-0 mr-4">
                      <BarChart3 className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Financial Analytics</h4>
                      <p className="text-vyom-gray">Gain insights into your business finances with detailed reports and analytics.</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-vyom-purple rounded-full flex items-center justify-center shrink-0 mr-4">
                      <Building className="text-white h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Integration Capabilities</h4>
                      <p className="text-vyom-gray">Seamlessly connect with accounting software and ERP systems.</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  <Button 
                    className="bg-vyom-blue hover:bg-vyom-blue/90 text-white"
                    onClick={() => {
                      toast({
                        title: "Business Registration",
                        description: "Thank you for your interest in registering your business. Our team will contact you shortly to complete the registration process.",
                      });
                    }}
                  >
                    Register Your Business
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-vyom-blue text-vyom-blue hover:bg-vyom-blue hover:text-white"
                    onClick={() => {
                      toast({
                        title: "Demo Request",
                        description: "Thank you for requesting a demo. Our team will schedule a personalized demo session for you shortly.",
                      });
                    }}
                  >
                    Request Demo
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Business Services */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Comprehensive Business Services</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue">Trade Finance</h3>
                <p className="text-vyom-gray">International trade solutions including LCs, guarantees, and forex services.</p>
              </div>
              
              <div className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue">Cash Management</h3>
                <p className="text-vyom-gray">Optimize your cash flow with collection, payment, and liquidity management services.</p>
              </div>
              
              <div className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue">Merchant Services</h3>
                <p className="text-vyom-gray">Payment acceptance solutions including POS terminals and payment gateways.</p>
              </div>
              
              <div className="p-6 rounded-xl hover:shadow-md transition-all duration-300 border border-gray-100">
                <h3 className="font-bold text-lg mb-3 text-vyom-blue">Supply Chain Finance</h3>
                <p className="text-vyom-gray">End-to-end financing solutions for your entire supply chain ecosystem.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-vyom-blue text-white">
          <div className="container mx-auto px-4 text-center max-w-4xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Accelerate Your Business Growth With Vyom</h2>
            <p className="text-lg md:text-xl mb-8 opacity-90">Partner with us for comprehensive financial solutions tailored to your business requirements.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                size="lg" 
                className="bg-white text-vyom-blue hover:bg-vyom-light"
                onClick={() => {
                  toast({
                    title: "Business Registration",
                    description: "Thank you for your interest in registering your business. Our team will contact you shortly to complete the registration process.",
                  });
                }}
              >
                Register Your Business
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white/10"
                onClick={() => setShowAdvisorForm(true)}
              >
                Schedule Consultation
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      {showAdvisorForm && <BusinessAdvisorForm onClose={() => setShowAdvisorForm(false)} />}
      
      <Footer />
    </div>
  );
};

export default BusinessBanking;
