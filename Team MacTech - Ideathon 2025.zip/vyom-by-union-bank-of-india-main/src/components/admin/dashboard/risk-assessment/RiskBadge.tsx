
import React from "react";
import { Badge } from "@/components/ui/badge";

interface RiskBadgeProps {
  category: string;
}

const RiskBadge = ({ category }: RiskBadgeProps) => {
  switch (category) {
    case "Low":
      return <Badge className="bg-green-500">Low</Badge>;
    case "Medium":
      return <Badge className="bg-yellow-500">Medium</Badge>;
    case "High":
      return <Badge className="bg-red-500">High</Badge>;
    default:
      return <Badge className="bg-gray-500">Unknown</Badge>;
  }
};

export default RiskBadge;
