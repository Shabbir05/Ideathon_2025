
import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]",
  {
    variants: {
      variant: {
        default: "bg-vyom-red text-white hover:bg-vyom-red/90 hover:shadow-md hover:translate-y-[-2px]",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90 hover:shadow-md",
        outline:
          "border border-input bg-background hover:bg-accent/10 hover:text-accent-foreground hover:border-accent hover:shadow-sm",
        secondary:
          "bg-vyom-blue text-white hover:bg-vyom-blue/90 hover:shadow-md hover:translate-y-[-2px]",
        ghost: "hover:bg-accent/10 hover:text-accent-foreground",
        link: "text-vyom-blue underline-offset-4 hover:underline hover:text-vyom-accent",
        teal: "bg-vyom-teal text-white hover:bg-vyom-teal/90 hover:shadow-md hover:translate-y-[-2px]",
        purple: "bg-vyom-purple text-white hover:bg-vyom-purple/90 hover:shadow-md hover:translate-y-[-2px]",
        gradient: "bg-gradient-to-r from-vyom-blue to-vyom-teal text-white hover:shadow-lg hover:opacity-90 hover:translate-y-[-2px]",
        contact: "bg-white text-vyom-blue hover:bg-vyom-light hover:shadow-md hover:translate-y-[-2px] border border-vyom-blue/20",
        toggle: "bg-white text-foreground hover:bg-vyom-light transition-all",
        "toggle-active": "bg-white text-foreground shadow-sm font-semibold",
        international: "bg-gradient-to-r from-vyom-purple to-vyom-blue text-white hover:shadow-lg hover:opacity-90 hover:translate-y-[-2px]",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
        xl: "h-12 rounded-md px-10 text-base",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }
