
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Gift, Award, Clock, ShoppingBag, Tag, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

const Rewards = () => {
  const { toast } = useToast();
  
  const handleClaim = () => {
    toast({
      title: "Reward Claimed",
      description: "Your reward has been claimed successfully!"
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">Rewards & Loyalty</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="col-span-1 md:col-span-2">
          <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                  <Award className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <CardTitle>Your Rewards</CardTitle>
                  <CardDescription>Earn and redeem rewards on all your transactions</CardDescription>
                </div>
              </div>
              <Button>Redeem Points</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <h3 className="text-4xl font-bold text-vyom-blue mb-2">5,250</h3>
                    <p className="text-muted-foreground mb-4">Available Points</p>
                    <p className="text-sm">Worth approx. ₹1,312</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <h3 className="text-4xl font-bold text-vyom-purple mb-2">750</h3>
                    <p className="text-muted-foreground mb-4">Points Earned This Month</p>
                    <p className="text-sm">12 transactions</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <h3 className="text-4xl font-bold text-vyom-teal mb-2">3,500</h3>
                    <p className="text-muted-foreground mb-4">Lifetime Points Redeemed</p>
                    <p className="text-sm">5 redemptions</p>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="mt-8">
              <h3 className="text-lg font-medium mb-4">Upcoming Milestones</h3>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm">Silver Tier</span>
                    <span className="text-sm text-vyom-blue">4,250 / 5,000 points</span>
                  </div>
                  <Progress value={85} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-2">Earn 750 more points to reach Silver Tier</p>
                </div>
                
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm">Airport Lounge Access</span>
                    <span className="text-sm text-vyom-blue">5,250 / 10,000 points</span>
                  </div>
                  <Progress value={52} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-2">Earn 4,750 more points for complimentary lounge access</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Quick Redeem</CardTitle>
            <CardDescription>Popular redemption options</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border rounded-lg p-4 hover:bg-accent transition-colors cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-9 w-9 rounded-full bg-red-100 flex items-center justify-center">
                    <ShoppingBag className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <p className="font-medium">Amazon Voucher</p>
                    <p className="text-xs text-muted-foreground">2,000 points for ₹500</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full" onClick={handleClaim}>Redeem Now</Button>
              </div>
              
              <div className="border rounded-lg p-4 hover:bg-accent transition-colors cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-9 w-9 rounded-full bg-blue-100 flex items-center justify-center">
                    <Tag className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-medium">Flipkart Voucher</p>
                    <p className="text-xs text-muted-foreground">2,000 points for ₹500</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full" onClick={handleClaim}>Redeem Now</Button>
              </div>
              
              <div className="border rounded-lg p-4 hover:bg-accent transition-colors cursor-pointer">
                <div className="flex items-center gap-3 mb-2">
                  <div className="h-9 w-9 rounded-full bg-green-100 flex items-center justify-center">
                    <Zap className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <p className="font-medium">Cashback</p>
                    <p className="text-xs text-muted-foreground">4,000 points for ₹1,000</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full" onClick={handleClaim}>Redeem Now</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="rewards-store" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="rewards-store">Rewards Store</TabsTrigger>
          <TabsTrigger value="point-history">Points History</TabsTrigger>
          <TabsTrigger value="benefits">Your Benefits</TabsTrigger>
        </TabsList>
        
        <TabsContent value="rewards-store" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Amazon Gift Card",
                points: "2,000",
                value: "₹500",
                category: "Shopping",
                icon: <ShoppingBag className="h-5 w-5 text-red-600" />
              },
              {
                title: "Movie Tickets",
                points: "1,500",
                value: "2 tickets",
                category: "Entertainment",
                icon: <Gift className="h-5 w-5 text-purple-600" />
              },
              {
                title: "Flight Ticket Discount",
                points: "8,000",
                value: "₹2,000 off",
                category: "Travel",
                icon: <Tag className="h-5 w-5 text-blue-600" />
              },
              {
                title: "Dining Voucher",
                points: "3,000",
                value: "₹750",
                category: "Dining",
                icon: <Gift className="h-5 w-5 text-amber-600" />
              },
              {
                title: "Cashback to Account",
                points: "4,000",
                value: "₹1,000",
                category: "Cashback",
                icon: <Zap className="h-5 w-5 text-green-600" />
              },
              {
                title: "Electronics Discount",
                points: "10,000",
                value: "₹2,500 off",
                category: "Electronics",
                icon: <ShoppingBag className="h-5 w-5 text-teal-600" />
              },
            ].map((reward, index) => (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <Badge className="bg-primary/10 text-primary border-none">
                      {reward.category}
                    </Badge>
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      {reward.icon}
                    </div>
                  </div>
                  <CardTitle className="mt-3">{reward.title}</CardTitle>
                  <CardDescription>Value: {reward.value}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 mb-4">
                    <Award className="h-5 w-5 text-amber-500" />
                    <span className="font-medium">{reward.points} points</span>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" onClick={handleClaim}>
                    Redeem Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="point-history" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Points History</CardTitle>
              <CardDescription>Track your reward points activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { type: "Earned", desc: "Credit Card Purchase", points: "+250", date: "24 Mar 2025" },
                  { type: "Redeemed", desc: "Amazon Gift Card", points: "-2,000", date: "20 Mar 2025" },
                  { type: "Earned", desc: "Debit Card Purchase", points: "+150", date: "18 Mar 2025" },
                  { type: "Earned", desc: "Bill Payment", points: "+100", date: "15 Mar 2025" },
                  { type: "Earned", desc: "Welcome Bonus", points: "+1,000", date: "10 Mar 2025" },
                  { type: "Redeemed", desc: "Movie Tickets", points: "-1,500", date: "05 Mar 2025" },
                  { type: "Expired", desc: "Monthly Expiry", points: "-100", date: "01 Mar 2025" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                        <Clock className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{item.desc}</p>
                        <p className="text-xs text-muted-foreground">{item.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${item.points.startsWith("+") ? "text-green-600" : "text-red-500"}`}>
                        {item.points} points
                      </p>
                      <p className="text-xs text-muted-foreground">{item.type}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="benefits" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Reward Benefits</CardTitle>
              <CardDescription>Benefits based on your current tier</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-6">
                <div className="h-12 w-12 rounded-full bg-amber-100 flex items-center justify-center">
                  <Award className="h-6 w-6 text-amber-600" />
                </div>
                <div>
                  <p className="font-medium">Bronze Tier</p>
                  <p className="text-sm text-muted-foreground">Your current tier</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <p className="font-medium mb-1">Accelerated Points Earning</p>
                  <p className="text-sm text-muted-foreground">Earn 1 point for every ₹100 spent using your Vyom Bank cards</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="font-medium mb-1">Airport Lounge Access</p>
                  <p className="text-sm text-muted-foreground">Redeem points for complimentary domestic airport lounge access</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="font-medium mb-1">Birthday Bonus</p>
                  <p className="text-sm text-muted-foreground">Earn 500 bonus points on your birthday month</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <p className="font-medium mb-1">Movie Ticket Discounts</p>
                  <p className="text-sm text-muted-foreground">Get 10% off on movie tickets booked through our partners</p>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium mb-4">Next Tier Benefits</h3>
                <div className="p-4 border rounded-lg border-dashed">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-9 w-9 rounded-full bg-slate-100 flex items-center justify-center">
                      <Award className="h-5 w-5 text-slate-600" />
                    </div>
                    <div>
                      <p className="font-medium">Silver Tier</p>
                      <p className="text-sm text-muted-foreground">Unlock at 5,000 points</p>
                    </div>
                  </div>
                  
                  <ul className="space-y-2 pl-5 list-disc text-sm text-muted-foreground">
                    <li>Earn 2 points for every ₹100 spent</li>
                    <li>Priority customer service</li>
                    <li>Quarterly fee waivers on selected services</li>
                    <li>Complimentary card protection insurance</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

// Need to define Badge component for this page to work
const Badge = ({ children, className }: { children: React.ReactNode, className?: string }) => {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}>
      {children}
    </span>
  );
};

export default Rewards;
