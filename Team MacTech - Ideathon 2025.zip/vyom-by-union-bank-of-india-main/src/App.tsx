import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import UserDashboard from "./pages/UserDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/NotFound";
import Features from "./pages/Features";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ForgotPassword from "./pages/ForgotPassword";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import { LanguageProvider } from "./components/LanguageToggle";
import UserProfileForm from "./pages/UserProfileForm";

// Service Pages
import PersonalBanking from "./pages/services/PersonalBanking";
import BusinessBanking from "./pages/services/BusinessBanking";
import Loans from "./pages/services/Loans";
import Investments from "./pages/services/Investments";
import Insurance from "./pages/services/Insurance";

// Dashboard Features
import Cards from "./pages/dashboard/Cards";
import Transfers from "./pages/dashboard/Transfers";
import Statement from "./pages/dashboard/Statement";
import BHIMUPI from "./pages/dashboard/BHIMUPI";
import ScanQR from "./pages/dashboard/ScanQR";
import MPassbook from "./pages/dashboard/mPassbook";
import Rewards from "./pages/dashboard/Rewards";
import AllOffers from "./pages/dashboard/AllOffers";
import ApplyOffer from "./pages/dashboard/ApplyOffer";
import TransactionHistory from "./pages/dashboard/TransactionHistory";
import SecurityCenter from "./pages/dashboard/SecurityCenter";
import CardManagement from "./pages/dashboard/CardManagement";
import QuickPay from "./pages/dashboard/QuickPay";
import FinancialInsights from "./pages/dashboard/FinancialInsights";
import InternationalTransactions from "./pages/dashboard/InternationalTransactions";
import InternationalTransfers from "./pages/dashboard/InternationalTransfers";

// Create a client
const queryClient = new QueryClient();

// ScrollToTop component to scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <ScrollToTop />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/dashboard" element={<UserDashboard />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/features" element={<Features />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/privacy-policy" element={<PrivacyPolicy />} />
              <Route path="/terms-of-service" element={<TermsOfService />} />
              
              {/* Service Routes */}
              <Route path="/services/personal-banking" element={<PersonalBanking />} />
              <Route path="/services/business-banking" element={<BusinessBanking />} />
              <Route path="/services/loans" element={<Loans />} />
              <Route path="/services/investments" element={<Investments />} />
              <Route path="/services/insurance" element={<Insurance />} />
              
              {/* Dashboard Feature Routes */}
              <Route path="/dashboard/cards" element={<Cards />} />
              <Route path="/dashboard/transfers" element={<Transfers />} />
              <Route path="/dashboard/statement" element={<Statement />} />
              <Route path="/dashboard/bhim-upi" element={<BHIMUPI />} />
              <Route path="/dashboard/scan-qr" element={<ScanQR />} />
              <Route path="/dashboard/mpassbook" element={<MPassbook />} />
              <Route path="/dashboard/rewards" element={<Rewards />} />
              <Route path="/dashboard/all-offers" element={<AllOffers />} />
              <Route path="/dashboard/apply-offer" element={<ApplyOffer />} />
              <Route path="/dashboard/transactions" element={<TransactionHistory />} />
              <Route path="/dashboard/security" element={<SecurityCenter />} />
              <Route path="/dashboard/cards-management" element={<CardManagement />} />
              <Route path="/dashboard/quick-pay" element={<QuickPay />} />
              <Route path="/dashboard/insights" element={<FinancialInsights />} />
              <Route path="/dashboard/international" element={<InternationalTransactions />} />
              <Route path="/dashboard/international-transfers" element={<InternationalTransfers />} />
              
              <Route path="/profile-form" element={<UserProfileForm />} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
};

export default App;
