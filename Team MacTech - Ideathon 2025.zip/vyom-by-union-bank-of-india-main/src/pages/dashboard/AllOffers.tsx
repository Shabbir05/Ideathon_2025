
import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Gift, Tag, Clock, ArrowRight, CreditCard, Home, Plane, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

const AllOffers = () => {
  const { toast } = useToast();
  
  const handleApply = (offerName: string) => {
    toast({
      title: "Offer Applied",
      description: `You've successfully applied for ${offerName}.`
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">All Offers</h1>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="flex flex-wrap">
          <TabsTrigger value="all">All Offers</TabsTrigger>
          <TabsTrigger value="cards">Card Offers</TabsTrigger>
          <TabsTrigger value="loans">Loan Offers</TabsTrigger>
          <TabsTrigger value="travel">Travel</TabsTrigger>
          <TabsTrigger value="shopping">Shopping</TabsTrigger>
          <TabsTrigger value="exclusive">Exclusive</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Zero Processing Fee on Home Loans",
                description: "Limited-time offer valid till April 30, 2025. Apply now to save up to ₹25,000 on processing fees.",
                category: "Loan",
                expiryDate: "30 Apr 2025",
                icon: <Home className="h-5 w-5 text-green-600" />
              },
              {
                title: "5% Cashback on Credit Card Spends",
                description: "Get 5% cashback on all your credit card spends above ₹10,000 in a single transaction.",
                category: "Card",
                expiryDate: "15 Apr 2025",
                icon: <CreditCard className="h-5 w-5 text-blue-600" />
              },
              {
                title: "Travel Voucher Worth ₹2,500",
                description: "Open a Platinum Savings Account and get travel vouchers worth ₹2,500 to use on your next trip.",
                category: "Travel",
                expiryDate: "20 May 2025",
                icon: <Plane className="h-5 w-5 text-purple-600" />
              },
              {
                title: "10% Off on Gold Loan Interest Rate",
                description: "Avail a 10% reduction in interest rates on all new gold loans. Minimum loan amount ₹1 lakh.",
                category: "Loan",
                expiryDate: "10 Apr 2025",
                icon: <Tag className="h-5 w-5 text-amber-600" />
              },
              {
                title: "Free Movie Tickets on Debit Card",
                description: "Get 2 free movie tickets on spending ₹5,000 or more using your Vyom debit card.",
                category: "Card",
                expiryDate: "25 Apr 2025",
                icon: <Gift className="h-5 w-5 text-red-600" />
              },
              {
                title: "Shopping Vouchers on New FD",
                description: "Open a fixed deposit of ₹1 lakh or more and get shopping vouchers worth ₹1,000.",
                category: "Shopping",
                expiryDate: "30 Apr 2025",
                icon: <ShoppingBag className="h-5 w-5 text-teal-600" />
              },
            ].map((offer, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                      {offer.icon}
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Valid till {offer.expiryDate}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{offer.title}</CardTitle>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary mt-2">
                    {offer.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{offer.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View Details
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleApply(offer.title)}
                  >
                    Apply Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="cards" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "5% Cashback on Credit Card Spends",
                description: "Get 5% cashback on all your credit card spends above ₹10,000 in a single transaction.",
                expiryDate: "15 Apr 2025"
              },
              {
                title: "Free Movie Tickets on Debit Card",
                description: "Get 2 free movie tickets on spending ₹5,000 or more using your Vyom debit card.",
                expiryDate: "25 Apr 2025"
              },
              {
                title: "50% Off on Credit Card Annual Fee",
                description: "Apply for a new Vyom Platinum Credit Card and get 50% off on the first year annual fee.",
                expiryDate: "30 Apr 2025"
              },
            ].map((offer, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="h-9 w-9 rounded-full bg-blue-100 flex items-center justify-center">
                      <CreditCard className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Valid till {offer.expiryDate}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{offer.title}</CardTitle>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-600 mt-2">
                    Card
                  </span>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{offer.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View Details
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => handleApply(offer.title)}
                  >
                    Apply Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="loans" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Zero Processing Fee on Home Loans",
                description: "Limited-time offer valid till April 30, 2025. Apply now to save up to ₹25,000 on processing fees.",
                expiryDate: "30 Apr 2025"
              },
              {
                title: "10% Off on Gold Loan Interest Rate",
                description: "Avail a 10% reduction in interest rates on all new gold loans. Minimum loan amount ₹1 lakh.",
                expiryDate: "10 Apr 2025"
              },
              {
                title: "Personal Loan at 10.99%",
                description: "Special offer for existing customers. Get personal loans at a reduced interest rate of 10.99%.",
                expiryDate: "15 May 2025"
              },
            ].map((offer, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="h-9 w-9 rounded-full bg-green-100 flex items-center justify-center">
                      <Home className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Valid till {offer.expiryDate}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{offer.title}</CardTitle>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-600 mt-2">
                    Loan
                  </span>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{offer.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View Details
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => handleApply(offer.title)}
                  >
                    Apply Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="travel" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Travel Voucher Worth ₹2,500",
                description: "Open a Platinum Savings Account and get travel vouchers worth ₹2,500 to use on your next trip.",
                expiryDate: "20 May 2025"
              },
              {
                title: "5X Reward Points on Travel",
                description: "Get 5X reward points on all travel bookings made using your Vyom credit card.",
                expiryDate: "30 Apr 2025"
              },
              {
                title: "Complimentary Airport Lounge Access",
                description: "Get 2 complimentary domestic airport lounge access on spending ₹50,000 or more in a month.",
                expiryDate: "15 Jun 2025"
              },
            ].map((offer, index) => (
              <Card key={index}>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <div className="h-9 w-9 rounded-full bg-purple-100 flex items-center justify-center">
                      <Plane className="h-5 w-5 text-purple-600" />
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span>Valid till {offer.expiryDate}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{offer.title}</CardTitle>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-600 mt-2">
                    Travel
                  </span>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{offer.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="ghost" size="sm" className="text-primary">
                    View Details
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => handleApply(offer.title)}
                  >
                    Apply Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="shopping" className="mt-6">
          {/* Shopping Offers Tab Content */}
          <Card>
            <CardHeader>
              <CardTitle>Shopping Offers</CardTitle>
              <CardDescription>Special discounts and offers for your shopping needs</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Coming soon! We're preparing exciting shopping offers for you.</p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="exclusive" className="mt-6">
          {/* Exclusive Offers Tab Content */}
          <Card>
            <CardHeader>
              <CardTitle>Exclusive Offers</CardTitle>
              <CardDescription>Special offers exclusively for select customers</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Coming soon! We're preparing exclusive offers for our premium customers.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="mt-10 p-6 border rounded-lg bg-accent">
        <h2 className="text-xl font-bold mb-3">Looking for something specific?</h2>
        <p className="text-muted-foreground mb-4">
          Our team is ready to help you find the perfect offer for your financial needs.
        </p>
        <Button className="flex items-center gap-2">
          <span>Contact Us</span>
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default AllOffers;
