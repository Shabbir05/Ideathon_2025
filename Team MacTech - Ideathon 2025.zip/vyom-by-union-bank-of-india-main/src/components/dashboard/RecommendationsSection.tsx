
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { CreditCard, Home, LineChart, Shield, ArrowRight, RefreshCw } from "lucide-react";

interface Recommendation {
  id: string;
  recommended_product: string;
  recommendation_reason: string;
  created_at: string;
}

export const RecommendationsSection = () => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { toast } = useToast();

  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      
      const { data: userSession } = await supabase.auth.getSession();
      if (!userSession.session?.user?.id) {
        toast({
          title: "Authentication Error",
          description: "Please log in to view your recommendations",
          variant: "destructive",
        });
        setLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('user_recommendations')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error("Error fetching recommendations:", error);
        toast({
          title: "Error",
          description: "Failed to load recommendations",
          variant: "destructive",
        });
      } else {
        setRecommendations(data || []);
      }
    } catch (error) {
      console.error("Error in fetchRecommendations:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const refreshRecommendations = async () => {
    try {
      setRefreshing(true);
      
      const { data: userSession } = await supabase.auth.getSession();
      if (!userSession.session?.user?.id) {
        toast({
          title: "Authentication Error",
          description: "Please log in to refresh your recommendations",
          variant: "destructive",
        });
        setRefreshing(false);
        return;
      }

      const userId = userSession.session.user.id;
      
      // Call the edge function to generate new recommendations
      const { data, error } = await supabase.functions.invoke('generate-recommendations', {
        body: { userId },
      });

      if (error) {
        console.error("Error invoking function:", error);
        toast({
          title: "Error",
          description: "Failed to generate new recommendations",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: "Your recommendations have been updated",
        });
        // Refresh the list of recommendations
        fetchRecommendations();
      }
    } catch (error) {
      console.error("Error in refreshRecommendations:", error);
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const getIconForProduct = (product: string) => {
    if (product.toLowerCase().includes("credit card")) {
      return <CreditCard className="h-10 w-10 text-vyom-purple" />;
    } else if (product.toLowerCase().includes("loan")) {
      return <Home className="h-10 w-10 text-vyom-blue" />;
    } else if (product.toLowerCase().includes("investment")) {
      return <LineChart className="h-10 w-10 text-vyom-teal" />;
    } else if (product.toLowerCase().includes("insurance")) {
      return <Shield className="h-10 w-10 text-vyom-green" />;
    } else {
      return <CreditCard className="h-10 w-10 text-vyom-blue" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-vyom-blue">Personalized Recommendations</h2>
          <p className="text-gray-500">Financial products selected just for you based on your profile and spending habits</p>
        </div>
        <Button 
          onClick={refreshRecommendations} 
          disabled={refreshing}
          className="flex gap-2 items-center"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Refreshing...' : 'Refresh'}
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="overflow-hidden">
              <CardHeader className="pb-2">
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-24 w-full" />
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : recommendations.length === 0 ? (
        <Card className="p-6 text-center">
          <div className="mb-4">
            <LineChart className="h-12 w-12 mx-auto text-vyom-blue opacity-50" />
          </div>
          <h3 className="text-lg font-medium mb-2">No recommendations yet</h3>
          <p className="text-gray-500 mb-4">
            We need more information about your financial habits to create personalized recommendations.
          </p>
          <Button onClick={refreshRecommendations} disabled={refreshing}>
            Generate Recommendations
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {recommendations.map((rec) => {
            const [productType, specificType] = rec.recommended_product.split(': ');
            
            return (
              <Card key={rec.id} className="overflow-hidden hover:shadow-md transition-shadow">
                <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-teal" />
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-vyom-blue">{specificType || rec.recommended_product}</CardTitle>
                      <CardDescription>{productType}</CardDescription>
                    </div>
                    <div>
                      {getIconForProduct(rec.recommended_product)}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{rec.recommendation_reason}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Learn More <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
