
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { 
  BanknoteIcon, 
  LineChart, 
  ShieldCheck, 
  CreditCard, 
  Landmark, 
  Headphones,
  Globe,
  Building2,
  ChevronRight,
  MapPin,
  QrCode,
  InfoIcon
} from "lucide-react";
import { ReactNode } from "react";

interface Service {
  id: number;
  name: string;
  icon: ReactNode;
  description: string;
  link: string;
  features: string[];
}

interface ServicesSectionProps {
  navigate: (path: string) => void;
}

export const ServicesSection = ({ navigate }: ServicesSectionProps) => {
  const services: Service[] = [
    { 
      id: 1, 
      name: "Personal Loan", 
      icon: <BanknoteIcon className="text-vyom-purple h-12 w-12" />, 
      description: "Get instant loans up to ₹15 Lakhs", 
      link: "/services/loans",
      features: ["Competitive interest rates", "Quick approval", "Minimal documentation"]
    },
    { 
      id: 2, 
      name: "Mutual Funds", 
      icon: <LineChart className="text-vyom-teal h-12 w-12" />, 
      description: "Start your investment journey", 
      link: "/services/investments",
      features: ["Diverse portfolio options", "SIP & lump sum investments", "Expert fund management"]
    },
    { 
      id: 3, 
      name: "Insurance", 
      icon: <ShieldCheck className="text-vyom-blue h-12 w-12" />, 
      description: "Protect yourself and your family", 
      link: "/services/insurance",
      features: ["Life, health & general insurance", "Affordable premiums", "Hassle-free claims"]
    },
    { 
      id: 4, 
      name: "Credit Card", 
      icon: <CreditCard className="text-vyom-red h-12 w-12" />, 
      description: "Apply for premium credit cards", 
      link: "/dashboard/cards",
      features: ["Reward points", "Exclusive offers", "Travel benefits"]
    },
    { 
      id: 5, 
      name: "Fixed Deposit", 
      icon: <Landmark className="text-vyom-gray h-12 w-12" />, 
      description: "Secure investments with great returns", 
      link: "/services/investments",
      features: ["Guaranteed returns", "Flexible tenures", "Tax benefits"]
    },
    { 
      id: 6, 
      name: "Customer Support", 
      icon: <Headphones className="text-vyom-green h-12 w-12" />, 
      description: "24/7 assistance for all your needs", 
      link: "/contact",
      features: ["24/7 support", "Video KYC", "Doorstep service"]
    }
  ];

  const handleServiceClick = (link: string) => {
    navigate(link);
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map(service => (
          <Card
            key={service.id}
            className="overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer"
            onClick={() => handleServiceClick(service.link)}
          >
            <div className="h-1 bg-gradient-to-r from-vyom-blue to-vyom-teal" />
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <CardTitle className="text-xl mb-1">{service.name}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </div>
                <div className="ml-4">{service.icon}</div>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 mt-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="mt-1 h-2 w-2 rounded-full bg-vyom-blue shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Button
                className="w-full mt-4"
                variant={service.id % 2 === 0 ? "secondary" : "default"}
                onClick={() => handleServiceClick(service.link)}
              >
                Learn More
                <ChevronRight size={16} />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="overflow-hidden bg-gradient-to-r from-vyom-blue to-vyom-purple text-white">
          <CardHeader>
            <CardTitle>Premium Banking Services</CardTitle>
            <CardDescription className="text-white/80">
              Exclusive benefits for premium customers
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p>Enjoy premium banking privileges with personalized services, preferential rates, and exclusive offers.</p>
              <div className="flex flex-wrap gap-2 mt-4">
                <Badge className="bg-white/20 hover:bg-white/30">Relationship Manager</Badge>
                <Badge className="bg-white/20 hover:bg-white/30">Priority Service</Badge>
                <Badge className="bg-white/20 hover:bg-white/30">Global Access</Badge>
                <Badge className="bg-white/20 hover:bg-white/30">Premium Cards</Badge>
              </div>
              <Button 
                variant="contact" 
                className="mt-4"
                onClick={() => {
                  toast({
                    title: "Premium Banking",
                    description: "We'll contact you shortly to discuss premium banking options.",
                  });
                }}
              >
                Contact Us
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Need Assistance?</CardTitle>
            <CardDescription>
              Our support team is available 24/7 to help you
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col items-center justify-center p-4 rounded-lg border">
                  <Headphones className="h-8 w-8 text-vyom-blue mb-2" />
                  <h3 className="font-medium text-center">Call Support</h3>
                  <p className="text-sm text-vyom-gray text-center">1800-123-4567</p>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg border">
                  <QrCode className="h-8 w-8 text-vyom-purple mb-2" />
                  <h3 className="font-medium text-center">Video KYC</h3>
                  <p className="text-sm text-vyom-gray text-center">Schedule Now</p>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex flex-col items-center justify-center p-4 rounded-lg border">
                  <MapPin className="h-8 w-8 text-vyom-red mb-2" />
                  <h3 className="font-medium text-center">Find Branch</h3>
                  <p className="text-sm text-vyom-gray text-center">Locate Nearest</p>
                </div>
                <div className="flex flex-col items-center justify-center p-4 rounded-lg border">
                  <InfoIcon className="h-8 w-8 text-vyom-green mb-2" />
                  <h3 className="font-medium text-center">FAQs</h3>
                  <p className="text-sm text-vyom-gray text-center">Get Answers</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
