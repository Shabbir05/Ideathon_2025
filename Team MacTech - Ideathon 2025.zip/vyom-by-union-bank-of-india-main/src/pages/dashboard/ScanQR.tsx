
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Camera, Upload, RefreshCw, QrCode } from "lucide-react";
import { Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";

const ScanQR = () => {
  const { toast } = useToast();
  const [isScanning, setIsScanning] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [amount, setAmount] = useState("");
  
  const handleStartScan = () => {
    setIsScanning(true);
    
    // Simulate QR code detection after 3 seconds
    setTimeout(() => {
      setIsScanning(false);
      setShowPaymentForm(true);
      toast({
        title: "QR Code Detected",
        description: "Ready to pay to Rahul Sharma (rahul@okbank)",
      });
    }, 3000);
  };
  
  const handleUpload = () => {
    // Simulate upload and processing
    toast({
      title: "Processing QR Code",
      description: "Please wait while we process the image",
    });
    
    setTimeout(() => {
      setShowPaymentForm(true);
      toast({
        title: "QR Code Detected",
        description: "Ready to pay to Priya Patel (priya@upibank)",
      });
    }, 2000);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Payment Successful",
      description: `₹${amount} has been sent successfully.`,
    });
    setShowPaymentForm(false);
    setAmount("");
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">Scan QR Code</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Scan to Pay</CardTitle>
            <CardDescription>Scan any UPI QR code to make payments</CardDescription>
          </CardHeader>
          <CardContent>
            {!showPaymentForm ? (
              <div className="flex flex-col items-center">
                <div className="relative w-full max-w-sm aspect-square border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center mb-6">
                  {isScanning ? (
                    <>
                      <div className="absolute inset-4 border-2 border-vyom-blue animate-pulse"></div>
                      <RefreshCw className="h-16 w-16 text-vyom-blue animate-spin" />
                    </>
                  ) : (
                    <QrCode className="h-24 w-24 text-vyom-gray opacity-50" />
                  )}
                </div>
                
                <div className="flex flex-wrap gap-4 justify-center">
                  <Button 
                    onClick={handleStartScan}
                    disabled={isScanning}
                    className="flex items-center gap-2"
                  >
                    <Camera className="h-4 w-4" />
                    {isScanning ? "Scanning..." : "Start Scanning"}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={handleUpload}
                    className="flex items-center gap-2"
                  >
                    <Upload className="h-4 w-4" />
                    Upload QR Code
                  </Button>
                </div>
                
                <Separator className="my-6" />
                
                <div className="text-center text-muted-foreground text-sm">
                  <p>Position the QR code within the scanner frame</p>
                  <p>The payment details will appear automatically</p>
                </div>
              </div>
            ) : (
              <div>
                <div className="bg-accent p-4 rounded-lg mb-6">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-medium">RS</span>
                    </div>
                    <div>
                      <p className="font-medium">Rahul Sharma</p>
                      <p className="text-sm text-muted-foreground">rahul@okbank</p>
                    </div>
                  </div>
                </div>
                
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="amount" className="text-sm font-medium">Amount (₹)</label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="note" className="text-sm font-medium">Note (Optional)</label>
                    <Input id="note" placeholder="Add a note" />
                  </div>
                  
                  <div className="flex gap-3">
                    <Button type="submit" className="flex-1">Pay Now</Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowPaymentForm(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </form>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Scan QR Code Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-medium">1</span>
                </div>
                <div>
                  <p className="font-medium">Always Verify Details</p>
                  <p className="text-sm text-muted-foreground">
                    Check the name and UPI ID before making a payment to ensure you're paying the right person.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-medium">2</span>
                </div>
                <div>
                  <p className="font-medium">Adequate Lighting</p>
                  <p className="text-sm text-muted-foreground">
                    Ensure the QR code is in a well-lit area for better scanning.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-medium">3</span>
                </div>
                <div>
                  <p className="font-medium">Stable Position</p>
                  <p className="text-sm text-muted-foreground">
                    Hold your phone steady while scanning to get better results.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="font-medium">4</span>
                </div>
                <div>
                  <p className="font-medium">Security First</p>
                  <p className="text-sm text-muted-foreground">
                    Only scan QR codes from trusted merchants or individuals.
                  </p>
                </div>
              </div>
              
              <Separator className="my-4" />
              
              <div className="p-4 bg-yellow-50 rounded-lg">
                <p className="font-medium text-amber-800 mb-1">Security Alert</p>
                <p className="text-sm text-amber-700">
                  Be cautious of QR codes in unsolicited messages or suspicious locations. 
                  Scammers may use QR codes to redirect you to malicious sites.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default ScanQR;
