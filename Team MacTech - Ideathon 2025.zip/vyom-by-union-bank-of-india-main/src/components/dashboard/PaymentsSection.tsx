
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { toast } from "@/hooks/use-toast";
import { Plus, Send, Smartphone, CreditCard, AlertCircle, Wifi } from "lucide-react";
import { Account } from "./AccountsSection";
import { AddContactDialog } from "../payments/AddContactDialog";
import { AddPaymentMethodDialog } from "../payments/AddPaymentMethodDialog";
import { AddBillerDialog } from "../payments/AddBillerDialog";
import { PayBillDialog } from "../payments/PayBillDialog";

export interface Contact {
  id: number;
  name: string;
  mobile: string;
}

export interface PaymentMethod {
  id: number;
  type: string;
  linkedTo: string;
  lastUsed: string;
}

export interface Biller {
  id: number;
  name: string;
  category: string;
  lastPaid: string;
}

const transferSchema = z.object({
  fromAccount: z.string(),
  transferMode: z.string(),
  recipient: z.string().min(1, "Recipient is required"),
  amount: z.string().min(1, "Amount is required"),
  note: z.string().optional(),
});

type TransferFormValues = z.infer<typeof transferSchema>;

interface PaymentsSectionProps {
  accounts: Account[];
}

export const PaymentsSection = ({ accounts }: PaymentsSectionProps) => {
  const [showAddContactDialog, setShowAddContactDialog] = useState(false);
  const [showAddPaymentMethodDialog, setShowAddPaymentMethodDialog] = useState(false);
  const [showAddBillerDialog, setShowAddBillerDialog] = useState(false);
  const [showPayBillDialog, setShowPayBillDialog] = useState(false);
  const [isTransferring, setIsTransferring] = useState(false);
  const [selectedBill, setSelectedBill] = useState<{ name: string; amount: string; dueDate?: string } | null>(null);
  const [activePaymentMethod, setActivePaymentMethod] = useState<number | null>(null);
  
  const [contacts, setContacts] = useState([
    { id: 1, name: "Rahul", mobile: "9876543210" },
    { id: 2, name: "Priya", mobile: "9876543211" },
    { id: 3, name: "Ajay", mobile: "9876543212" }
  ]);
  
  const [paymentMethods, setPaymentMethods] = useState([
    { id: 1, type: "UPI", linkedTo: "9876543210@vyom", lastUsed: "Yesterday" },
    { id: 2, type: "Debit Card", linkedTo: "**** **** **** 5678", lastUsed: "2 days ago" },
    { id: 3, type: "Credit Card", linkedTo: "**** **** **** 9012", lastUsed: "1 week ago" }
  ]);
  
  const [billers, setBillers] = useState([
    { id: 1, name: "Electricity Board", category: "Utility", lastPaid: "15 May 2023" },
    { id: 2, name: "Broadband Service", category: "Internet", lastPaid: "2 Jun 2023" },
    { id: 3, name: "Mobile Recharge", category: "Telecom", lastPaid: "10 Jun 2023" }
  ]);

  const form = useForm<TransferFormValues>({
    resolver: zodResolver(transferSchema),
    defaultValues: {
      fromAccount: "Savings Account (₹157,892.45)",
      transferMode: "UPI",
      recipient: "",
      amount: "",
      note: "",
    },
  });

  const handleAddContact = (contact: { name: string; mobile: string }) => {
    const newContact = {
      id: contacts.length + 1,
      name: contact.name,
      mobile: contact.mobile
    };
    setContacts([...contacts, newContact]);
    toast({
      title: "Contact Added",
      description: `${contact.name} has been added to your contacts.`,
    });
  };

  const handleAddPaymentMethod = (method: { type: string; linkedTo: string }) => {
    const newMethod = {
      id: paymentMethods.length + 1,
      type: method.type,
      linkedTo: method.type === "Debit Card" || method.type === "Credit Card" 
        ? "**** **** **** " + method.linkedTo.slice(-4) 
        : method.linkedTo,
      lastUsed: "Just now"
    };
    setPaymentMethods([...paymentMethods, newMethod]);
    toast({
      title: "Payment Method Added",
      description: `${method.type} has been added to your payment methods.`,
    });
  };

  const handleAddBiller = (biller: { name: string; category: string }) => {
    const today = new Date();
    const formattedDate = `${today.getDate()} ${today.toLocaleString('default', { month: 'short' })} ${today.getFullYear()}`;
    
    const newBiller = {
      id: billers.length + 1,
      name: biller.name,
      category: biller.category,
      lastPaid: formattedDate
    };
    setBillers([...billers, newBiller]);
    toast({
      title: "Biller Added",
      description: `${biller.name} has been added to your billers.`,
    });
  };

  const handlePayBill = (name: string, amount: string, dueDate?: string) => {
    setSelectedBill({ name, amount, dueDate });
    setShowPayBillDialog(true);
  };

  const handleUsePaymentMethod = (methodId: number) => {
    const method = paymentMethods.find(method => method.id === methodId);
    if (method) {
      setActivePaymentMethod(methodId);
      
      form.setValue('transferMode', method.type);
      
      const updatedMethods = paymentMethods.map(m => 
        m.id === methodId 
          ? { ...m, lastUsed: "Just now" } 
          : m
      );
      setPaymentMethods(updatedMethods);
      
      toast({
        title: "Payment Method Selected",
        description: `${method.type} has been selected for your transaction.`,
      });
    }
  };

  const onSubmitTransfer = (values: TransferFormValues) => {
    setIsTransferring(true);
    
    const amount = parseFloat(values.amount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid amount greater than zero.",
        variant: "destructive",
      });
      setIsTransferring(false);
      return;
    }
    
    if (!values.recipient.trim()) {
      toast({
        title: "Invalid Recipient",
        description: "Please select or enter a valid recipient.",
        variant: "destructive",
      });
      setIsTransferring(false);
      return;
    }
    
    setTimeout(() => {
      toast({
        title: "Transfer Successful",
        description: `₹${values.amount} has been transferred to ${values.recipient}.`,
      });
      
      form.reset({
        fromAccount: "Savings Account (₹157,892.45)",
        transferMode: "UPI",
        recipient: "",
        amount: "",
        note: "",
      });
      
      setIsTransferring(false);
    }, 1500);
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column: Payment Methods */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl">Payment Methods</CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0" 
                  onClick={() => setShowAddPaymentMethodDialog(true)}
                >
                  <Plus size={16} />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {paymentMethods.map(method => (
                  <div 
                    key={method.id} 
                    className={`flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 cursor-pointer transition-all ${
                      activePaymentMethod === method.id ? "border-vyom-blue bg-blue-50" : ""
                    }`}
                    onClick={() => handleUsePaymentMethod(method.id)}
                  >
                    <div className="flex items-center gap-3">
                      {method.type === "UPI" && <Smartphone className="text-vyom-purple" size={20} />}
                      {method.type === "Debit Card" && <CreditCard className="text-vyom-blue" size={20} />}
                      {method.type === "Credit Card" && <CreditCard className="text-vyom-red" size={20} />}
                      <div>
                        <p className="text-sm font-medium">{method.type}</p>
                        <p className="text-xs text-vyom-gray">{method.linkedTo}</p>
                      </div>
                    </div>
                    <span className="text-xs text-vyom-gray">{method.lastUsed}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-xl">Contacts</CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 w-8 p-0" 
                  onClick={() => setShowAddContactDialog(true)}
                >
                  <Plus size={16} />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {contacts.map(contact => (
                  <div 
                    key={contact.id} 
                    className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 cursor-pointer transition-all"
                    onClick={() => {
                      form.setValue("recipient", contact.name);
                      toast({
                        title: "Contact Selected",
                        description: `${contact.name} has been selected for your transaction.`,
                      });
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center h-8 w-8 rounded-full bg-vyom-light text-vyom-blue font-medium">
                        {contact.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{contact.name}</p>
                        <p className="text-xs text-vyom-gray">{contact.mobile}</p>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7"
                      onClick={(e) => {
                        e.stopPropagation();
                        form.setValue("recipient", contact.name);
                        toast({
                          title: "Quick Pay",
                          description: `Set up payment to ${contact.name}`,
                        });
                      }}
                    >
                      <Send size={14} />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Middle column: Transfer Form */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Transfer Money</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmitTransfer)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fromAccount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From Account</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {accounts.filter(acc => acc.type !== "Credit Card").map(account => (
                            <SelectItem 
                              key={account.id} 
                              value={`${account.type} (₹${account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})`}
                            >
                              {account.type} (₹{account.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="transferMode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Transfer Mode</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select mode" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="UPI">UPI</SelectItem>
                          <SelectItem value="NEFT">NEFT</SelectItem>
                          <SelectItem value="RTGS">RTGS</SelectItem>
                          <SelectItem value="IMPS">IMPS</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="recipient"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Recipient</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter recipient name or select from contacts" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount (₹)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Enter amount" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="note"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Note (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="Add a note for this transaction" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full mt-4"
                  disabled={isTransferring}
                >
                  {isTransferring ? "Processing..." : "Transfer Money"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      {/* Bill Payments */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl">Bill Payments</CardTitle>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 w-8 p-0" 
              onClick={() => setShowAddBillerDialog(true)}
            >
              <Plus size={16} />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {billers.map(biller => (
              <div 
                key={biller.id} 
                className="p-4 rounded-lg border hover:shadow-md transition-all cursor-pointer"
                onClick={() => handlePayBill(biller.name, "0.00")}
              >
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-sm font-medium">{biller.name}</h3>
                    <p className="text-xs text-vyom-gray">{biller.category}</p>
                  </div>
                  {biller.category === "Utility" && <AlertCircle size={16} className="text-vyom-red" />}
                  {biller.category === "Internet" && <Wifi size={16} className="text-vyom-blue" />}
                  {biller.category === "Telecom" && <Smartphone size={16} className="text-vyom-purple" />}
                </div>
                <div className="flex items-center justify-between mt-3 pt-2 border-t">
                  <span className="text-xs text-vyom-gray">Last Paid: {biller.lastPaid}</span>
                  <Button variant="outline" size="sm" className="h-7 text-xs">
                    Pay Now
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      <AddContactDialog
        open={showAddContactDialog}
        onOpenChange={setShowAddContactDialog}
        onAdd={handleAddContact}
      />

      <AddPaymentMethodDialog
        open={showAddPaymentMethodDialog}
        onOpenChange={setShowAddPaymentMethodDialog}
        onAdd={handleAddPaymentMethod}
      />

      <AddBillerDialog
        open={showAddBillerDialog}
        onOpenChange={setShowAddBillerDialog}
        onAdd={handleAddBiller}
      />

      <PayBillDialog
        open={showPayBillDialog}
        onOpenChange={setShowPayBillDialog}
        bill={selectedBill}
      />
    </div>
  );
};
