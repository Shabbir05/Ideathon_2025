
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  CreditCard, 
  Lock, 
  ShieldCheck, 
  Globe, 
  Gauge, 
  Wallet, 
  PlusCircle,
  RefreshCw,
  Banknote,
  CalendarClock,
  BarChart
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Progress } from "@/components/ui/progress";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const CardManagement = () => {
  const navigate = useNavigate();
  const [cards, setCards] = useState([
    {
      id: 1,
      type: "Debit Card",
      name: "Vyom Platinum Debit Card",
      number: "**** **** **** 5678",
      expiryDate: "05/26",
      isBlocked: false,
      isInternationalEnabled: true,
      isContactlessEnabled: true,
      isOnlineTxnEnabled: true,
      spendLimit: {
        daily: 50000,
        monthly: 500000
      },
      usedLimit: {
        daily: 12500,
        monthly: 125000
      }
    },
    {
      id: 2,
      type: "Credit Card",
      name: "Vyom Signature Credit Card",
      number: "**** **** **** 9012",
      expiryDate: "08/25",
      isBlocked: false,
      isInternationalEnabled: false,
      isContactlessEnabled: true,
      isOnlineTxnEnabled: true,
      spendLimit: {
        daily: 100000,
        monthly: 1000000
      },
      usedLimit: {
        daily: 35000,
        monthly: 350000
      }
    }
  ]);

  const handleToggleCardSetting = (cardId: number, setting: string) => {
    setCards(cards.map(card => 
      card.id === cardId 
        ? { 
            ...card, 
            [setting]: !card[setting] 
          } 
        : card
    ));
    
    const card = cards.find(c => c.id === cardId);
    const settingValue = card ? !card[setting as keyof typeof card] : false;
    
    const settingName = setting === 'isBlocked' 
      ? 'Card Block'
      : setting === 'isInternationalEnabled' 
        ? 'International Transactions'
        : setting === 'isContactlessEnabled'
          ? 'Contactless Payments'
          : 'Online Transactions';
    
    toast({
      title: `${settingName} ${settingValue ? 'Enabled' : 'Disabled'}`,
      description: `${settingName} has been ${settingValue ? 'enabled' : 'disabled'} for your ${card?.name}.`,
    });
  };

  const calculateLimitPercentage = (used: number, total: number) => {
    return Math.min(Math.round((used / total) * 100), 100);
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => navigate("/dashboard")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-vyom-blue">Card Management</h1>
          <p className="text-vyom-gray">Manage and control all your banking cards</p>
        </div>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" /> Apply for New Card
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="col-span-1 md:col-span-2 space-y-6">
          {cards.map(card => (
            <Card key={card.id} className="shadow-md overflow-hidden border-none">
              <div className={`h-1 ${card.type === "Credit Card" ? "bg-vyom-red" : "bg-vyom-blue"}`}></div>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className={`h-5 w-5 ${card.type === "Credit Card" ? "text-vyom-red" : "text-vyom-blue"}`} />
                    {card.name}
                  </CardTitle>
                  <CardDescription>
                    {card.number} | Expires: {card.expiryDate}
                  </CardDescription>
                </div>
                <Badge variant={card.isBlocked ? "destructive" : "outline"} className={`
                  ${card.isBlocked 
                    ? "bg-red-50 text-vyom-red border-vyom-red/30" 
                    : "bg-green-50 text-vyom-green border-vyom-green/30"}
                `}>
                  {card.isBlocked ? "Blocked" : "Active"}
                </Badge>
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="bg-red-100 p-2 rounded-full">
                        <Lock className="h-4 w-4 text-vyom-red" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Block Card</p>
                        <p className="text-xs text-vyom-gray">Temporarily block your card</p>
                      </div>
                    </div>
                    <Switch 
                      checked={card.isBlocked} 
                      onCheckedChange={() => handleToggleCardSetting(card.id, 'isBlocked')}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 p-2 rounded-full">
                        <Globe className="h-4 w-4 text-vyom-blue" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">International Transactions</p>
                        <p className="text-xs text-vyom-gray">Use card abroad</p>
                      </div>
                    </div>
                    <Switch 
                      checked={card.isInternationalEnabled} 
                      onCheckedChange={() => handleToggleCardSetting(card.id, 'isInternationalEnabled')}
                      disabled={card.isBlocked}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-full">
                        <ShieldCheck className="h-4 w-4 text-vyom-purple" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Contactless Payments</p>
                        <p className="text-xs text-vyom-gray">Tap to pay feature</p>
                      </div>
                    </div>
                    <Switch 
                      checked={card.isContactlessEnabled} 
                      onCheckedChange={() => handleToggleCardSetting(card.id, 'isContactlessEnabled')}
                      disabled={card.isBlocked}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-3 rounded-lg border bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="bg-teal-100 p-2 rounded-full">
                        <Globe className="h-4 w-4 text-vyom-teal" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">Online Transactions</p>
                        <p className="text-xs text-vyom-gray">E-commerce purchases</p>
                      </div>
                    </div>
                    <Switch 
                      checked={card.isOnlineTxnEnabled} 
                      onCheckedChange={() => handleToggleCardSetting(card.id, 'isOnlineTxnEnabled')}
                      disabled={card.isBlocked}
                    />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h3 className="text-sm font-medium">Spending Limits</h3>
                  
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span>Daily Limit</span>
                      <span>₹{card.usedLimit.daily.toLocaleString()} / ₹{card.spendLimit.daily.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={calculateLimitPercentage(card.usedLimit.daily, card.spendLimit.daily)} 
                      className="h-2"
                    />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span>Monthly Limit</span>
                      <span>₹{card.usedLimit.monthly.toLocaleString()} / ₹{card.spendLimit.monthly.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={calculateLimitPercentage(card.usedLimit.monthly, card.spendLimit.monthly)} 
                      className="h-2"
                    />
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex flex-wrap justify-start gap-2 border-t p-4 bg-gray-50">
                <Button variant="outline" size="sm" className="text-xs">
                  <RefreshCw className="mr-1 h-3 w-3" /> Set Limits
                </Button>
                <Button variant="outline" size="sm" className="text-xs">
                  <Lock className="mr-1 h-3 w-3" /> Change PIN
                </Button>
                <Button variant="outline" size="sm" className="text-xs">
                  <RefreshCw className="mr-1 h-3 w-3" /> Report Lost
                </Button>
                {card.type === "Credit Card" && (
                  <Button variant="outline" size="sm" className="text-xs">
                    <Banknote className="mr-1 h-3 w-3" /> Pay Bill
                  </Button>
                )}
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="space-y-6">
          <Card className="shadow-md border-none overflow-hidden">
            <div className="h-1 bg-vyom-teal"></div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarClock className="h-5 w-5 text-vyom-teal" />
                Recent Card Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 rounded-lg border bg-gray-50">
                <p className="text-sm font-medium">Amazon Shopping</p>
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-vyom-gray">Today, 14:30 PM</p>
                  <p className="text-sm font-medium text-vyom-red">-₹3,540.50</p>
                </div>
                <Badge variant="outline" className="mt-2 text-xs bg-blue-50 text-vyom-blue border-vyom-blue/30">
                  Online Transaction
                </Badge>
              </div>
              
              <div className="p-3 rounded-lg border bg-gray-50">
                <p className="text-sm font-medium">Cafe Coffee Day</p>
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-vyom-gray">Yesterday, 11:15 AM</p>
                  <p className="text-sm font-medium text-vyom-red">-₹350.00</p>
                </div>
                <Badge variant="outline" className="mt-2 text-xs bg-purple-50 text-vyom-purple border-vyom-purple/30">
                  Contactless Payment
                </Badge>
              </div>
              
              <div className="p-3 rounded-lg border bg-gray-50">
                <p className="text-sm font-medium">Fuel Station</p>
                <div className="flex justify-between items-center mt-1">
                  <p className="text-xs text-vyom-gray">3 days ago, 09:45 AM</p>
                  <p className="text-sm font-medium text-vyom-red">-₹1,850.50</p>
                </div>
                <Badge variant="outline" className="mt-2 text-xs bg-gray-100 text-vyom-gray border-vyom-gray/30">
                  Chip Transaction
                </Badge>
              </div>
              
              <Button variant="link" className="w-full text-xs">View All Transactions</Button>
            </CardContent>
          </Card>
          
          <Card className="shadow-md border-none overflow-hidden">
            <div className="h-1 bg-vyom-purple"></div>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart className="h-5 w-5 text-vyom-purple" />
                Card Benefits
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-sm">Reward Points</AccordionTrigger>
                  <AccordionContent className="text-xs text-vyom-gray">
                    <p>Current Points: 5,420</p>
                    <p className="mt-1">Earn 2X points on all online transactions and 1X on all other spends.</p>
                    <Button variant="link" className="text-xs p-0 h-6 mt-1">Redeem Points</Button>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-sm">Airport Lounge Access</AccordionTrigger>
                  <AccordionContent className="text-xs text-vyom-gray">
                    <p>4 complimentary domestic airport lounge visits per quarter.</p>
                    <p className="mt-1">Used: 1/4 this quarter</p>
                    <Button variant="link" className="text-xs p-0 h-6 mt-1">View Eligible Lounges</Button>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-sm">Cashback Offers</AccordionTrigger>
                  <AccordionContent className="text-xs text-vyom-gray">
                    <p>5% cashback on movie ticket bookings</p>
                    <p className="mt-1">2% cashback on utility bill payments</p>
                    <p className="mt-1">1% cashback on all other transactions</p>
                    <Button variant="link" className="text-xs p-0 h-6 mt-1">View All Offers</Button>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-sm">Insurance Coverage</AccordionTrigger>
                  <AccordionContent className="text-xs text-vyom-gray">
                    <p>Complimentary travel insurance up to ₹50 Lakhs</p>
                    <p className="mt-1">Purchase protection up to ₹2 Lakhs</p>
                    <Button variant="link" className="text-xs p-0 h-6 mt-1">Learn More</Button>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CardManagement;
