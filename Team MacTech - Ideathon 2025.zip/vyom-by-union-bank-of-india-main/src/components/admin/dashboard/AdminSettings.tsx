
import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  UserCog, Shield, Lock, AlertTriangle, Database, RefreshCw, Settings, Users, 
  FileText, CheckSquare, BarChart, List, AlertCircle
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

// Mock data for admin roles
const adminRoles = [
  { 
    id: 1, 
    role: "Super Admin", 
    description: "Full system access with all privileges", 
    userCount: 3, 
    permissions: ["all"], 
    restricted: false 
  },
  { 
    id: 2, 
    role: "Compliance Officer", 
    description: "Access to compliance monitoring & reporting", 
    userCount: 5, 
    permissions: ["compliance_view", "compliance_edit", "reports_generate", "reports_view"], 
    restricted: false 
  },
  { 
    id: 3, 
    role: "Security Analyst", 
    description: "Access to security monitoring & configuration", 
    userCount: 7, 
    permissions: ["security_view", "security_edit", "mfa_manage", "user_activity_view"], 
    restricted: false 
  },
  { 
    id: 4, 
    role: "Customer Service Manager", 
    description: "Handle customer requests & issues", 
    userCount: 12, 
    permissions: ["requests_view", "requests_approve", "user_view"], 
    restricted: true 
  },
  { 
    id: 5, 
    role: "Audit Manager", 
    description: "Review logs and system activities", 
    userCount: 4, 
    permissions: ["audit_logs_view", "reports_view", "compliance_view"], 
    restricted: true 
  }
];

// Mock data for fraud detection rules
const fraudRules = [
  {
    id: 1,
    name: "Large Transaction Alert",
    description: "Flag transactions above certain amount",
    type: "Transaction",
    threshold: "₹200,000",
    action: "Flag for Review",
    status: "active"
  },
  {
    id: 2,
    name: "Rapid Successive Transactions",
    description: "Multiple transactions in short time frame",
    type: "Transaction",
    threshold: "5 transactions / 10 minutes",
    action: "Flag for Review",
    status: "active"
  },
  {
    id: 3,
    name: "International IP Login",
    description: "Login attempt from international IP",
    type: "Authentication",
    threshold: "Any international IP",
    action: "Enforce MFA",
    status: "active"
  },
  {
    id: 4,
    name: "Multiple Failed Login Attempts",
    description: "Repeated failed login attempts",
    type: "Authentication",
    threshold: "5 attempts / 15 minutes",
    action: "Lock Account",
    status: "active"
  },
  {
    id: 5,
    name: "Unusual Account Activity",
    description: "Activity outside normal patterns",
    type: "Behavioral",
    threshold: "Deviation Score > 0.8",
    action: "Flag for Review",
    status: "inactive"
  }
];

// Mock data for backup schedule
const backupSchedule = [
  {
    id: 1,
    type: "Full System Backup",
    frequency: "Daily",
    time: "02:00 AM IST",
    retention: "30 days",
    lastBackup: "2023-10-05 02:00:00",
    status: "success"
  },
  {
    id: 2,
    type: "Transaction Database",
    frequency: "Hourly",
    time: "Every hour",
    retention: "7 days",
    lastBackup: "2023-10-05 14:00:00",
    status: "success"
  },
  {
    id: 3,
    type: "User Database",
    frequency: "Daily",
    time: "03:00 AM IST",
    retention: "30 days",
    lastBackup: "2023-10-05 03:00:00",
    status: "success"
  },
  {
    id: 4,
    type: "Configuration Files",
    frequency: "Weekly",
    time: "Sunday, 01:00 AM IST",
    retention: "52 weeks",
    lastBackup: "2023-10-01 01:00:00",
    status: "success"
  },
  {
    id: 5,
    type: "Audit Logs",
    frequency: "Daily",
    time: "04:00 AM IST",
    retention: "365 days",
    lastBackup: "2023-10-05 04:00:00",
    status: "success"
  }
];

const AdminSettings = () => {
  const [autoFreeze, setAutoFreeze] = useState(true);
  const [criticalAlerts, setCriticalAlerts] = useState(true);
  const [autoBackup, setAutoBackup] = useState(true);
  
  const handleSaveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Your admin settings have been saved successfully.",
    });
  };
  
  const handleBackupNow = () => {
    toast({
      title: "Backup Initiated",
      description: "Manual backup has been started. You will be notified when complete.",
    });
  };
  
  const handleRestoreBackup = () => {
    toast({
      title: "Restore Initiated",
      description: "System restore has been initiated. This may take several minutes.",
      variant: "destructive"
    });
  };
  
  const handleToggleRule = (ruleId: number, enabled: boolean) => {
    toast({
      title: enabled ? "Rule Activated" : "Rule Deactivated",
      description: `Fraud detection rule ${ruleId} has been ${enabled ? "activated" : "deactivated"}.`,
    });
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="access" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="access">
            <UserCog className="h-4 w-4 mr-2" />
            Role-Based Access
          </TabsTrigger>
          <TabsTrigger value="fraud">
            <Shield className="h-4 w-4 mr-2" />
            Fraud Detection
          </TabsTrigger>
          <TabsTrigger value="incident">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Incident Response
          </TabsTrigger>
          <TabsTrigger value="backup">
            <Database className="h-4 w-4 mr-2" />
            Backup & Recovery
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="access">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCog className="h-5 w-5 text-vyom-blue" />
                Role-Based Access Control (RBAC)
              </CardTitle>
              <CardDescription>Configure admin roles and permission levels</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Role</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Users</TableHead>
                    <TableHead>Permissions</TableHead>
                    <TableHead>Restricted</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adminRoles.map((role) => (
                    <TableRow key={role.id}>
                      <TableCell className="font-medium">{role.role}</TableCell>
                      <TableCell>{role.description}</TableCell>
                      <TableCell>{role.userCount}</TableCell>
                      <TableCell>
                        {role.permissions.includes("all") ? (
                          <Badge className="bg-purple-100 text-purple-800 border-purple-200">All Permissions</Badge>
                        ) : (
                          <div className="flex flex-wrap gap-1">
                            {role.permissions.slice(0, 2).map((permission, index) => (
                              <Badge key={index} className="bg-blue-100 text-blue-800 border-blue-200">
                                {permission.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                              </Badge>
                            ))}
                            {role.permissions.length > 2 && (
                              <Badge className="bg-gray-100 text-gray-800 border-gray-200">
                                +{role.permissions.length - 2} more
                              </Badge>
                            )}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {role.restricted ? (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-200">Restricted</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Unrestricted</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="h-8 px-2 text-xs"
                          >
                            Edit Role
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="h-8 px-2 text-xs"
                          >
                            View Users
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="mt-4 flex justify-end">
                <Button>
                  <Users className="h-4 w-4 mr-2" />
                  Create New Role
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <List className="h-5 w-5 text-vyom-blue" />
                Admin Audit Logging
              </CardTitle>
              <CardDescription>Configuration for admin action logging</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Log All Admin Actions</h3>
                  <p className="text-sm text-vyom-gray">Record all administrative actions in the system audit log</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Extended Logging Detail</h3>
                  <p className="text-sm text-vyom-gray">Include detailed information about each admin action</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">IP Address Tracking</h3>
                  <p className="text-sm text-vyom-gray">Track IP addresses for all admin actions</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">Log Retention Period</h3>
                  <p className="text-sm text-vyom-gray">How long to retain detailed admin audit logs</p>
                </div>
                <select className="px-3 py-2 border rounded-md">
                  <option value="90">90 Days</option>
                  <option value="180">180 Days</option>
                  <option value="365" selected>365 Days</option>
                  <option value="730">2 Years</option>
                </select>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button variant="outline" className="mr-2">
                  <FileText className="h-4 w-4 mr-2" />
                  View Admin Logs
                </Button>
                <Button onClick={handleSaveSettings}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="fraud">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-vyom-blue" />
                Fraud Detection Rule Configuration
              </CardTitle>
              <CardDescription>Customize system rules for detecting suspicious activities</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rule Name</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Threshold</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Toggle</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fraudRules.map((rule) => (
                    <TableRow key={rule.id}>
                      <TableCell className="font-medium">{rule.name}</TableCell>
                      <TableCell>{rule.description}</TableCell>
                      <TableCell>
                        {rule.type === "Transaction" && (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Transaction</Badge>
                        )}
                        {rule.type === "Authentication" && (
                          <Badge className="bg-blue-100 text-blue-800 border-blue-200">Authentication</Badge>
                        )}
                        {rule.type === "Behavioral" && (
                          <Badge className="bg-purple-100 text-purple-800 border-purple-200">Behavioral</Badge>
                        )}
                      </TableCell>
                      <TableCell>{rule.threshold}</TableCell>
                      <TableCell>
                        {rule.action === "Flag for Review" && (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-200">Flag for Review</Badge>
                        )}
                        {rule.action === "Enforce MFA" && (
                          <Badge className="bg-blue-100 text-blue-800 border-blue-200">Enforce MFA</Badge>
                        )}
                        {rule.action === "Lock Account" && (
                          <Badge className="bg-red-100 text-red-800 border-red-200">Lock Account</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {rule.status === "active" ? (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Active</Badge>
                        ) : (
                          <Badge className="bg-gray-100 text-gray-800 border-gray-200">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Switch 
                          checked={rule.status === "active"} 
                          onCheckedChange={(checked) => handleToggleRule(rule.id, checked)}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="mt-4 flex justify-between">
                <Button variant="outline">
                  <BarChart className="h-4 w-4 mr-2" />
                  View Rule Performance
                </Button>
                <Button>
                  <Shield className="h-4 w-4 mr-2" />
                  Create New Rule
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-vyom-blue" />
                Fraud Detection Settings
              </CardTitle>
              <CardDescription>Global configurations for the fraud detection system</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">AI-Enhanced Detection</h3>
                  <p className="text-sm text-vyom-gray">Use machine learning algorithms to improve detection accuracy</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Behavioral Analysis</h3>
                  <p className="text-sm text-vyom-gray">Analyze user behavior patterns to detect anomalies</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Real-time Alerts</h3>
                  <p className="text-sm text-vyom-gray">Send immediate notifications for high-risk activities</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">Risk Sensitivity</h3>
                  <p className="text-sm text-vyom-gray">Adjust overall sensitivity of the fraud detection system</p>
                </div>
                <select className="px-3 py-2 border rounded-md">
                  <option value="low">Low (Fewer Alerts)</option>
                  <option value="medium" selected>Medium (Balanced)</option>
                  <option value="high">High (More Alerts)</option>
                  <option value="very-high">Very High (Maximum Security)</option>
                </select>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button onClick={handleSaveSettings}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="incident">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-vyom-blue" />
                Incident Response Automation
              </CardTitle>
              <CardDescription>Configure automated responses to security incidents</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Auto-Freeze Accounts</h3>
                  <p className="text-sm text-vyom-gray">Automatically freeze accounts in critical fraud cases</p>
                </div>
                <Switch 
                  checked={autoFreeze} 
                  onCheckedChange={setAutoFreeze}
                />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Critical Alert Notifications</h3>
                  <p className="text-sm text-vyom-gray">Send SMS/email to admin team for critical security incidents</p>
                </div>
                <Switch 
                  checked={criticalAlerts} 
                  onCheckedChange={setCriticalAlerts}
                />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Auto-Block Suspicious IPs</h3>
                  <p className="text-sm text-vyom-gray">Automatically block IPs involved in multiple suspicious activities</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Enforce Step-up Authentication</h3>
                  <p className="text-sm text-vyom-gray">Require additional authentication for suspicious sessions</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">Auto-Generate Incident Reports</h3>
                  <p className="text-sm text-vyom-gray">Automatically create detailed reports for each security incident</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mt-6">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-amber-800">Auto-Response Warning</h3>
                    <p className="text-sm text-amber-700 mt-1">
                      Automated responses may impact user experience. Enable with caution and monitor regularly for false positives.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button onClick={handleSaveSettings}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-vyom-blue" />
                Security Incident Response Team
              </CardTitle>
              <CardDescription>Configure notification settings for the security incident response team</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Role</TableHead>
                    <TableHead>Notification Method</TableHead>
                    <TableHead>Severity Threshold</TableHead>
                    <TableHead>On-Call</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Security Team Lead</TableCell>
                    <TableCell>SMS, Email, Phone Call</TableCell>
                    <TableCell>All Incidents</TableCell>
                    <TableCell>Yes (24/7)</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Fraud Analyst</TableCell>
                    <TableCell>SMS, Email</TableCell>
                    <TableCell>Medium & Critical</TableCell>
                    <TableCell>Business Hours</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">System Administrator</TableCell>
                    <TableCell>SMS, Email</TableCell>
                    <TableCell>High & Critical</TableCell>
                    <TableCell>Rotational</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Compliance Officer</TableCell>
                    <TableCell>Email</TableCell>
                    <TableCell>Critical Only</TableCell>
                    <TableCell>No</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
              <div className="mt-4 flex justify-end">
                <Button variant="outline">
                  Edit Team Configuration
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="backup">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-vyom-blue" />
                Backup Configuration
              </CardTitle>
              <CardDescription>System backup schedule and settings</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Backup Type</TableHead>
                    <TableHead>Frequency</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Retention</TableHead>
                    <TableHead>Last Backup</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {backupSchedule.map((backup) => (
                    <TableRow key={backup.id}>
                      <TableCell className="font-medium">{backup.type}</TableCell>
                      <TableCell>{backup.frequency}</TableCell>
                      <TableCell>{backup.time}</TableCell>
                      <TableCell>{backup.retention}</TableCell>
                      <TableCell>{new Date(backup.lastBackup).toLocaleString()}</TableCell>
                      <TableCell>
                        {backup.status === "success" && (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Success</Badge>
                        )}
                        {backup.status === "in_progress" && (
                          <Badge className="bg-blue-100 text-blue-800 border-blue-200">In Progress</Badge>
                        )}
                        {backup.status === "failed" && (
                          <Badge className="bg-red-100 text-red-800 border-red-200">Failed</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <div className="mt-4 flex justify-between">
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="auto-backup" 
                    checked={autoBackup} 
                    onCheckedChange={setAutoBackup}
                  />
                  <label htmlFor="auto-backup" className="text-sm font-medium leading-none">
                    Automatic scheduled backups
                  </label>
                </div>
                <div className="space-x-2">
                  <Button 
                    variant="outline"
                    onClick={handleBackupNow}
                  >
                    <Database className="h-4 w-4 mr-2" />
                    Backup Now
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={handleRestoreBackup}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Restore from Backup
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-vyom-blue" />
                Backup & Recovery Settings
              </CardTitle>
              <CardDescription>Configure backup storage and recovery options</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Encrypted Backups</h3>
                  <p className="text-sm text-vyom-gray">Encrypt all backup data for enhanced security</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Off-site Storage</h3>
                  <p className="text-sm text-vyom-gray">Store backups in secondary geographic location</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Compression</h3>
                  <p className="text-sm text-vyom-gray">Compress backup data to save storage space</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">Backup Storage Location</h3>
                  <p className="text-sm text-vyom-gray">Where backup data is stored</p>
                </div>
                <select className="px-3 py-2 border rounded-md">
                  <option value="cloud" selected>Cloud Storage (Primary)</option>
                  <option value="local">Local Server</option>
                  <option value="hybrid">Hybrid (Cloud + Local)</option>
                </select>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mt-6">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-medium text-blue-800">Disaster Recovery Plan</h3>
                    <p className="text-sm text-blue-700 mt-1">
                      A comprehensive disaster recovery plan is in place with an estimated recovery time of 4 hours.
                      Regular recovery drills are conducted quarterly.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button variant="outline" className="mr-2">
                  <FileText className="h-4 w-4 mr-2" />
                  View Backup Logs
                </Button>
                <Button onClick={handleSaveSettings}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminSettings;

