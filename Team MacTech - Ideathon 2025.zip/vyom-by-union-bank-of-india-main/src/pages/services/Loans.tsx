
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Check, Shield, Calculator, FileText, Coins, ChevronRight } from "lucide-react";
import LoanApplicationForm from "@/components/services/LoanApplicationForm";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { toast } from "@/hooks/use-toast";

const Loans = () => {
  const [showLoanForm, setShowLoanForm] = useState(false);
  const [loanType, setLoanType] = useState("Personal");

  const handleApplyNow = (type: string) => {
    setLoanType(type);
    setShowLoanForm(true);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow pt-24">
        {/* Hero Section */}
        <div className="relative bg-gradient-to-r from-vyom-blue to-vyom-teal text-white py-24">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Loans & Financing Solutions
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8">
                Get the financial support you need with our range of loan products designed for every stage of life.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  variant="default" 
                  size="lg" 
                  className="rounded-full"
                  onClick={() => {
                    setLoanType("Personal");
                    setShowLoanForm(true);
                  }}
                >
                  Apply Now <ArrowRight className="ml-2" />
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 rounded-full"
                  onClick={() => {
                    toast({
                      title: "Eligibility Check",
                      description: "Our eligibility checker will be available soon. Please apply directly or contact us for assistance.",
                    });
                  }}
                >
                  Check Eligibility
                </Button>
              </div>
            </div>
          </div>
          <div className="absolute bottom-0 left-0 w-full h-16 bg-white" style={{ clipPath: "polygon(0 100%, 100% 100%, 100% 0)" }}></div>
        </div>

        {/* Loan Types Section */}
        <div className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Explore Our Loan Products</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Home Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-red"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Home Loans</h3>
                  <p className="text-gray-600 mb-4">Make your dream home a reality with competitive interest rates and flexible repayment options.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 7.50% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Loan amount up to ₹5 crore</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Tenure up to 30 years</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Home")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
              
              {/* Personal Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-teal"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Personal Loans</h3>
                  <p className="text-gray-600 mb-4">Quick access to funds for your personal needs with minimal documentation.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 10.50% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Loan amount up to ₹25 lakhs</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Quick approval within 24 hours</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Personal")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
              
              {/* Business Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-purple"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Business Loans</h3>
                  <p className="text-gray-600 mb-4">Fuel your business growth with customized funding solutions.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 9.50% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Loan amount up to ₹2 crore</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Minimal collateral requirements</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Business")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
              
              {/* Education Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-blue"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Education Loans</h3>
                  <p className="text-gray-600 mb-4">Invest in your future with our education financing options.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 8.50% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Loan amount up to ₹75 lakhs for studies abroad</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Repayment starts after course completion</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Education")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
              
              {/* Car Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-teal"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Car Loans</h3>
                  <p className="text-gray-600 mb-4">Drive your dream car with our affordable auto financing.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 8.00% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Up to 100% financing on select models</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Flexible tenure options up to 7 years</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Car")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
              
              {/* Gold Loan */}
              <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="h-2 bg-vyom-red"></div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-vyom-blue">Gold Loans</h3>
                  <p className="text-gray-600 mb-4">Unlock the value of your gold with quick and secure loans.</p>
                  <ul className="space-y-2 mb-4">
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Interest rates starting at 7.00% p.a.</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Up to 75% of gold value as loan amount</span>
                    </li>
                    <li className="flex items-center gap-2 text-sm text-gray-600">
                      <Check size={16} className="text-vyom-teal" />
                      <span>Secure storage with insurance coverage</span>
                    </li>
                  </ul>
                  <Button 
                    variant="link" 
                    className="px-0 flex items-center"
                    onClick={() => handleApplyNow("Gold")}
                  >
                    Apply Now <ChevronRight size={16} className="ml-1" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Loan Calculator Section */}
        <div className="py-16 bg-vyom-light">
          <div className="container mx-auto px-4 md:px-6">
            <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
              <div className="flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                  <Calculator size={48} className="text-vyom-blue mb-4" />
                  <h3 className="text-2xl font-bold mb-4 text-vyom-blue">Loan Calculator</h3>
                  <p className="text-gray-600 mb-4">
                    Estimate your monthly payments and total interest costs with our easy-to-use loan calculator.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3">
                      <Shield className="text-vyom-teal" />
                      <span>Plan your finances with confidence</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <FileText className="text-vyom-teal" />
                      <span>Compare different loan scenarios</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <Coins className="text-vyom-teal" />
                      <span>Make informed borrowing decisions</span>
                    </li>
                  </ul>
                </div>
                <div className="md:w-1/2 bg-vyom-light p-6 rounded-lg">
                  <h4 className="font-semibold mb-4 text-center">Coming Soon</h4>
                  <p className="text-center text-gray-600 mb-4">Our interactive loan calculator is under development and will be available shortly.</p>
                  <Button 
                    variant="default" 
                    className="w-full"
                    onClick={() => {
                      toast({
                        title: "Notification Set",
                        description: "You'll be notified when our loan calculator becomes available. Thank you for your interest!",
                      });
                    }}
                  >
                    Get Notified When Available
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="bg-gradient-to-r from-vyom-blue to-vyom-teal rounded-xl text-white p-8 md:p-12 max-w-5xl mx-auto">
              <h2 className="text-3xl font-bold mb-4 text-center">Ready to Apply for a Loan?</h2>
              <p className="text-xl text-center mb-8">Get started with a simple application process and quick approval.</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  variant="default" 
                  size="lg"
                  onClick={() => {
                    setLoanType("Personal");
                    setShowLoanForm(true);
                  }}
                >
                  Apply Online Now
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="bg-white/10 border-white/20 hover:bg-white/20"
                  onClick={() => {
                    toast({
                      title: "Loan Advisor Request",
                      description: "A loan advisor will contact you shortly to discuss your loan requirements.",
                    });
                  }}
                >
                  Speak to a Loan Advisor
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Loan Application Form */}
        {showLoanForm && (
          <LoanApplicationForm loanType={loanType} onClose={() => setShowLoanForm(false)} />
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Loans;
