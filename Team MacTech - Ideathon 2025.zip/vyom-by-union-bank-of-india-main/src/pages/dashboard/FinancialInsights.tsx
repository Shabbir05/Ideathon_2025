
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import { 
  ArrowLeft, 
  BarChart3, 
  PieChart, 
  LineChart,
  TrendingUp,
  Download,
  Wallet,
  ShoppingCart,
  Home,
  Car,
  Coffee,
  Utensils,
  PlayCircle,
  Droplet,
  Sparkles,
  Calendar,
  DollarSign
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, 
  Bar, 
  PieChart as RechartsChart, 
  Pie, 
  Cell, 
  LineChart as RLineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";

const FinancialInsights = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("overview");
  const [timeframe, setTimeframe] = useState("monthly");
  
  // Weekly spending data
  const weeklySpendingData = [
    { name: 'Mon', amount: 1200 },
    { name: 'Tue', amount: 1800 },
    { name: 'Wed', amount: 1000 },
    { name: 'Thu', amount: 2200 },
    { name: 'Fri', amount: 1500 },
    { name: 'Sat', amount: 2500 },
    { name: 'Sun', amount: 1900 }
  ];

  // Category spending data
  const categorySpendingData = [
    { name: 'Shopping', value: 8500, fill: '#3b82f6', icon: <ShoppingCart size={16} /> },
    { name: 'Food', value: 5200, fill: '#10b981', icon: <Utensils size={16} /> },
    { name: 'Transport', value: 3800, fill: '#f59e0b', icon: <Car size={16} /> },
    { name: 'Bills', value: 6300, fill: '#ef4444', icon: <Home size={16} /> },
    { name: 'Entertainment', value: 2100, fill: '#8b5cf6', icon: <PlayCircle size={16} /> }
  ];

  // Monthly savings data
  const savingsData = [
    { month: 'Jan', amount: 35000 },
    { month: 'Feb', amount: 38000 },
    { month: 'Mar', amount: 37500 },
    { month: 'Apr', amount: 42000 },
    { month: 'May', amount: 45000 },
    { month: 'Jun', amount: 48000 }
  ];
  
  // Income vs Expenses
  const incomeVsExpensesData = [
    { month: 'Jan', income: 75000, expenses: 40000 },
    { month: 'Feb', income: 75000, expenses: 37000 },
    { month: 'Mar', income: 75000, expenses: 37500 },
    { month: 'Apr', income: 90000, expenses: 48000 },
    { month: 'May', income: 75000, expenses: 30000 },
    { month: 'Jun', income: 75000, expenses: 32500 }
  ];
  
  // Year-over-year comparison
  const yearComparisonData = [
    { month: 'Jan', current: 35000, previous: 32000 },
    { month: 'Feb', current: 38000, previous: 31000 },
    { month: 'Mar', current: 37500, previous: 33500 },
    { month: 'Apr', current: 42000, previous: 38000 },
    { month: 'May', current: 45000, previous: 40000 },
    { month: 'Jun', current: 48000, previous: 41000 }
  ];
  
  // Budget progress
  const budgetData = [
    { category: 'Shopping', limit: 10000, spent: 8500 },
    { category: 'Food', limit: 8000, spent: 5200 },
    { category: 'Transport', limit: 5000, spent: 3800 },
    { category: 'Bills', limit: 7000, spent: 6300 },
    { category: 'Entertainment', limit: 3000, spent: 2100 }
  ];

  const handleDownloadReport = () => {
    toast({
      title: "Report Downloaded",
      description: "Your financial insights report has been downloaded successfully.",
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <Button 
        variant="outline" 
        className="mb-6" 
        onClick={() => navigate("/dashboard")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
      </Button>
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-vyom-blue">Financial Insights</h1>
          <p className="text-vyom-gray">Analyze your spending patterns and financial health</p>
        </div>
        <div className="flex items-center gap-2">
          <select 
            className="p-2 border rounded-lg"
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
          >
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="yearly">Yearly</option>
          </select>
          <Button variant="outline" onClick={handleDownloadReport}>
            <Download className="mr-2 h-4 w-4" /> Download Report
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="spending">Spending</TabsTrigger>
          <TabsTrigger value="budget">Budget</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Income vs Expenses */}
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 size={18} className="text-vyom-blue" />
                  Income vs Expenses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={incomeVsExpensesData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, '']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Legend />
                      <Bar dataKey="income" name="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="expenses" name="Expenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            {/* Savings Growth */}
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp size={18} className="text-vyom-green" />
                  Savings Growth
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={savingsData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <defs>
                        <linearGradient id="colorSavings" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, 'Amount']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="amount" 
                        name="Savings"
                        stroke="#10b981" 
                        fillOpacity={1} 
                        fill="url(#colorSavings)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Spending by Category */}
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <PieChart size={18} className="text-vyom-purple" />
                  Spending by Category
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsChart>
                      <Pie
                        data={categorySpendingData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {categorySpendingData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, 'Amount']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Legend />
                    </RechartsChart>
                  </ResponsiveContainer>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4">
                  {categorySpendingData.slice(0, 3).map((category, index) => (
                    <div key={index} className="flex flex-col items-center p-2 rounded-lg bg-gray-50">
                      <div className="p-1.5 rounded-full" style={{ backgroundColor: `${category.fill}20` }}>
                        {category.icon}
                      </div>
                      <span className="text-xs mt-1">{category.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Year over Year Comparison */}
            <Card className="shadow-md border-none md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <LineChart size={18} className="text-vyom-blue" />
                  Year-over-Year Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <RLineChart
                      data={yearComparisonData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, '']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="current" 
                        name="2023" 
                        stroke="#3b82f6" 
                        activeDot={{ r: 8 }} 
                        strokeWidth={2}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="previous" 
                        name="2022" 
                        stroke="#94a3b8" 
                        strokeDasharray="5 5" 
                        strokeWidth={2}
                      />
                    </RLineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="shadow-md border-none col-span-1 md:col-span-3">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles size={18} className="text-vyom-teal" />
                  Financial Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                    <div className="flex items-center gap-2 mb-2">
                      <Wallet size={18} className="text-vyom-blue" />
                      <h3 className="font-medium">Savings Opportunity</h3>
                    </div>
                    <p className="text-sm text-vyom-gray">Your dining expenses have increased by 15% compared to last month. Consider cooking at home more often to save around ₹3,000 per month.</p>
                    <Button variant="link" className="p-0 h-auto mt-2 text-xs">Learn More</Button>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-green-50 border border-green-100">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp size={18} className="text-vyom-green" />
                      <h3 className="font-medium">Investment Tip</h3>
                    </div>
                    <p className="text-sm text-vyom-gray">Consider increasing your monthly SIP contribution by 10% to accelerate your retirement fund growth. This could add ₹15 lakhs to your corpus in 10 years.</p>
                    <Button variant="link" className="p-0 h-auto mt-2 text-xs">Learn More</Button>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-purple-50 border border-purple-100">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign size={18} className="text-vyom-purple" />
                      <h3 className="font-medium">Tax Saving</h3>
                    </div>
                    <p className="text-sm text-vyom-gray">You still have room for ₹50,000 tax-saving investments under Section 80C. Investing now could save you approximately ₹15,000 in taxes.</p>
                    <Button variant="link" className="p-0 h-auto mt-2 text-xs">Learn More</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="spending" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="shadow-md border-none col-span-1 md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Calendar size={18} className="text-vyom-blue" />
                  Daily Spending Pattern
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklySpendingData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, 'Amount']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Bar dataKey="amount" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <ShoppingCart size={18} className="text-vyom-red" />
                  Top Spending Categories
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categorySpendingData.map((category, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-full" style={{ backgroundColor: `${category.fill}20` }}>
                            {category.icon}
                          </div>
                          <span className="text-sm font-medium">{category.name}</span>
                        </div>
                        <span className="text-sm">₹{category.value.toLocaleString()}</span>
                      </div>
                      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full rounded-full" 
                          style={{ 
                            width: `${(category.value / Math.max(...categorySpendingData.map(c => c.value))) * 100}%`,
                            backgroundColor: category.fill
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Coffee size={18} className="text-vyom-purple" />
                  Merchant Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <ShoppingCart size={16} className="text-vyom-blue" />
                        <span className="font-medium">Amazon</span>
                      </div>
                      <span>₹7,250</span>
                    </div>
                    <div className="text-xs text-vyom-gray">5 transactions this month</div>
                  </div>
                  
                  <div className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Utensils size={16} className="text-vyom-red" />
                        <span className="font-medium">Food Delivery</span>
                      </div>
                      <span>₹4,350</span>
                    </div>
                    <div className="text-xs text-vyom-gray">12 transactions this month</div>
                  </div>
                  
                  <div className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Droplet size={16} className="text-vyom-teal" />
                        <span className="font-medium">Utility Bills</span>
                      </div>
                      <span>₹3,600</span>
                    </div>
                    <div className="text-xs text-vyom-gray">4 transactions this month</div>
                  </div>
                  
                  <div className="p-3 rounded-lg border">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Car size={16} className="text-vyom-orange" />
                        <span className="font-medium">Fuel & Transport</span>
                      </div>
                      <span>₹3,200</span>
                    </div>
                    <div className="text-xs text-vyom-gray">8 transactions this month</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <BarChart3 size={18} className="text-vyom-green" />
                  Monthly Comparison
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={[
                        { month: 'Jan', shopping: 6500, food: 4200, bills: 5300, entertainment: 1800 },
                        { month: 'Feb', shopping: 7200, food: 4800, bills: 5500, entertainment: 2200 },
                        { month: 'Mar', shopping: 6800, food: 4500, bills: 5800, entertainment: 1500 },
                        { month: 'Apr', shopping: 7800, food: 5000, bills: 6000, entertainment: 1900 },
                        { month: 'May', shopping: 8200, food: 5100, bills: 6200, entertainment: 2000 },
                        { month: 'Jun', shopping: 8500, food: 5200, bills: 6300, entertainment: 2100 }
                      ]}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`₹${value.toLocaleString()}`, '']}
                        contentStyle={{ borderRadius: '8px', boxShadow: '0 4px 6px rgba(0,0,0,0.1)', border: '1px solid #f0f0f0' }}
                      />
                      <Legend />
                      <Bar dataKey="shopping" name="Shopping" stackId="a" fill="#3b82f6" />
                      <Bar dataKey="food" name="Food" stackId="a" fill="#10b981" />
                      <Bar dataKey="bills" name="Bills" stackId="a" fill="#ef4444" />
                      <Bar dataKey="entertainment" name="Entertainment" stackId="a" fill="#8b5cf6" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="budget" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="shadow-md border-none col-span-1 md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <DollarSign size={18} className="text-vyom-blue" />
                  Budget Overview
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {budgetData.map((category, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{category.category}</span>
                        <span className="text-sm">₹{category.spent.toLocaleString()} of ₹{category.limit.toLocaleString()}</span>
                      </div>
                      <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${category.spent > category.limit * 0.9 ? 'bg-vyom-red' : 'bg-vyom-green'}`}
                          style={{ width: `${Math.min((category.spent / category.limit) * 100, 100)}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-xs text-vyom-gray">
                        <span>₹{(category.limit - category.spent).toLocaleString()} remaining</span>
                        <span>{Math.round((category.spent / category.limit) * 100)}% used</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card className="shadow-md border-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp size={18} className="text-vyom-green" />
                  Budget Health
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center p-4">
                  <div className="relative h-40 w-40">
                    <svg viewBox="0 0 100 100" className="h-full w-full">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="#e5e7eb"
                        strokeWidth="10"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="10"
                        strokeDasharray="283"
                        strokeDashoffset="70"
                        transform="rotate(-90 50 50)"
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-3xl font-bold text-vyom-green">75%</span>
                      <span className="text-sm text-vyom-gray">Budget Health</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3 mt-4">
                  <div className="p-3 rounded-lg bg-green-50 border border-green-100">
                    <p className="text-sm"><span className="font-medium">Shopping</span>: Under budget by ₹1,500</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50 border border-green-100">
                    <p className="text-sm"><span className="font-medium">Food</span>: Under budget by ₹2,800</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50 border border-red-100">
                    <p className="text-sm"><span className="font-medium">Bills</span>: Over budget by ₹700</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card className="shadow-md border-none">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Sparkles size={18} className="text-vyom-teal" />
                Budget Optimization Suggestions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-lg bg-blue-50 border border-blue-100">
                  <h3 className="font-medium text-vyom-blue mb-2">Food Expenses</h3>
                  <p className="text-sm text-vyom-gray">Plan meals for the week and buy groceries in bulk to reduce food expenses by up to 20%.</p>
                </div>
                
                <div className="p-4 rounded-lg bg-purple-50 border border-purple-100">
                  <h3 className="font-medium text-vyom-purple mb-2">Entertainment</h3>
                  <p className="text-sm text-vyom-gray">Look for free or discounted entertainment options. Your bank offers discounts on movie tickets and streaming services.</p>
                </div>
                
                <div className="p-4 rounded-lg bg-green-50 border border-green-100">
                  <h3 className="font-medium text-vyom-green mb-2">Utility Bills</h3>
                  <p className="text-sm text-vyom-gray">Use energy-efficient appliances and be mindful of electricity usage to reduce utility bills by 15%.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinancialInsights;
