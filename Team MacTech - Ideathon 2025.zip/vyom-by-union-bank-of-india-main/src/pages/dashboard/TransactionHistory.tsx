
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Download, Filter, Search, ArrowUpDown, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format } from "date-fns";

const transactions = [
  {
    id: "TXN789012",
    date: "24 Mar 2025",
    description: "Salary Credit",
    type: "Credit",
    category: "Income",
    amount: "75,000.00",
    status: "Completed"
  },
  {
    id: "TXN789013",
    date: "23 Mar 2025",
    description: "ATM Withdrawal",
    type: "Debit",
    category: "Withdrawal",
    amount: "10,000.00",
    status: "Completed"
  },
  {
    id: "TXN789014",
    date: "22 Mar 2025",
    description: "Online Shopping - Amazon",
    type: "Debit",
    category: "Shopping",
    amount: "2,450.00",
    status: "Completed"
  },
  {
    id: "TXN789015",
    date: "21 Mar 2025",
    description: "Electricity Bill Payment",
    type: "Debit",
    category: "Utilities",
    amount: "3,250.00",
    status: "Completed"
  },
  {
    id: "TXN789016",
    date: "20 Mar 2025",
    description: "Fund Transfer to Rahul",
    type: "Debit",
    category: "Transfer",
    amount: "5,000.00",
    status: "Completed"
  },
  {
    id: "TXN789017",
    date: "19 Mar 2025",
    description: "Mutual Fund Investment",
    type: "Debit",
    category: "Investment",
    amount: "10,000.00",
    status: "Completed"
  },
  {
    id: "TXN789018",
    date: "18 Mar 2025",
    description: "Interest Credit",
    type: "Credit",
    category: "Income",
    amount: "750.50",
    status: "Completed"
  },
  {
    id: "TXN789019",
    date: "17 Mar 2025",
    description: "Mobile Recharge",
    type: "Debit",
    category: "Utilities",
    amount: "999.00",
    status: "Completed"
  },
  {
    id: "TXN789020",
    date: "16 Mar 2025",
    description: "Restaurant Payment",
    type: "Debit",
    category: "Food",
    amount: "2,350.00",
    status: "Completed"
  },
  {
    id: "TXN789021",
    date: "15 Mar 2025",
    description: "Cash Deposit",
    type: "Credit",
    category: "Income",
    amount: "20,000.00",
    status: "Completed"
  },
  {
    id: "TXN789022",
    date: "14 Mar 2025",
    description: "Movie Tickets",
    type: "Debit",
    category: "Entertainment",
    amount: "750.00",
    status: "Completed"
  },
  {
    id: "TXN789023",
    date: "13 Mar 2025",
    description: "Healthcare Expense",
    type: "Debit",
    category: "Health",
    amount: "1,500.00",
    status: "Completed"
  },
  {
    id: "TXN789024",
    date: "12 Mar 2025",
    description: "Grocery Shopping",
    type: "Debit",
    category: "Groceries",
    amount: "3,250.00",
    status: "Completed"
  },
  {
    id: "TXN789025",
    date: "11 Mar 2025",
    description: "Dividend Credit",
    type: "Credit",
    category: "Income",
    amount: "1,250.00",
    status: "Completed"
  },
  {
    id: "TXN789026",
    date: "10 Mar 2025",
    description: "Fuel Payment",
    type: "Debit",
    category: "Transport",
    amount: "2,100.00",
    status: "Completed"
  },
];

const TransactionHistory = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  const toggleSort = () => {
    setSortDirection(sortDirection === "asc" ? "desc" : "asc");
  };
  
  // Filter and sort transactions
  const filteredTransactions = transactions.filter(transaction => {
    // Apply type filter
    if (filterType !== "all" && transaction.type.toLowerCase() !== filterType) {
      return false;
    }
    
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        transaction.description.toLowerCase().includes(query) ||
        transaction.category.toLowerCase().includes(query) ||
        transaction.amount.includes(query) ||
        transaction.id.toLowerCase().includes(query)
      );
    }
    
    return true;
  });
  
  // Sort transactions
  const sortedTransactions = [...filteredTransactions].sort((a, b) => {
    const dateA = new Date(a.date).getTime();
    const dateB = new Date(b.date).getTime();
    return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
  });
  
  // Calculate pagination
  const totalPages = Math.ceil(sortedTransactions.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedTransactions = sortedTransactions.slice(startIndex, startIndex + itemsPerPage);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-vyom-blue mb-6">Transaction History</h1>
      
      <Card className="mb-8">
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <CardTitle>All Transactions</CardTitle>
              <CardDescription>View and filter all your account transactions</CardDescription>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 md:flex-none">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search transactions"
                  className="pl-8 w-full md:w-auto min-w-[200px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Calendar className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <CalendarComponent
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              
              <Button variant="outline" size="icon" onClick={toggleSort}>
                <ArrowUpDown className="h-4 w-4" />
              </Button>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent>
                  <div className="space-y-4 p-2">
                    <h4 className="font-medium">Filter Transactions</h4>
                    <div className="space-y-2">
                      <label className="text-sm">Transaction Type</label>
                      <Select
                        value={filterType}
                        onValueChange={setFilterType}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Transactions</SelectItem>
                          <SelectItem value="credit">Credit Only</SelectItem>
                          <SelectItem value="debit">Debit Only</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm">Date Range</label>
                      <Select defaultValue="30days">
                        <SelectTrigger>
                          <SelectValue placeholder="Select range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="7days">Last 7 Days</SelectItem>
                          <SelectItem value="30days">Last 30 Days</SelectItem>
                          <SelectItem value="90days">Last 90 Days</SelectItem>
                          <SelectItem value="custom">Custom Range</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-sm">Category</label>
                      <Select defaultValue="all">
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Categories</SelectItem>
                          <SelectItem value="shopping">Shopping</SelectItem>
                          <SelectItem value="food">Food & Dining</SelectItem>
                          <SelectItem value="utilities">Utilities</SelectItem>
                          <SelectItem value="travel">Travel</SelectItem>
                          <SelectItem value="entertainment">Entertainment</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="flex justify-between pt-2">
                      <Button variant="outline" size="sm">Reset</Button>
                      <Button size="sm">Apply Filters</Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
              
              <Button variant="outline" className="flex items-center gap-2">
                <Download className="h-4 w-4" />
                <span className="hidden md:inline">Download</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Transaction ID</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead className="text-right">Amount (₹)</TableHead>
                  <TableHead className="text-right">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedTransactions.length > 0 ? (
                  paginatedTransactions.map((transaction, index) => (
                    <TableRow key={index} className="cursor-pointer hover:bg-accent">
                      <TableCell>{transaction.date}</TableCell>
                      <TableCell className="font-mono text-xs">{transaction.id}</TableCell>
                      <TableCell>{transaction.description}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {transaction.category}
                        </Badge>
                      </TableCell>
                      <TableCell className={`text-right ${transaction.type === "Credit" ? "text-green-600" : "text-red-500"}`}>
                        {transaction.type === "Credit" ? "+" : "-"}₹{transaction.amount}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge variant="secondary" className="capitalize">
                          {transaction.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      No transactions found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-muted-foreground">
                Showing {startIndex + 1} to {Math.min(startIndex + itemsPerPage, sortedTransactions.length)} of {sortedTransactions.length} transactions
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <div className="flex items-center space-x-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      size="sm"
                      className="w-8"
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </Button>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <Link to="/dashboard">
          <Button variant="outline">Back to Dashboard</Button>
        </Link>
      </div>
    </div>
  );
};

export default TransactionHistory;
