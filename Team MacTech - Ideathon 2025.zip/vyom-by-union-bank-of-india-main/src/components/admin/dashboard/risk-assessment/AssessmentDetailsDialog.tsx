
import React from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RiskAssessment } from "./types";
import RiskBadge from "./RiskBadge";

interface AssessmentDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  assessment: RiskAssessment | null;
}

const AssessmentDetailsDialog = ({ open, onOpenChange, assessment }: AssessmentDetailsDialogProps) => {
  if (!assessment) return null;
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>Risk Assessment Details</DialogTitle>
          <DialogDescription>
            Comprehensive analysis of user's risk profile
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold">Risk Score</h4>
              <div className="text-2xl font-bold">{assessment.risk_score}/100</div>
            </div>
            <div>
              <h4 className="font-semibold">Risk Category</h4>
              <div className="text-xl"><RiskBadge category={assessment.risk_category} /></div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-semibold">Risk Factors</h4>
            
            {assessment.assessment_details && (
              <>
                <div className="border rounded-lg p-3 bg-gray-50">
                  <p className="text-sm font-medium">Age</p>
                  <p className="text-sm text-gray-600">{assessment.assessment_details.age_factor}</p>
                </div>
                
                <div className="border rounded-lg p-3 bg-gray-50">
                  <p className="text-sm font-medium">Occupation</p>
                  <p className="text-sm text-gray-600">{assessment.assessment_details.occupation_factor}</p>
                </div>
                
                <div className="border rounded-lg p-3 bg-gray-50">
                  <p className="text-sm font-medium">Income</p>
                  <p className="text-sm text-gray-600">{assessment.assessment_details.income_factor}</p>
                </div>
                
                <div className="border rounded-lg p-3 bg-gray-50">
                  <p className="text-sm font-medium">KYC Verification</p>
                  <p className="text-sm text-gray-600">{assessment.assessment_details.kyc_factor}</p>
                </div>
                
                <div className="border rounded-lg p-3 bg-gray-50">
                  <p className="text-sm font-medium">Marital Status</p>
                  <p className="text-sm text-gray-600">{assessment.assessment_details.marital_status_factor}</p>
                </div>
              </>
            )}
          </div>

          <div className="border-t pt-4">
            <h4 className="font-semibold mb-2">Summary</h4>
            <p className="text-gray-700">
              {assessment.assessment_details?.summary || 
              "No summary available for this assessment."}
            </p>
          </div>

          <div className="text-xs text-gray-500">
            Last updated: {new Date(assessment.updated_at).toLocaleString()}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AssessmentDetailsDialog;
