
import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, Shield, Key, Globe, Smartphone, MapPin, Lock, Fingerprint, AlertCircle
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/hover-card";

// Mock data for MFA activity
const mfaLogs = [
  { 
    id: 1, 
    user: "Vikram Malhotra", 
    userType: "Employee",
    accountId: "EMP00234", 
    triggerTime: "2023-10-05 14:22:45", 
    triggerReason: "unusual_location", 
    ipAddress: "103.86.177.35", 
    location: "Pune, India", 
    expectedLocation: "Mumbai, India",
    deviceType: "Mobile - Android",
    status: "approved", 
    mfaMethod: "sms"
  },
  { 
    id: 2, 
    user: "Sanjay Kumar", 
    userType: "Customer",
    accountId: "CUST78561", 
    triggerTime: "2023-10-05 09:15:22", 
    triggerReason: "large_transaction", 
    ipAddress: "45.112.162.78", 
    location: "Delhi, India", 
    expectedLocation: "Delhi, India",
    deviceType: "Desktop - Windows",
    status: "pending", 
    mfaMethod: "app"
  },
  { 
    id: 3, 
    user: "Anita Shah", 
    userType: "Customer",
    accountId: "CUST45672", 
    triggerTime: "2023-10-05 11:42:17", 
    triggerReason: "new_device", 
    ipAddress: "182.73.143.42", 
    location: "Bangalore, India", 
    expectedLocation: "Bangalore, India",
    deviceType: "Mobile - iOS",
    status: "approved", 
    mfaMethod: "email"
  },
  { 
    id: 4, 
    user: "Rajiv Gupta", 
    userType: "Employee",
    accountId: "EMP00567", 
    triggerTime: "2023-10-05 18:07:33", 
    triggerReason: "suspicious_activity", 
    ipAddress: "59.162.23.98", 
    location: "Mumbai, India", 
    expectedLocation: "Mumbai, India",
    deviceType: "Desktop - MacOS",
    status: "rejected", 
    mfaMethod: "app"
  },
  { 
    id: 5, 
    user: "Meera Patel", 
    userType: "Customer",
    accountId: "CUST12908", 
    triggerTime: "2023-10-05 21:55:11", 
    triggerReason: "unusual_time", 
    ipAddress: "122.175.65.143", 
    location: "Ahmedabad, India", 
    expectedLocation: "Ahmedabad, India",
    deviceType: "Mobile - Android",
    status: "approved", 
    mfaMethod: "sms"
  }
];

const activeAlerts = [
  {
    id: 1,
    user: "Sanjay Kumar",
    userType: "Customer",
    accountId: "CUST78561",
    alertTime: "2023-10-05 09:15:22",
    triggerReason: "large_transaction",
    details: "Attempted transaction of ₹500,000 to new beneficiary",
    status: "pending",
    priority: "high"
  },
  {
    id: 2,
    user: "Leela Krishnan",
    userType: "Customer",
    accountId: "CUST34521",
    alertTime: "2023-10-05 10:22:45",
    triggerReason: "unusual_location",
    details: "Login from United Kingdom (First time from this country)",
    status: "pending",
    priority: "critical"
  }
];

// Location data for geo monitoring
const geoActivityData = [
  { region: "Mumbai", mfaTriggered: 24, approved: 22, rejected: 2, suspicious: 3 },
  { region: "Delhi", mfaTriggered: 18, approved: 15, rejected: 3, suspicious: 5 },
  { region: "Bangalore", mfaTriggered: 12, approved: 11, rejected: 1, suspicious: 2 },
  { region: "Hyderabad", mfaTriggered: 9, approved: 8, rejected: 1, suspicious: 1 },
  { region: "Chennai", mfaTriggered: 7, approved: 6, rejected: 1, suspicious: 2 },
  { region: "International", mfaTriggered: 5, approved: 2, rejected: 3, suspicious: 5 }
];

const MFAPanel = () => {
  const [mfaAlertSound, setMfaAlertSound] = useState(true);
  const [blockInternational, setBlockInternational] = useState(true);
  const [autoApproveTrusted, setAutoApproveTrusted] = useState(true);
  
  const handleApprove = (logId: number) => {
    toast({
      title: "MFA Approved",
      description: `You've approved the MFA verification for ID ${logId}.`,
    });
  };
  
  const handleReject = (logId: number) => {
    toast({
      title: "MFA Rejected",
      description: `You've rejected the MFA verification for ID ${logId}.`,
      variant: "destructive"
    });
  };
  
  const handleLockAccount = (accountId: string) => {
    toast({
      title: "Account Locked",
      description: `Account ${accountId} has been locked due to suspicious activity.`,
      variant: "destructive"
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <Key className="h-5 w-5 text-vyom-blue" />
              MFA Triggers Today
            </CardTitle>
            <CardDescription>Total MFA verifications initiated</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-vyom-blue">78</div>
            <p className="text-sm text-vyom-gray">↑ 12% from yesterday</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <Globe className="h-5 w-5 text-amber-500" />
              Geo-Alerts
            </CardTitle>
            <CardDescription>Location-based MFA triggers</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-500">15</div>
            <p className="text-sm text-vyom-gray">5 international locations</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-purple-500" />
              New Devices
            </CardTitle>
            <CardDescription>First-time device logins</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-500">23</div>
            <p className="text-sm text-vyom-gray">12 mobile, 11 desktop</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              Pending Actions
            </CardTitle>
            <CardDescription>MFA verifications awaiting approval</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-500">2</div>
            <p className="text-sm text-vyom-gray">1 high priority</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-500" />
            Active MFA Alerts
          </CardTitle>
          <CardDescription>Pending MFA verifications requiring admin attention</CardDescription>
        </CardHeader>
        <CardContent>
          {activeAlerts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User</TableHead>
                  <TableHead>Account ID</TableHead>
                  <TableHead>Time</TableHead>
                  <TableHead>Trigger Reason</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activeAlerts.map((alert) => (
                  <TableRow key={alert.id}>
                    <TableCell className="font-medium">
                      {alert.user}
                      <span className="ml-2 text-xs text-vyom-gray">{alert.userType}</span>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{alert.accountId}</TableCell>
                    <TableCell>{alert.alertTime}</TableCell>
                    <TableCell>
                      {alert.triggerReason === "large_transaction" && (
                        <Badge className="bg-amber-100 text-amber-800 border-amber-200">Large Transaction</Badge>
                      )}
                      {alert.triggerReason === "unusual_location" && (
                        <Badge className="bg-red-100 text-red-800 border-red-200">Unusual Location</Badge>
                      )}
                    </TableCell>
                    <TableCell>{alert.details}</TableCell>
                    <TableCell>
                      {alert.priority === "high" && (
                        <Badge className="bg-amber-100 text-amber-800 border-amber-200">High</Badge>
                      )}
                      {alert.priority === "critical" && (
                        <Badge className="bg-red-100 text-red-800 border-red-200">Critical</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="h-8 px-2 text-xs bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                          onClick={() => handleApprove(alert.id)}
                        >
                          Approve
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 px-2 text-xs bg-red-50 text-red-700 border-red-200 hover:bg-red-100"
                          onClick={() => handleReject(alert.id)}
                        >
                          Reject
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="h-8 px-2 text-xs"
                          onClick={() => handleLockAccount(alert.accountId)}
                        >
                          <Lock className="h-3 w-3 mr-1" />
                          Lock Account
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <Shield className="h-12 w-12 text-green-500 mb-2" />
              <h3 className="text-lg font-medium">No pending MFA alerts</h3>
              <p className="text-sm text-vyom-gray">All MFA verifications have been processed</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All MFA Logs</TabsTrigger>
          <TabsTrigger value="geo">Geo Monitoring</TabsTrigger>
          <TabsTrigger value="methods">MFA Methods</TabsTrigger>
          <TabsTrigger value="settings">MFA Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5 text-vyom-blue" />
                MFA Activity Logs
              </CardTitle>
              <CardDescription>Comprehensive view of all MFA verifications</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Account ID</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Trigger Reason</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Device</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mfaLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-medium">
                        {log.user}
                        <span className="ml-2 text-xs text-vyom-gray">{log.userType}</span>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{log.accountId}</TableCell>
                      <TableCell>{log.triggerTime}</TableCell>
                      <TableCell>
                        {log.triggerReason === "unusual_location" && (
                          <Badge className="bg-red-100 text-red-800 border-red-200">Unusual Location</Badge>
                        )}
                        {log.triggerReason === "large_transaction" && (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-200">Large Transaction</Badge>
                        )}
                        {log.triggerReason === "new_device" && (
                          <Badge className="bg-blue-100 text-blue-800 border-blue-200">New Device</Badge>
                        )}
                        {log.triggerReason === "suspicious_activity" && (
                          <Badge className="bg-purple-100 text-purple-800 border-purple-200">Suspicious Activity</Badge>
                        )}
                        {log.triggerReason === "unusual_time" && (
                          <Badge className="bg-orange-100 text-orange-800 border-orange-200">Unusual Time</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <HoverCard>
                          <HoverCardTrigger className="flex items-center gap-1 cursor-help">
                            <MapPin className="h-3 w-3" />
                            {log.location}
                          </HoverCardTrigger>
                          <HoverCardContent>
                            <div className="text-sm">
                              <div className="font-medium mb-1">Location Details</div>
                              <div className="grid grid-cols-2 gap-2">
                                <div className="text-vyom-gray">Current:</div>
                                <div>{log.location}</div>
                                <div className="text-vyom-gray">Expected:</div>
                                <div>{log.expectedLocation}</div>
                                <div className="text-vyom-gray">IP Address:</div>
                                <div className="font-mono text-xs">{log.ipAddress}</div>
                              </div>
                            </div>
                          </HoverCardContent>
                        </HoverCard>
                      </TableCell>
                      <TableCell>{log.deviceType}</TableCell>
                      <TableCell>
                        {log.mfaMethod === "sms" && (
                          <Badge className="bg-green-100 text-green-800 border-green-200">SMS</Badge>
                        )}
                        {log.mfaMethod === "app" && (
                          <Badge className="bg-blue-100 text-blue-800 border-blue-200">Authenticator App</Badge>
                        )}
                        {log.mfaMethod === "email" && (
                          <Badge className="bg-purple-100 text-purple-800 border-purple-200">Email</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {log.status === "approved" && (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Approved</Badge>
                        )}
                        {log.status === "pending" && (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-200">Pending</Badge>
                        )}
                        {log.status === "rejected" && (
                          <Badge className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {log.status === "pending" ? (
                          <div className="flex space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              className="h-8 px-2 text-xs bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                              onClick={() => handleApprove(log.id)}
                            >
                              Approve
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="h-8 px-2 text-xs bg-red-50 text-red-700 border-red-200 hover:bg-red-100"
                              onClick={() => handleReject(log.id)}
                            >
                              Reject
                            </Button>
                          </div>
                        ) : (
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="h-8 px-2 text-xs"
                          >
                            View Details
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <div className="text-sm text-vyom-gray">Showing 5 of 78 entries</div>
              <Button variant="outline" size="sm">View All Logs</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="geo">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-vyom-blue" />
                Geo-based MFA Monitoring
              </CardTitle>
              <CardDescription>Location-based security insights and MFA triggers</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Region</TableHead>
                    <TableHead>MFA Triggers</TableHead>
                    <TableHead>Approved</TableHead>
                    <TableHead>Rejected</TableHead>
                    <TableHead>Suspicious Activities</TableHead>
                    <TableHead>Risk Level</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {geoActivityData.map((region) => (
                    <TableRow key={region.region}>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {region.region}
                        </div>
                      </TableCell>
                      <TableCell>{region.mfaTriggered}</TableCell>
                      <TableCell>{region.approved}</TableCell>
                      <TableCell>{region.rejected}</TableCell>
                      <TableCell>{region.suspicious}</TableCell>
                      <TableCell>
                        {region.region === "International" ? (
                          <Badge className="bg-red-100 text-red-800 border-red-200">High</Badge>
                        ) : region.suspicious > 4 ? (
                          <Badge className="bg-amber-100 text-amber-800 border-amber-200">Medium</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800 border-green-200">Low</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter className="flex justify-between border-t px-6 py-4">
              <div className="flex items-center space-x-2">
                <Switch 
                  id="block-international" 
                  checked={blockInternational} 
                  onCheckedChange={setBlockInternational}
                />
                <label htmlFor="block-international" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Auto-block logins from unexpected international locations
                </label>
              </div>
              <Button variant="outline" size="sm">View Detailed Map</Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="methods">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5 text-vyom-blue" />
                MFA Methods Analysis
              </CardTitle>
              <CardDescription>Performance metrics for different MFA methods</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-blue-50 rounded-lg p-6 text-center">
                  <Smartphone className="h-10 w-10 text-blue-600 mx-auto mb-2" />
                  <h3 className="text-lg font-medium text-blue-800">Authenticator App</h3>
                  <div className="text-3xl font-bold text-blue-600 my-3">42%</div>
                  <p className="text-sm text-blue-600">Most Secure Method</p>
                  <p className="text-sm text-vyom-gray mt-2">Average completion time: 8 seconds</p>
                </div>
                
                <div className="bg-green-50 rounded-lg p-6 text-center">
                  <Smartphone className="h-10 w-10 text-green-600 mx-auto mb-2" />
                  <h3 className="text-lg font-medium text-green-800">SMS OTP</h3>
                  <div className="text-3xl font-bold text-green-600 my-3">38%</div>
                  <p className="text-sm text-green-600">Most Popular Method</p>
                  <p className="text-sm text-vyom-gray mt-2">Average completion time: 22 seconds</p>
                </div>
                
                <div className="bg-purple-50 rounded-lg p-6 text-center">
                  <Smartphone className="h-10 w-10 text-purple-600 mx-auto mb-2" />
                  <h3 className="text-lg font-medium text-purple-800">Email OTP</h3>
                  <div className="text-3xl font-bold text-purple-600 my-3">20%</div>
                  <p className="text-sm text-purple-600">Fallback Method</p>
                  <p className="text-sm text-vyom-gray mt-2">Average completion time: 45 seconds</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5 text-vyom-blue" />
                MFA Settings & Configuration
              </CardTitle>
              <CardDescription>Configure how MFA works across the system</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Alert Sound for New MFA Requests</h3>
                  <p className="text-sm text-vyom-gray">Play sound when new MFA verification is required</p>
                </div>
                <Switch 
                  checked={mfaAlertSound} 
                  onCheckedChange={setMfaAlertSound}
                />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Auto-approve for Trusted Devices/Locations</h3>
                  <p className="text-sm text-vyom-gray">Automatically approve MFA for recognized patterns</p>
                </div>
                <Switch 
                  checked={autoApproveTrusted} 
                  onCheckedChange={setAutoApproveTrusted}
                />
              </div>
              
              <div className="flex items-center justify-between py-2 border-b">
                <div>
                  <h3 className="font-medium">Block International Logins</h3>
                  <p className="text-sm text-vyom-gray">Block logins from international locations</p>
                </div>
                <Switch 
                  checked={blockInternational} 
                  onCheckedChange={setBlockInternational}
                />
              </div>
              
              <div className="flex items-center justify-between py-2">
                <div>
                  <h3 className="font-medium">MFA Session Duration</h3>
                  <p className="text-sm text-vyom-gray">How long until MFA is required again</p>
                </div>
                <select className="px-3 py-2 border rounded-md">
                  <option value="1">1 Hour</option>
                  <option value="4">4 Hours</option>
                  <option value="8" selected>8 Hours</option>
                  <option value="24">24 Hours</option>
                </select>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end border-t px-6 py-4">
              <Button>Save Settings</Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default MFAPanel;
