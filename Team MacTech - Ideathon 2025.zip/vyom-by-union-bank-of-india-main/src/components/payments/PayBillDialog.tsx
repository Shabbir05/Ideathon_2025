
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "@/hooks/use-toast";
import { useState } from "react";

interface PayBillDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bill: {
    name: string;
    amount: string;
    dueDate?: string;
  } | null;
}

export function PayBillDialog({ open, onOpenChange, bill }: PayBillDialogProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  
  if (!bill) return null;

  const handlePayment = () => {
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Payment Successful",
        description: `Payment of ₹${bill.amount} for ${bill.name} has been completed.`,
      });
      onOpenChange(false);
    }, 1500);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Confirm Payment</DialogTitle>
          <DialogDescription>
            Please review and confirm the bill payment details
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-1">
            <p className="text-sm font-medium">Biller</p>
            <p className="text-sm text-muted-foreground">{bill.name}</p>
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium">Amount</p>
            <p className="text-base font-semibold text-vyom-red">₹{bill.amount}</p>
          </div>
          {bill.dueDate && (
            <div className="space-y-1">
              <p className="text-sm font-medium">Due Date</p>
              <p className="text-sm text-muted-foreground">{bill.dueDate}</p>
            </div>
          )}
          <div className="rounded-md bg-amber-50 p-3 border border-amber-200">
            <p className="text-sm text-amber-800">
              By proceeding, you confirm that you authorize this payment.
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isProcessing}>
            Cancel
          </Button>
          <Button onClick={handlePayment} disabled={isProcessing}>
            {isProcessing ? "Processing..." : "Confirm Payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
