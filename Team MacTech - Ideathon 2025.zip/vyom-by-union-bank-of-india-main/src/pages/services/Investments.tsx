
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { TrendingUp, Shield, BarChart3, PieChart, Clock, CreditCard, ArrowRight, ChevronRight } from "lucide-react";

const Investments = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-vyom-light to-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-vyom-blue to-vyom-purple text-white py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Investment & Wealth Management
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-8">
              Grow your wealth with our expert investment solutions designed to help you achieve your financial goals.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button variant="default" size="lg" className="rounded-full">
                Start Investing <ArrowRight className="ml-2" />
              </Button>
              <Button variant="outline" size="lg" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 rounded-full">
                Speak to an Advisor
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-16 bg-white" style={{ clipPath: "polygon(0 100%, 100% 100%, 100% 0)" }}></div>
      </div>

      {/* Investment Products Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Investment Products</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Mutual Funds */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-red"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <PieChart className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Mutual Funds</h3>
                </div>
                <p className="text-gray-600 mb-4">Professionally managed investment portfolios across equity, debt, and hybrid options.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Diversified investment options</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Start with as little as ₹500 per month</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Tax benefits on select funds</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Mutual Funds <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Fixed Deposits */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-teal"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Clock className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Fixed Deposits</h3>
                </div>
                <p className="text-gray-600 mb-4">Secure your savings with guaranteed returns for a fixed period.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Competitive interest rates up to 7.25% p.a.</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Flexible tenures from 7 days to 10 years</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Special rates for senior citizens</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Open a Fixed Deposit <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Stocks & Trading */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-purple"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <TrendingUp className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Stocks & Trading</h3>
                </div>
                <p className="text-gray-600 mb-4">Invest directly in equities through our secure trading platform.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Access to BSE and NSE markets</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Advanced trading tools and research</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Low brokerage fees</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Start Trading <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Government Bonds */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-blue"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Shield className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Government Bonds</h3>
                </div>
                <p className="text-gray-600 mb-4">Invest in government-backed securities for stable returns.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Sovereign guarantee on investments</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Regular interest payouts</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Tax benefits as per applicable laws</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Learn More <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Recurring Deposits */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-teal"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <CreditCard className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Recurring Deposits</h3>
                </div>
                <p className="text-gray-600 mb-4">Build your savings systematically with monthly deposits.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Start with as low as ₹500 per month</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Flexible tenure options</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Automatic monthly deposits</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Open an RD Account <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Vyom Portfolio Management */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-red"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <BarChart3 className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Portfolio Management</h3>
                </div>
                <p className="text-gray-600 mb-4">Personalized investment strategies managed by expert advisors.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Tailored investment strategies</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Regular portfolio reviews</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Dedicated wealth advisor</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Schedule a Consultation <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Investment Performance Section */}
      <div className="py-16 bg-vyom-light">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
                <BarChart3 size={48} className="text-vyom-blue mb-4" />
                <h3 className="text-2xl font-bold mb-4 text-vyom-blue">Performance Tracker</h3>
                <p className="text-gray-600 mb-4">
                  Track the performance of your investments and make informed decisions with our advanced analytics tools.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3">
                    <Shield className="text-vyom-teal" />
                    <span>Real-time portfolio valuation</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Shield className="text-vyom-teal" />
                    <span>Comprehensive performance reports</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <Shield className="text-vyom-teal" />
                    <span>Market insights and recommendations</span>
                  </li>
                </ul>
              </div>
              <div className="md:w-1/2 bg-vyom-light p-6 rounded-lg">
                <h4 className="font-semibold mb-4 text-center">Coming Soon</h4>
                <p className="text-center text-gray-600 mb-4">Our interactive performance tracker is under development and will be available shortly.</p>
                <Button variant="default" className="w-full">
                  Get Notified When Available
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-gradient-to-r from-vyom-blue to-vyom-purple rounded-xl text-white p-8 md:p-12 max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold mb-4 text-center">Ready to Start Your Investment Journey?</h2>
            <p className="text-xl text-center mb-8">Open an investment account today and take the first step towards financial growth.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="default" size="lg">Open an Investment Account</Button>
              <Button variant="outline" size="lg" className="bg-white/10 border-white/20 hover:bg-white/20">
                Schedule a Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Investments;
