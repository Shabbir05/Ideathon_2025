
import { useState } from "react";
import { 
  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle 
} from "@/components/ui/card";
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, Shield, Lock, Clock, MapPin, UserCog, LogIn, LogOut, Activity, User
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { toast } from "@/hooks/use-toast";

// Mock data for employee activity
const recentLogins = [
  { 
    id: 1, 
    employee: "Sarah Johnson", 
    role: "Loan Officer", 
    loginTime: "2023-10-05 08:30:22", 
    logoutTime: "2023-10-05 17:45:13", 
    duration: "9h 15m", 
    ipAddress: "192.168.1.45", 
    location: "Mumbai HQ", 
    status: "normal" 
  },
  { 
    id: 2, 
    employee: "Rahul Sharma", 
    role: "Customer Service", 
    loginTime: "2023-10-05 23:17:05", 
    logoutTime: "2023-10-06 01:22:48", 
    duration: "2h 5m", 
    ipAddress: "103.54.89.213", 
    location: "Delhi (Remote)", 
    status: "unusual" 
  },
  { 
    id: 3, 
    employee: "Ananya Patel", 
    role: "Account Manager", 
    loginTime: "2023-10-05 09:02:17", 
    logoutTime: "2023-10-05 18:15:32", 
    duration: "9h 13m", 
    ipAddress: "192.168.1.78", 
    location: "Mumbai HQ", 
    status: "normal" 
  },
  { 
    id: 4, 
    employee: "Vikram Singh", 
    role: "System Administrator", 
    loginTime: "2023-10-05 07:55:12", 
    logoutTime: "-", 
    duration: "Active", 
    ipAddress: "192.168.1.22", 
    location: "Mumbai HQ", 
    status: "normal" 
  },
  { 
    id: 5, 
    employee: "Priya Mehta", 
    role: "Loan Officer", 
    loginTime: "2023-10-05 10:12:44", 
    logoutTime: "2023-10-05 14:30:19", 
    duration: "4h 18m", 
    ipAddress: "117.192.45.78", 
    location: "Bangalore (Remote)", 
    status: "normal" 
  }
];

const loginAttempts = [
  { 
    id: 1, 
    employee: "Kiran Das", 
    time: "2023-10-05 15:22:33", 
    ipAddress: "81.22.45.67", 
    location: "Unknown (France)", 
    status: "failed", 
    attempts: 5, 
    action: "account_locked" 
  },
  { 
    id: 2, 
    employee: "Vikram Singh", 
    time: "2023-10-05 03:12:45", 
    ipAddress: "192.168.1.22", 
    location: "Mumbai HQ", 
    status: "success", 
    attempts: 1, 
    action: "unusual_hours" 
  },
  { 
    id: 3, 
    employee: "Neha Gupta", 
    time: "2023-10-05 11:45:12", 
    ipAddress: "192.168.14.55", 
    location: "Delhi Branch", 
    status: "escalation", 
    attempts: 1, 
    action: "privilege_escalation" 
  }
];

const loginActivityData = [
  { time: '00:00', logins: 2, failed: 0, unusual: 0 },
  { time: '02:00', logins: 1, failed: 2, unusual: 1 },
  { time: '04:00', logins: 0, failed: 1, unusual: 0 },
  { time: '06:00', logins: 5, failed: 0, unusual: 0 },
  { time: '08:00', logins: 25, failed: 3, unusual: 0 },
  { time: '10:00', logins: 15, failed: 1, unusual: 0 },
  { time: '12:00', logins: 10, failed: 0, unusual: 0 },
  { time: '14:00', logins: 12, failed: 2, unusual: 1 },
  { time: '16:00', logins: 8, failed: 1, unusual: 0 },
  { time: '18:00', logins: 6, failed: 0, unusual: 0 },
  { time: '20:00', logins: 4, failed: 3, unusual: 2 },
  { time: '22:00', logins: 3, failed: 5, unusual: 1 },
];

const EmployeeActivity = () => {
  const [lockoutThreshold, setLockoutThreshold] = useState(5);
  const [autoLockEnabled, setAutoLockEnabled] = useState(true);
  
  const handleLockAccount = (employeeId: number) => {
    toast({
      title: "Account Locked",
      description: `Employee ID ${employeeId} account has been manually locked.`,
      variant: "destructive"
    });
  };
  
  const handleUnlockAccount = (employeeId: number) => {
    toast({
      title: "Account Unlocked",
      description: `Employee ID ${employeeId} account has been manually unlocked.`,
    });
  };
  
  const handleResetAttempts = (employeeId: number) => {
    toast({
      title: "Login Attempts Reset",
      description: `Login attempts counter has been reset for employee ID ${employeeId}.`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <Activity className="h-5 w-5 text-vyom-blue" />
              Active Sessions
            </CardTitle>
            <CardDescription>Currently active employee sessions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-vyom-blue">17</div>
            <p className="text-sm text-vyom-gray">Out of 42 total employees</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-amber-500" />
              Security Alerts
            </CardTitle>
            <CardDescription>Employee account related alerts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-500">4</div>
            <p className="text-sm text-vyom-gray">
              <span className="text-red-500 font-medium">1 critical</span>,
              <span className="text-amber-500 font-medium"> 3 moderate</span>
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center gap-2">
              <Lock className="h-5 w-5 text-red-500" />
              Locked Accounts
            </CardTitle>
            <CardDescription>Accounts locked due to suspicious activity</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-500">2</div>
            <p className="text-sm text-vyom-gray">Last locked: 35 minutes ago</p>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-vyom-blue" />
            Login Activity Timeline (24 Hours)
          </CardTitle>
          <CardDescription>Tracking successful, failed, and unusual logins</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={loginActivityData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="logins" stroke="#0066FF" strokeWidth={2} activeDot={{ r: 8 }} name="Successful Logins" />
                <Line type="monotone" dataKey="failed" stroke="#FF3A5E" strokeWidth={2} name="Failed Attempts" />
                <Line type="monotone" dataKey="unusual" stroke="#FFD700" strokeWidth={2} name="Unusual Activity" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5 text-vyom-blue" />
            Recent Employee Logins
          </CardTitle>
          <CardDescription>Monitor employee login/logout activity</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Login Time</TableHead>
                <TableHead>Logout Time</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentLogins.map((login) => (
                <TableRow key={login.id}>
                  <TableCell className="font-medium">{login.employee}</TableCell>
                  <TableCell>{login.role}</TableCell>
                  <TableCell>{login.loginTime}</TableCell>
                  <TableCell>{login.logoutTime}</TableCell>
                  <TableCell>{login.duration}</TableCell>
                  <TableCell className="font-mono text-xs">{login.ipAddress}</TableCell>
                  <TableCell className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {login.location}
                  </TableCell>
                  <TableCell>
                    {login.status === "normal" ? (
                      <Badge className="bg-green-100 text-green-800 border-green-200">Normal</Badge>
                    ) : (
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200">Unusual Hours</Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            Suspicious Login Activity
          </CardTitle>
          <CardDescription>Failed attempts, unusual hours, and privilege escalation</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Employee</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>IP Address</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Failed Attempts</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loginAttempts.map((attempt) => (
                <TableRow key={attempt.id}>
                  <TableCell className="font-medium">{attempt.employee}</TableCell>
                  <TableCell>{attempt.time}</TableCell>
                  <TableCell className="font-mono text-xs">{attempt.ipAddress}</TableCell>
                  <TableCell className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {attempt.location}
                  </TableCell>
                  <TableCell>
                    {attempt.status === "failed" && (
                      <Badge className="bg-red-100 text-red-800 border-red-200">Failed Attempts</Badge>
                    )}
                    {attempt.status === "success" && (
                      <Badge className="bg-amber-100 text-amber-800 border-amber-200">Unusual Hours</Badge>
                    )}
                    {attempt.status === "escalation" && (
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">Privilege Escalation</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {attempt.attempts} / {lockoutThreshold}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      {attempt.action === "account_locked" ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          className="h-8 px-2 text-xs"
                          onClick={() => handleUnlockAccount(attempt.id)}
                        >
                          <Lock className="h-3 w-3 mr-1" />
                          Unlock
                        </Button>
                      ) : (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-8 px-2 text-xs text-red-600 border-red-200 hover:bg-red-50"
                          onClick={() => handleLockAccount(attempt.id)}
                        >
                          <Lock className="h-3 w-3 mr-1" />
                          Lock
                        </Button>
                      )}
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="h-8 px-2 text-xs"
                        onClick={() => handleResetAttempts(attempt.id)}
                      >
                        Reset Counter
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
        <CardFooter className="flex justify-between border-t px-6 py-4">
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="auto-lockout" 
              checked={autoLockEnabled} 
              onCheckedChange={(checked) => setAutoLockEnabled(checked === true)}
            />
            <label htmlFor="auto-lockout" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              Auto-lock accounts after {lockoutThreshold} failed attempts
            </label>
          </div>
          <Button variant="outline" size="sm">View All Activity Logs</Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default EmployeeActivity;
