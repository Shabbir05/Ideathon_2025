
import { useState, createContext, useContext, ReactNode, useEffect } from "react";
import { Check, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/components/ui/use-toast";

// Define available languages
export const languages = [
  { code: "en", name: "English" },
  { code: "hi", name: "हिंदी" },
  { code: "mr", name: "मराठी" },
];

// Create language context
type LanguageContextType = {
  currentLanguage: typeof languages[0];
  setLanguage: (language: typeof languages[0]) => void;
};

const LanguageContext = createContext<LanguageContextType>({
  currentLanguage: languages[0],
  setLanguage: () => {},
});

// Language provider component
export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  // Check for stored language preference
  const getInitialLanguage = () => {
    const savedLanguage = localStorage.getItem("preferredLanguage");
    if (savedLanguage) {
      const foundLanguage = languages.find(lang => lang.code === savedLanguage);
      return foundLanguage || languages[0];
    }
    return languages[0];
  };

  const [currentLanguage, setCurrentLanguage] = useState(getInitialLanguage);
  const { toast } = useToast();

  // Initialize language on mount
  useEffect(() => {
    // Apply any language specific settings if needed
    document.documentElement.lang = currentLanguage.code;
  }, [currentLanguage]);

  const setLanguage = (language: typeof languages[0]) => {
    setCurrentLanguage(language);
    localStorage.setItem("preferredLanguage", language.code);
    document.documentElement.lang = language.code;
    
    toast({
      title: "Language Changed",
      description: `The interface language has been changed to ${language.name}`,
      duration: 3000,
    });
  };

  return (
    <LanguageContext.Provider value={{ currentLanguage, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use language context
export const useLanguage = () => useContext(LanguageContext);

// Language toggle component
const LanguageToggle = () => {
  const { currentLanguage, setLanguage } = useLanguage();

  const handleLanguageChange = (language: typeof languages[0]) => {
    setLanguage(language);
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="flex items-center text-sm font-medium focus:outline-none">
        <span className="mr-1">{currentLanguage.name}</span>
        <ChevronDown size={16} />
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40 animate-fade-in">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            className="flex items-center justify-between cursor-pointer"
            onClick={() => handleLanguageChange(language)}
          >
            <span>{language.name}</span>
            {currentLanguage.code === language.code && (
              <Check size={16} className="text-vyom-red" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default LanguageToggle;
