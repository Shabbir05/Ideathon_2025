
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Heart, Home, Car, Briefcase, Users, Umbrella, ArrowRight, ChevronRight, Shield } from "lucide-react";

const Insurance = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-vyom-light to-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-vyom-teal to-vyom-blue text-white py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Insurance & Protection Plans
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-8">
              Protect what matters most with comprehensive insurance solutions tailored to your needs.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button variant="default" size="lg" className="rounded-full">
                Get Covered <ArrowRight className="ml-2" />
              </Button>
              <Button variant="outline" size="lg" className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 rounded-full">
                Compare Plans
              </Button>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-16 bg-white" style={{ clipPath: "polygon(0 100%, 100% 100%, 100% 0)" }}></div>
      </div>

      {/* Insurance Products Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Insurance Solutions</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Life Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-red"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Heart className="text-vyom-red mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Life Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Secure your family's financial future with comprehensive life coverage.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Term Life Insurance</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Whole Life Insurance</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Endowment Plans</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Life Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Health Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-teal"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Users className="text-vyom-teal mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Health Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Comprehensive healthcare coverage for you and your family.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Individual Health Plans</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Family Floater Policies</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Critical Illness Coverage</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Health Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Home Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-purple"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Home className="text-vyom-purple mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Home Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Protect your home and belongings against unexpected events.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Building Insurance</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Contents Insurance</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Natural Disaster Protection</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Home Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Motor Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-blue"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Car className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Motor Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Comprehensive coverage for your vehicles with 24/7 roadside assistance.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Third-Party Liability</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Comprehensive Coverage</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Zero Depreciation Options</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Motor Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Business Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-teal"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Briefcase className="text-vyom-blue mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Business Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Protect your business assets and operations with tailored insurance solutions.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Property Insurance</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Liability Coverage</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Business Interruption Insurance</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Business Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
            
            {/* Travel Insurance */}
            <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden">
              <div className="h-2 bg-vyom-red"></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <Umbrella className="text-vyom-red mr-3" size={24} />
                  <h3 className="text-xl font-semibold text-vyom-blue">Travel Insurance</h3>
                </div>
                <p className="text-gray-600 mb-4">Travel with peace of mind with our comprehensive travel protection plans.</p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Medical Emergency Coverage</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Trip Cancellation Protection</span>
                  </li>
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Shield size={16} className="text-vyom-teal" />
                    <span>Baggage Loss Coverage</span>
                  </li>
                </ul>
                <Button variant="link" className="px-0 flex items-center">
                  Explore Travel Insurance <ChevronRight size={16} className="ml-1" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Claims Process Section */}
      <div className="py-16 bg-vyom-light">
        <div className="container mx-auto px-4 md:px-6">
          <h2 className="text-3xl font-bold text-center mb-12 text-vyom-blue">Simple Claims Process</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="bg-white p-6 rounded-xl shadow-md text-center">
              <div className="w-12 h-12 bg-vyom-red/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-vyom-red font-bold text-xl">1</span>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-vyom-blue">Report Claim</h3>
              <p className="text-gray-600">Notify us about your claim through our app, website, or customer service.</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md text-center">
              <div className="w-12 h-12 bg-vyom-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-vyom-blue font-bold text-xl">2</span>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-vyom-blue">Submit Documents</h3>
              <p className="text-gray-600">Upload required documents and evidence through our digital platform.</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md text-center">
              <div className="w-12 h-12 bg-vyom-teal/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-vyom-teal font-bold text-xl">3</span>
              </div>
              <h3 className="text-lg font-semibold mb-3 text-vyom-blue">Receive Settlement</h3>
              <p className="text-gray-600">Get your claim settled quickly with direct transfer to your bank account.</p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Button variant="outline" className="bg-white">
              Learn More About Claims
            </Button>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-gradient-to-r from-vyom-teal to-vyom-blue rounded-xl text-white p-8 md:p-12 max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold mb-4 text-center">Ready to Secure Your Future?</h2>
            <p className="text-xl text-center mb-8">Speak with an insurance advisor today to find the right coverage for your needs.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="default" size="lg">Get a Free Quote</Button>
              <Button variant="outline" size="lg" className="bg-white/10 border-white/20 hover:bg-white/20">
                Speak to an Advisor
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Insurance;
