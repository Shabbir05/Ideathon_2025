
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import AccountOverview from "@/components/AccountOverview";
import { toast } from "@/hooks/use-toast";
import { Account, AccountsSection } from "@/components/dashboard/AccountsSection";
import { PaymentsSection } from "@/components/dashboard/PaymentsSection";
import { InternationalSection } from "@/components/dashboard/InternationalSection";
import { ServicesSection } from "@/components/dashboard/ServicesSection";
import { RecommendationsSection } from "@/components/dashboard/RecommendationsSection";

const UserDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const navigate = useNavigate();
  
  const accounts: Account[] = [
    { 
      id: 1, 
      type: "Savings Account", 
      number: "XXXX XXXX XXXX 4523", 
      balance: 157892.45,
      interestRate: "3.5% p.a.",
      lastTransaction: "Salary Credit - ₹75,000.00",
      lastTransactionDate: "Today, 09:45 AM",
      status: "Active",
      branch: "Andheri East, Mumbai",
      openDate: "15 Jan 2020",
      availableCredit: null,
      transactions: [
        { id: 1, type: "credit", description: "Salary Deposit", amount: 75000, date: "Today, 09:45 AM", category: "Income" },
        { id: 2, type: "debit", description: "Amazon Payment", amount: 3540.50, date: "2 days ago", category: "Shopping" },
        { id: 3, type: "debit", description: "Electric Bill", amount: 1260.75, date: "3 days ago", category: "Utilities" }
      ]
    },
    { 
      id: 2, 
      type: "Current Account", 
      number: "XXXX XXXX XXXX 8967", 
      balance: 245630.20,
      interestRate: "0.5% p.a.",
      lastTransaction: "Fund Transfer - ₹25,000.00",
      lastTransactionDate: "Yesterday, 06:32 PM",
      status: "Active",
      branch: "Bandra West, Mumbai",
      openDate: "05 Mar 2021",
      availableCredit: null,
      transactions: [
        { id: 1, type: "debit", description: "Fund Transfer", amount: 25000, date: "Yesterday, 06:32 PM", category: "Transfer" },
        { id: 2, type: "credit", description: "Client Payment", amount: 45000, date: "3 days ago", category: "Income" },
        { id: 3, type: "debit", description: "Office Supplies", amount: 12350.75, date: "5 days ago", category: "Business" }
      ]
    },
    { 
      id: 3, 
      type: "Fixed Deposit", 
      number: "FD-2023456789", 
      balance: 500000.00,
      interestRate: "5.5% p.a.",
      lastTransaction: "Interest Credit - ₹6,875.00",
      lastTransactionDate: "01 Jun 2023, 10:00 AM",
      status: "Active",
      branch: "Andheri East, Mumbai",
      openDate: "10 Apr 2022",
      maturityDate: "10 Apr 2025",
      availableCredit: null,
      transactions: [
        { id: 1, type: "credit", description: "Interest Credit", amount: 6875, date: "01 Jun 2023, 10:00 AM", category: "Interest" }
      ]
    },
    { 
      id: 4, 
      type: "Credit Card", 
      number: "XXXX XXXX XXXX 7654", 
      balance: -12450.25,
      interestRate: "18% p.a.",
      lastTransaction: "Amazon Shopping - ₹2,450.75",
      lastTransactionDate: "Yesterday, 02:15 PM",
      status: "Active",
      branch: null,
      openDate: "22 Jul 2021",
      availableCredit: 87549.75,
      creditLimit: 100000,
      dueDate: "05 Jun 2023",
      minimumDue: 2500,
      transactions: [
        { id: 1, type: "debit", description: "Amazon Shopping", amount: 2450.75, date: "Yesterday, 02:15 PM", category: "Shopping" },
        { id: 2, type: "debit", description: "Restaurant Bill", amount: 3450, date: "3 days ago", category: "Dining" },
        { id: 3, type: "debit", description: "Movie Tickets", amount: 1200, date: "5 days ago", category: "Entertainment" }
      ]
    }
  ];

  const handleAccountAction = (accountId: number, action: string) => {
    const account = accounts.find(acc => acc.id === accountId);
    if (account) {
      switch(action) {
        case "details":
          // Handled within the AccountsSection component
          break;
        case "transfer":
          setActiveTab("payments");
          toast({
            title: "Transfer Money",
            description: `Set up transfer from ${account.type}`,
          });
          break;
        case "statement":
          toast({
            title: "Generate Statement",
            description: `Generating statement for ${account.type}...`,
          });
          setTimeout(() => {
            toast({
              title: "Statement Ready",
              description: `Your account statement has been downloaded successfully.`,
            });
          }, 2000);
          break;
        case "payDue":
          if (account.type === "Credit Card") {
            setActiveTab("payments");
            toast({
              title: "Pay Credit Card",
              description: `Set up payment for your credit card`,
            });
          }
          break;
        default:
          break;
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2 text-vyom-blue">User Dashboard</h1>
      <p className="text-vyom-gray mb-8">Welcome back! Manage your accounts, payments, and banking services.</p>
      
      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-6 max-w-[900px] bg-vyom-light">
          <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">Overview</TabsTrigger>
          <TabsTrigger value="accounts" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">Accounts</TabsTrigger>
          <TabsTrigger value="payments" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">Payments</TabsTrigger>
          <TabsTrigger value="international" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">International</TabsTrigger>
          <TabsTrigger value="recommendations" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">Recommendations</TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-white data-[state=active]:text-vyom-blue data-[state=active]:shadow-md">Services</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6 animate-fade-in">
          <AccountOverview />
        </TabsContent>

        <TabsContent value="accounts" className="animate-fade-in">
          <AccountsSection 
            accounts={accounts}
            onAccountAction={handleAccountAction}
          />
        </TabsContent>

        <TabsContent value="payments" className="animate-fade-in">
          <PaymentsSection accounts={accounts} />
        </TabsContent>

        <TabsContent value="international" className="animate-fade-in">
          <InternationalSection accounts={accounts} navigate={navigate} />
        </TabsContent>

        <TabsContent value="recommendations" className="animate-fade-in">
          <RecommendationsSection />
        </TabsContent>

        <TabsContent value="services" className="animate-fade-in">
          <ServicesSection navigate={navigate} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserDashboard;
